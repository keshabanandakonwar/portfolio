<!DOCTYPE html>
<html>
  <head>
    <title>voter request </title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <meta name="viewport" content="width=device-width,initial-scale=1">

  </head>
  <body>
    <?php include('header.php'); ?>
    <div class="container">
      <div class="row">
        <div class="col-md-10" style="margin-left:20%">
            <!--------form to allow voters to vote in a election ----------->


     <!------------ show positions details--------------------->
          <table class="table table-bordered mb-4 table-striped table-hover">
            <tr>
              <th colspan="4" class="text-center bg-secondary">
                 <?php
                      if($data['admin_type']=='hod'){
                      $query="SELECT admin.sl_no,admin.admin_type,admin.depertment,depertment.depertment_name,depertment.depertment_id FROM admin INNER JOIN depertment ON  admin.depertment=depertment.depertment_id WHERE admin.sl_no='{$data['sl_no']}'";
                      $run_query=mysqli_query($con,$query);
                      $data2=mysqli_fetch_array($run_query);
                 ?>
                     <h3><?php echo $data2['depertment_name']?></h3>
               <?php } ?>
                <h4>All Voters List</h4>
              </th>
            </tr>
            <tr class='bg-dark text-center'>
               <th class="text-white">Sl No</th>
               <th class="text-white">Voter Details </th>
               <th class="text-white">Election</th>
               <th class="text-white">Action</th>
            </tr>
            <tbody id="voters">


            </tbody>
          </table>

        </div>
      </div>
    </div>
<script type="text/javascript" src="../css/jquery-3.2.1.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
  //load accepted voter details
   function  loadData(){
     $.ajax({
       url : "fetch_accept_voters.php",
       type : "GET",
       success : function(data){
         $('#voters').html(data);
       }
     });
   }
  loadData();
//code to cancel voter request
$(document).on("click",'#cancel-btn',function(){
    var vid=$(this).data("id");
    var eid=$(this).data("eid");
    if(confirm('Are you sure to remove this record ? ')){
    $.ajax({
      url : "delete_accept_voter.php",
      type : "POST",
      data : {delete_vid:vid,delete_eid:eid},
      success : function(data){
        loadData();
      }
    });
   }
 });
});
</script>
  </body>
</html>
