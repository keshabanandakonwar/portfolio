<!----------ready-------------->
<html>
  <head>
    <title>course</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <style media="screen">
      #model{
        background: rgba(0, 0, 0, 0.9);
        position: fixed;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        z-index: 100;
        display: none;
      }
      #model-form{
        background: #fff;
        width: 40%;
        position: relative;
        top: 20%;
        left: calc(50%-25%);
        margin-left: 35%;
        padding: 15px;
        border-radius: 5px;
      }
      #close-btn{
        background-color: red;
        color: white;
        width: 30px;
        height: 30px;
        text-align: center;
        border-radius: 50%;
        position: absolute;
        top: 17%;
        margin-left: 74%;
        cursor: pointer;
        box-shadow: 0px 0px 8px 5px white;
      }
      #close-btn:hover{
        box-shadow: 0px 0px 8px 9px green;
      }
    </style>
  </head>
  <body>
 <?php include('header.php'); ?>
    <div class="container">
      <div class="row">
        <div class="col-md-10" style="margin-left:20%;">
          <form class="bg-light" id="table">
            <table class=" table table-striped text-center table-bordered" style="width:100%">
              <thead>
                <tr class="bg-dark ">
                  <th colspan="8" class="text-center"><h2 class="text-white p-0 m-0">ADD COURSE</h2><br>
                    <i id="message" class="text-danger"></i>
                  </th>
                </tr>
              </thead>
              <tbody class="ml-3 bg-light">
                <tr>
                  <th>Select Department / School : </th>
                  <td>
                    <select class="form-control" id="department-id">
                      <option disabled selected>Select Department/school</option>
                      <?php
                        $qry1="SELECT * FROM department";
                        $run1=mysqli_query($con,$qry1);
                        while($data1=mysqli_fetch_array($run1)){
                      ?>
                      <option value="<?php echo $data1['department_id'] ?>"><?php echo $data1['department_name'] ?></option>
                    <?php } ?>
                    </select>
                  </td>
                </tr>
                <tr>
                  <th>Course Name</th>
                  <td><input type="text" name="course_name" placeholder="Enter course name here" class="form-control" required id="course-name"></td>
                </tr>
                <tr>
                  <th colspan="8"><input type="button" id="add-new-course" value="ADD COURSE" class="btn btn-success m-1"></th>
                </tr>
              </tbody>
            </table>
          </form>
        </div>
        <div class="col-md-10" id="course-table" style="margin-left:20%;"></div>


        </div>
      </div>
  </div>
      <div class="row">
        <div class="col-12"  id="model">
          <button id="close-btn">X</button>
          <table class="table-bordered table-striped" id="model-form">

          </table>
        </div>
      </div>

    <script type="text/javascript" src="../css/jquery-3.2.1.min.js"></script>
    <script type="text/javascript">
      $(document).ready(function(){
//---------- load course details ---------ready-----
        function loadData(){
          $.ajax({
            url : "fetch_courses.php",
            type : "get",
            success : function(data){
              $('#course-table').html(data);
            }
          });
        }
        loadData();
//------------add new course-------ready--
        $('#add-new-course').on('click',function(){
          var department_id=$('#department-id').val();
          var course_name = $('#course-name').val();
          if (course_name.length=='' || course_name[0]==' ') {
            alert('Please enter valid data.');
            exit();
          }
          $.ajax({
            url : "add_script.php",
            type : "post",
            data : {
              department_id :department_id,
              add_new_course : course_name
            },
            success : function(data){
              $('#message').html(data);
              loadData();
              $('#table').trigger('reset');
            }
          });
        });

//-----------update course status------ready-----
    $(document).on("click","#status",function(){
      var course_id = $(this).data("id");
      $.ajax({
        url : "update_status.php",
        type : "post",
        data : {course_id : course_id},
        success : function(data){
        loadData();
        }
      });
    });
//----------edit course details form---------ready---
   $(document).on("click",'#edit-course',function(){
      $('#model').show();
      var course_id = $(this).data("id");
      $.ajax({
        url : "edit_data.php",
        type : "POST",
        data : {edit_course_id : course_id},
        success : function(data){
             $('#model-form').html(data);
        }
      });
    });
//--------hide model box----------
    $('#close-btn').on("click",function(){
      $('#model').hide();
    });
//---------save updated course data--------ready-----
    $(document).on("click","#edit-course-btn",function(){
      var course_id=$('#course-id').val();
      var course_name=$('#edit-course-value').val();
      if (course_name.length=='' || course_name[0]==' ') {
        alert('Please enter valid data.');
        exit();
      }
      $.ajax({
        url : "edit_course_script.php",
        type : "POST",
        data : {
                  course_id : course_id,
                  course_name : course_name
               },
        success : function(data){
          alert(data);
          $('#model').hide();
          loadData();
        }
      });
    });
});
    </script>
  </body>
</html>
