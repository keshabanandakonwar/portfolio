 <?php
 //------------checked-----------
include("connection.php");
$depertment_id=mysqli_real_escape_string($con,$_POST['depertment_id']);
$course=mysqli_real_escape_string($con,$_POST['course_name']);
$qry2="INSERT INTO courses(depertment_id,course_name,course_status)VALUES('$depertment_id','$course','1')";
$run2=mysqli_query($con,$qry2);
if($run2){
  echo "New course inserted successfully.";
  exit();
}
 ?>
