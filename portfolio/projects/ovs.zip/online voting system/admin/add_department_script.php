<?php
//---------checked--------construction--
include('connection.php');
$depertment=$_POST['department_name'];
 $qry="INSERT INTO department(depertment_name,department_status)VALUES('$depertment','1')";
 $run=mysqli_query($con,$qry);
 if($run){
   echo "New Department / School created successfully.";
 }
?>
