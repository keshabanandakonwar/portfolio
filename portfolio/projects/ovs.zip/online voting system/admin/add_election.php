<!-------------ready--->
<html>
  <head>
    <title>add election</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <style media="screen">
      #model{
        background: rgba(0, 0, 0, 0.9);
        position: fixed;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        z-index: 100;
        display: none;
      }
      #model-form{
        background: #fff;
        width: 40%;
        position: relative;
        top: 20%;
        left: calc(50%-25%);
        margin-left: 35%;
        padding: 15px;
        border-radius: 5px;
      }
      #close-btn{
        background-color: red;
        color: white;
        width: 30px;
        height: 30px;
        text-align: center;
        border-radius: 50%;
        position: absolute;
        top: 17%;
        margin-left: 74%;
        cursor: pointer;
        box-shadow: 0px 0px 8px 5px white;
      }
      #close-btn:hover{
        box-shadow: 0px 0px 8px 9px green;
      }
    </style>
  </head>
  <body>
 <?php include('header.php'); ?>
    <div class="container">
      <div class="row">
        <div class="col-md-10" style="margin-left:20%;">
          <form class="bg-light" id="table">
            <table class="text-center table-bordered" style="width:100%">
              <thead>
                <tr class="bg-dark ">
                  <th colspan="8" class="text-center"><h2 class="text-white">ADD ELECTION</h2><br>
                    <p id="message" class="text-danger"></p>
                  </th>
                </tr>
              </thead>
              <tbody class="ml-3 bg-light">
                <tr>
                  <th colspan="1">Election Id</th>
                  <td colspan="7"><input type="text" name="election_id" value="<?php echo $id='election/'.date('Y/m/d')."/".rand(1,10)?>" class="form-control" readonly id="id"></td>
                </tr>
                <tr>
                  <th>Election Name</th>
                  <td><input type="text" name="election_name" placeholder="Enter election name here" class="form-control" required id="election_name"></td>
                </tr>
                <tr>
                  <th>Election Date</th>
                  <td>
                     <input type="hidden" name="" id='current-date' value="<?php echo $date=date('Y-m-d')?>">
                     <input type="Date" name="election_date" class="form-control" required id="date">
                  </td>
                  <th>Election Time upto:</th>
                  <td><input type="time" name="election_time" class="form-control" required id="time"> </td>
                </tr>
                <tr>
                  <th colspan="8"><input type="button" id="add_new_election" value="ADD ELECTION" class="btn btn-success m-1"></th>
                </tr>
              </tbody>
            </table>
          </form>
          <table class="table table-bordered mt-5 mb-4 table-striped table-hover">
            <tr class='bg-dark text-center'>
               <th class="text-white">Sl No</th>
               <th class="text-white">Election Id</th>
               <th class="text-white">Election Name</th>
               <th class="text-white">Election Date</th>
               <th class="text-white">Election Time(Upto)</th>
               <th class="text-white">Action</th>
            </tr>
            <tbody id="election_table">

            </tbody>
          </table>


        </div>
      </div>
  </div>
      <div class="row">
        <div class="col-12"  id="model">
          <button id="close-btn">X</button>
          <table class="table-bordered table-striped" id="model-form">

          </table>
        </div>
      </div>
    <script type="text/javascript" src="../css/jquery-3.2.1.min.js"></script>
    <script type="text/javascript">
      $(document).ready(function(){
//--------- load election data --------ready------
        function loadData(){
          $.ajax({
            url : "fetch_election.php",
            type : "post",
            success : function(data){
              $('#election_table').html(data);
            }
          });
        }
        loadData();
//------- add new election----------ready
        $('#add_new_election').on('click',function(){
          var election_id = $('#id').val();
          var election_name = $('#election_name').val();
          var election_date = $('#date').val();
          var election_time = $('#time').val();
         if (election_name=='' || election_name[0]==' ') {
            alert('Please enter valid election name.');
            exit();
          }
          if(election_date=='' || election_date[0]==' '){
            alert('Please enter valid election date.');
            exit();
          }
          $.ajax({
            url : "add_election_script.php",
            type : "post",
            data : {
              election_id : election_id,
              election_name : election_name,
              election_date : election_date,
              election_time : election_time
            },
            success : function(data){
              $('#message').html(data);
              loadData();
              $('#table').trigger('reset');
            }
          });
        });

//-----update election status-----ready
    $(document).on("click","#status",function(){
      var election_id = $(this).data("id");
      $.ajax({
        url : "update_status.php",
        type : "post",
        data : {election_id : election_id},
        success : function(data){
        loadData();
        }
      });
    });
//--------edit election details form----ready
   $(document).on("click",'#edit-election',function(){
      $('#model').show();
      var election_id = $(this).data("electionid");
      $.ajax({
        url : "edit_data.php",
        type : "POST",
        data : {edit_election_id : election_id},
        success : function(data){
             $('#model-form').html(data);
        }
      });
    });

//--------hide model box------ready
    $('#close-btn').on("click",function(){
      $('#model').hide();
    });
//save updated data-----ready
    $(document).on("click","#edit-btn",function(){
      var electionid=$('#electionid').val();
      var editElectionName=$('#editElectionName').val();
      var editElectionDate=$('#editElectionDate').val();
      var editElectionTime=$('#editElectionTime').val();
      var currentDate=$('#current-date').val();
      if (editElectionDate<currentDate){
        alert('Please enter valid date');
        exit();
      }
      if(editElectionName[0]==' ' || editElectionDate==''){
        alert("Please enter valid data.");
        exit();
      }
      $.ajax({
        url : "edit_election_script.php",
        type : "POST",
        data : {
                  electionid : electionid,
                  editElectionName : editElectionName,
                  editElectionDate : editElectionDate,
                  editElectionTime : editElectionTime
               },
        success : function(data){
          alert(data);
          $('#model').hide();
          loadData();
        }
      });
    });
//----------check whether the date is valid or not-------ready
    $('#date').on('change',function(){
      var date=$('#date').val();
      var currentDate=$('#current-date').val();
      if (date<currentDate){
        alert('Please enter valid date');
      }
    });
});
    </script>
  </body>
</html>
