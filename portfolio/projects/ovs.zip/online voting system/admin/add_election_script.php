<?php
//------------ready
 include('connection.php');
   $election_id=mysqli_real_escape_string($con,$_POST['election_id']);
   $election_name=mysqli_real_escape_string($con,$_POST['election_name']);
   $election_date=mysqli_real_escape_string($con,$_POST['election_date']);
   $election_time=mysqli_real_escape_string($con,$_POST['election_time']);
   $qry1="SELECT * FROM election WHERE election_name='$election_name' AND election_date='$election_date'";
   $run1=mysqli_query($con,$qry1);
   $check=mysqli_num_rows($run1);
   if($check>0){
     echo 'Sorry,this election id already exist';
     exit();
   }
   $qry2="INSERT INTO election(election_id,election_name,election_date,time_upto,election_status)VALUES('$election_id','$election_name','$election_date','$election_time','1')";
   $run2=mysqli_query($con,$qry2);
   if($run2){
     echo '
            New election created successfully.<br>
            <tt class="text-primary">Please refresh the page before add new election records</tt>
          ';
     exit();
   }
?>
