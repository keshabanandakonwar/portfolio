<!-------------->
<html>
  <head>
    <title>positions </title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <style>
      #model{
        background: rgba(0, 0, 0, 0.9);
        position: fixed;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        z-index: 100;
        display: none;
      }
      #model-form{
        background: #fff;
        width: 40%;
        height: 5%;
        overflow-y: scroll;
        position: relative;
        top: 20%;
        margin-left: 35%;
        padding: 15px;
        border-radius: 5px;
      }
      #close-btn{
        background-color: red;
        color: white;
        width: 30px;
        height: 30px;
        text-align: center;
        border-radius: 50%;
        position: absolute;
        top: 17%;
        margin-left: 74%;
        cursor: pointer;
        box-shadow: 0px 0px 8px 5px white;
      }
      #close-btn:hover{
        box-shadow: 0px 0px 8px 9px green;
      }
    </style>
  </head>
  <body>
    <?php include('header.php'); ?>
    <div class="container">
      <div class="row">
        <div class="col-md-10" style="margin-left:20%">
            <!-------- add position details----------->
          <table class="table table-striped table-bordered mb-5" id="table">
            <thead>
              <tr>
                <th colspan="4" class="text-center text-white bg-dark">ADD NEW POSITION
                     <p id="message" class="text-danger pt-2"></p>
                </th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th>Select Election</th>
                <td>
                  <Select class="form-control" id="election_id">
                    <option selected disabled>Select Election</option>
                    <?php
                       include('connection.php');
                       $qry1="SELECT * FROM election WHERE election_status='1' ORDER BY sl_no DESC";
                       $run1=mysqli_query($con,$qry1);
                       while($row=mysqli_fetch_array($run1)){
                    ?>
                        <option value="<?php echo $row['election_id']?>"><?php echo $row['election_name']?></option>
                  <?php } ?>

                </select>
                </td>
                 <th>Enter Position Name</th>
                <td><input type="text" placeholder="Enter new position name" id="position_name" class="form-control" required> </td>
              </tr>
              <tr>
                <th style="vertical-align:middle">Add Position Eligibility</th>
                <td colspan="3">
                  <p id="eligibility"></p>
                <!-- <button type="button" class="btn btn-block bg-primary text-white" id="add-row-btn" name="button">Add Row</button><br>--->
                  <textarea class="form-control" rows="4" cols="40" required id="eligibility-data" placeholder="Enter post eligibility"></textarea>
                <!--    <div class="form-group" id="new-row">
                      <p id="dynamic-row"><input type="text" style="width:85%" name="" id="eligibility-data" value=""><button type="button" style="width:15%;background-color:red;color:white" id="add-row-btn" name="button">ADD</button></p>
                    </div>
                    <button type="button" name="button">Add</button>--->
                </td>
              </tr>
              <tr>
                <th colspan="4" class="text-center"><input id="add_new_position" type="submit" value="ADD POSITION" class="btn btn-success"> </th>
              </tr>
            </tbody>
          </table>


     <!------------code to show positions details--------------------->
          <table class="table table-bordered mt-5 mb-4 table-striped table-hover">
            <tr class='bg-dark text-center'>
               <th class="text-white">Sl No</th>
               <th class="text-white">Election Details</th>
                 <th class="text-white">Position Name</th>
            </tr>
            <tbody id="position_table">

            </tbody>
          </table>

        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-12"  id="model">
        <button id="close-btn">X</button>
        <table class="table-bordered table-striped" id="model-form" style='border:1px double red;box-shadow:0px 0px 9px 7px lightblue;'>

        </table>

      </div>
    </div>
    <script type="text/javascript" src="../css/jquery-3.2.1.min.js"></script>
    <script type="text/javascript">
      $(document).ready(function(){
        //------ load position details-----ready
        function loadData(){
          $.ajax({
            url : "fetch_positions.php",
            type : "post",
            success : function(data){
              $('#position_table').html(data);
            }
          });
        }
        loadData();
    //----------- add new position---------ready
        $('#add_new_position').on('click',function(){
          var election_id = $('#election_id').val();
          var position_name = $('#position_name').val();
          var eligibility=$('#eligibility-data').val();
        //  var eligibility = $('#add-eligibility').val();
          $.ajax({
            url : "add_position_script.php",
            type : "post",
            data : {
              election_id : election_id,
              position_name : position_name,
              eligibility : eligibility
            },
            success : function(data){
              $('#message').html(data);
              loadData();
            }
          });
        });
    //----------update position status-------ready
        $(document).on("click","#status",function(){
          var position_id = $(this).data("id");
          $.ajax({
            url : "update_status.php",
            type : "post",
            data : {position_id : position_id},
            success : function(data){
              loadData();
            }
          });
        });
   //------- edit position details form--------ready
   $(document).on("click",'#edit-position-btn',function(){
      $('#model').show();
      var position_id = $(this).data("id");
      $.ajax({
        url : "edit_data.php",
        type : "POST",
        data : {edit_position_id : position_id},
        success : function(data){
             $('#model-form').html(data);
        }
      });
    });
    //---- hide model box
    $('#close-btn').on("click",function(){
      $('#model').hide();
    });
//---------- save updated position data-------ready
    $(document).on("click","#edit-btn",function(){
      var positionid=$('#positionid').val();
      var editPositionName=$('#editPositionName').val();
      var editPositionEligibility=$('#editPositionEligibility').val();
      if(editPositionName[0]==' ' || editPositionName==''){
        alert('Please enter valid data.');
        exit();
      }
      $.ajax({
        url : "edit_position_script.php",
        type : "POST",
        data : {
                  positionid : positionid,
                  editPositionName : editPositionName,
                  editPositionEligibility : editPositionEligibility
               },
        success : function(data){
          alert(data);
          $('#model').hide();
          loadData();
        }
      });
    });
//------show position eligibility---------ready
      $(document).on("click","#eligibility",function(){
        var position_id=$(this).data("id");
        $('#model').show();
        $.ajax({
          url : "position_eligibility.php",
          type : "GET",
          data : {position_id : position_id},
          success : function(data){
               $('#model-form').html(data);
          //  alert(data);
          }
        });
      });
//------------------add row------
/* $('').on('click',function(){
    newRowAdd='<p id="dynamic-row"><input type="text" id="eligibility-data" style="width:85%;margin-top:5px" name="" value=""><button type="button" id="add-row-btn" style="width:15%;background-color:red;color:white;margin-top:5px" name="button">ADD</button></p>';
    $('#new-row').append(newRowAdd);
 });*/
//------remove row-----
 $('#add-row-btn').on('click',function(){
   var eligibility_data=$('#eligibility-data').val();
   alert(eligibility_data);
   $('#eligibility').append(eligibility_data);
   $('#eligibility-data').reset();
 });

});
    </script>
  </body>
</html>
