<?php
//-------ready
 include('connection.php');
   $election_id=mysqli_real_escape_string($con,$_POST['election_id']);
   $position_name=mysqli_real_escape_string($con,$_POST['position_name']);
   $eligibility=mysqli_real_escape_string($con,$_POST['eligibility']);
   if($election_id==''){
     echo "Please select election name.";
     exit();
   }
   if($position_name==''){
     echo "Please enter position name.";
     exit();
   }
   if($eligibility==''){
     echo "Please enter position eligibility.";
     exit();
   }
   $qry1="SELECT * FROM positions WHERE election_id='$election_id' AND position_name='$position_name'";
   $run1=mysqli_query($con,$qry1);
   $check=mysqli_num_rows($run1);
   if($check>0){
     echo 'Sorry,this position already exist';
     exit();
   }
   $qry2="INSERT INTO positions(election_id,position_name,eligibility,position_status)VALUES('$election_id','$position_name','$eligibility','1')";
   $run2=mysqli_query($con,$qry2);
   if($run2){
     echo '  New position created successfully.';
     exit();
   }
?>
