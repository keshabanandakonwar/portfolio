<?php
include('connection.php');
//---------add new department--------ready--
if(isset($_POST['add_new_department'])){
  $department=$_POST['add_new_department'];
 $qry="INSERT INTO department(department_name,department_status)VALUES('$department','1')";
 $run=mysqli_query($con,$qry);
 if($run){
   echo "New Department / School created successfully.";
 }
}
//-----add new course------ready--
if(isset($_POST['add_new_course'])){
$department_id=mysqli_real_escape_string($con,$_POST['department_id']);
$course=mysqli_real_escape_string($con,$_POST['add_new_course']);
$qry2="INSERT INTO courses(department_id,course_name,course_status)VALUES('$department_id','$course','1')";
$run2=mysqli_query($con,$qry2);
if($run2){
  echo "New course inserted successfully.";
  exit();
}
}
?>
