<!DOCTYPE html>
<html>
  <head>
    <title>add semester</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <style>
      #model{
        background: rgba(0, 0, 0, 0.9);
        position: fixed;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        z-index: 100;
        display: none;
      }
      #model-form{
        background: #fff;
        width: 40%;
        position: relative;
        top: 20%;
        left: calc(50%-25%);
        margin-left: 35%;
        padding: 15px;
        border-radius: 5px;
      }
      #close-btn{
        background-color: red;
        color: white;
        width: 30px;
        height: 30px;
        text-align: center;
        border-radius: 50%;
        position: absolute;
        top: 17%;
        margin-left: 74%;
        cursor: pointer;
        box-shadow: 0px 0px 8px 5px white;
      }
      #close-btn:hover{
        box-shadow: 0px 0px 8px 9px green;
      }
    </style>
  </head>
  <body>
 <?php include('header.php'); ?>
    <div class="container">
      <div class="row">
        <div class="col-md-10" style="margin-left:20%;">
          <form class="bg-light" id="table">
            <table class="text-center table-bordered" style="width:100%">
              <thead>
                <tr class="bg-dark ">
                  <th colspan="8" class="text-center"><h2 class="text-white">ADD SEMESTER</h2><br>
                    <p id="message" class="text-danger"></p>
                  </th>
                </tr>
              </thead>
              <tbody class="ml-3 bg-light">
                <tr>
                  <th>Select Course</th>
                  <td><select class="form-control" id="course-id">
                    <option disabled selected>Select course</option>
                    <?php
                    include("connection.php");
                        $qry1="SELECT * FROM courses";
                        $run1=mysqli_query($con,$qry1);
                        while($data=mysqli_fetch_array($run1)){
                    ?>
                    <option value="<?php echo $data['course_id']?>"><?php echo $data['course_name']?></option>
                  <?php } ?>
                    </select>
                  </td>
                </tr>
                <tr>
                  <th>Semester Name</th>
                  <td><input type="text" name="semester_name" placeholder="Enter semester name here" class="form-control" required id="semester-name"></td>
                </tr>
                <tr>
                  <th colspan="8"><input type="button" id="add-new-semester" value="ADD SEMESTER" class="btn btn-success m-1"></th>
                </tr>
              </tbody>
            </table>
          </form>
          <div id="course-table"></div>
        </div>
      </div>
  </div>
      <div class="row">
        <div class="col-12"  id="model">
          <button id="close-btn">X</button>
          <table class="table-bordered table-striped" id="model-form">

          </table>
        </div>
      </div>
    <script type="text/javascript" src="../css/jquery-3.2.1.min.js"></script>
    <script type="text/javascript">
      $(document).ready(function(){
//----------load course details ----------ready----
        function loadData(){
          $.ajax({
            url : "fetch_semesters.php",
            type : "get",
            success : function(data){
              $('#course-table').html(data);
            }
          });
        }
        loadData();
//------------add new semester-------ready--
  $('#add-new-semester').on('click',function(){
          var course_id = $('#course-id').val();
          var semester_name = $('#semester-name').val();
          if(semester_name=='' || semester_name[0]==' '){
            alert('Please enter valid data.');
            exit();
          }
          $.ajax({
            url : "add_semester_script.php",
            type : "post",
            data : {
              course_id : course_id,
              semester_name : semester_name
            },
            success : function(data){
              $('#message').html(data);
              loadData();
              $('#table').trigger('reset');
            }
          });
        });

//-----------update semester status--------ready---
    $(document).on("click","#status",function(){
      var semester_id = $(this).data("id");
      $.ajax({
        url : "update_status.php",
        type : "post",
        data : {semester_id : semester_id},
        success : function(data){
        loadData();
        }
      });
    });
//------------edit semester Details form---------ready-
$(document).on("click","#edit-semester",function(){
  $('#model').show();
  var semesterId = $(this).data("id");
   $.ajax({
     url : "edit_data.php",
     type : "POST",
     data : {edit_semester_id : semesterId},
     success : function(data){
          $('#model-form').html(data);
     }
   });
 });
//---------save updated course data--------ready-----
     $(document).on("click","#edit-semester-btn",function(){
       var semester_name=$('#semester-semester-value').val();
       var semester_id=$('#edit-semester-btn').data('id');
       if (semester_name.length=='' || semester_name[0]==' ') {
         alert('Please enter valid data.');
         exit();
       }
       $.ajax({
         url : "edit_semester_script.php",
         type : "POST",
         data : {
                   semester_id : semester_id,
                   semester_name : semester_name
                },
         success : function(data){
           alert(data);
           $('#model').hide();
           loadData();
         }
       });
     });
//--------code to hide model box----------
 $('#close-btn').on("click",function(){
      $('#model').hide();
    });
});
    </script>
  </body>
</html>
