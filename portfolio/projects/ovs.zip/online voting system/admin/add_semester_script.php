 <?php
 //----------ready
include("connection.php");
$course_id=mysqli_real_escape_string($con,$_POST['course_id']);
$semester_name=mysqli_real_escape_string($con,$_POST['semester_name']);
if($course_id==''){
  echo "Please select course";
  exit();
}
$qry1="INSERT INTO semester(course_id,semester_name,semester_status)VALUES('$course_id','$semester_name','1')";
$run1=mysqli_query($con,$qry1);
if($run1){
  echo "New semester created successfully.";
  exit();
}
 ?>
