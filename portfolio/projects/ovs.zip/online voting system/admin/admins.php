<!---------ready--------------->
<html>
  <head>
    <title>Sub Admins</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <style media="screen">
    .field{
      display: none;
    }
      #model{
        background: rgba(0, 0, 0, 0.9);
        position: fixed;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        z-index: 100;
        display: none;
      }
      #model-form{
        background: #fff;
        width: 40%;
        position: relative;
        top: 20%;
        left: calc(50%-25%);
        margin-left: 35%;
        padding: 15px;
        border-radius: 5px;
      }
      #close-btn{
        background-color: red;
        color: white;
        width: 30px;
        height: 30px;
        text-align: center;
        border-radius: 50%;
        position: absolute;
        top: 17%;
        margin-left: 74%;
        cursor: pointer;
        box-shadow: 0px 0px 8px 5px white;
      }
      #close-btn:hover{
        box-shadow: 0px 0px 8px 9px green;
      }
    </style>
  </head>
  <body>
 <?php include('header.php'); ?>
    <div class="container">
      <div class="row">
        <div class="col-md-10" style="margin-left:20%;">
          <form class="bg-light" id="table" method="post">
            <table class=" table table-striped text-center table-bordered" style="width:100%">
              <thead>
                <tr class="bg-dark ">
                  <th colspan="8" class="text-center"><h2 class="text-white p-0 m-0">ADD NEW ADMIN</h2><br>
                    <i id="message" class="text-danger"></i>
                  </th>
                </tr>
              </thead>
              <tbody class="ml-3 bg-light">
                <tr>
                  <th>Select Department / School : </th>
                  <td>
                    <select class="form-control" name="department" required id="department">
                      <option disabled selected>Select Department/school</option>
                      <?php
                        $qry1="SELECT * FROM department ORDER BY department_id DESC";
                        $run1=mysqli_query($con,$qry1);
                        while($data1=mysqli_fetch_array($run1)){
                      ?>
                      <option value="<?php echo $data1['department_id'] ?>"><?php echo $data1['department_name'] ?></option>
                    <?php } ?>
                    </select>
                  </td>
                </tr>
                <tr>
                  <th>Select course : </th>
                  <td>
                    <select class="form-control" name="course" required id="course">
                    </select>
                  </td>
                </tr>
                <tr>
                  <th>Admin Name</th>
                  <td><input type="text" name="name" placeholder="Enter admin name" class="form-control" required id="admin-name"></td>
                </tr>
                <tr>
                  <th>Admin Email</th>
                  <td><input type="email" name="email" placeholder="Admin email id" class="form-control" required id="admin-email"></td>
                </tr>
                <tr>
                  <th>Admin password</th>
                  <td><input type="password" name="password" class="form-control" required id="admin-password"></td>
                </tr>
                <tr>
                  <th colspan="8"><input type="submit" name="submit" id="add-new-course" value="Submit" class="btn btn-success m-1"></th>
                </tr>
              </tbody>
            </table>
          </form>
          <table class="table table-bordered mt-5 mb-4 table-striped table-hover">
            <tr class='bg-dark text-center'>
               <th class="text-white">Sl No</th>
               <th class="text-white">School / Department</th>
               <th class="text-white">Course</th>
               <th class="text-white">Sub Admin</th>
                <th class="text-white">Action</th>
            </tr>
            <tbody id="admin-table">

            </tbody>
          </table>


        </div>
      </div>
  </div>
      <div class="row">
        <div class="col-12"  id="model">
          <button id="close-btn">X</button>
          <table class="table-bordered table-striped" id="model-form">

          </table>
        </div>
      </div>

<script type="text/javascript" src="../css/jquery-3.2.1.min.js"></script>
<script>
$(document).ready(function(){
  //---------load sub admins----ready----
  function loadData(){
    $.ajax({
      url : 'sub_admin_script.php',
      type : 'get',
      success : function(data){
        $('#admin-table').html(data);
      }
    });
  }
  loadData();
//--------fetch dependent courses-------ready--
$('#department').on('change',function(){
  var department=$(this).val();
  $.ajax({
    url : "../fetch_dependent_course.php",
    type : "post",
    data : {dept_id: department},
    success : function(data){
      $('#course').html(data);
    }
  });
});
//------delete sub admin------ready--
$(document).on('click','#delete-admin',function(){
  var sl_no=$(this).data('id');
  if(confirm('Are you sure to remove this record ? ')){
  $.ajax({
    url : "delete_record.php",
    type : "POST",
    data : {subadmin_id : sl_no},
    success : function(data){
      loadData();
    }
  });
  }
});
//-------update sub admin account status-----ready---
$(document).on('click','#status',function(){
  var slno=$(this).data('id');
  $.ajax({
    url : 'update_status.php',
    type : 'post',
    data : {subadmin_id : slno},
    success : function(data){
      loadData();
    }
  });
});
//---------show edit admin details form----ready-----
$(document).on('click','#edit-subadmin',function(){
  var sl_no = $(this).data('id');
  $('#model').show();
  $.ajax({
    url : 'edit_data.php',
    type : 'post',
    data : {subadmin_id : sl_no},
    success : function(data){
      $('#model-form').html(data);
    }
  });
});
//--------edit sub admin details------ready----
$(document).on('click','#edit-admin-btn',function(){
  var admin_id=$(this).data('id');
  var name=$('#name').val();
  if(name.length=='' || name[0]==' '){
    alert('Please enter valid admin name.');
    exit();
  }
  var email=$('#email').val();
  if(email.length==''){
    alert('Please enter valid email id.');
    exit();
  }
  $.ajax({
    url : 'edit_subadmin_script.php',
    type : 'post',
    data : {admin_id:admin_id, name:name, email:email},
    success : function(data){
      alert(data);
      $('#model').hide();
      loadData();
    }
  });
});
//-----hide model box----ready---
$('#close-btn').on("click",function(){
      $('#model').hide();
    });
});
</script>
  </body>
</html>
<?php
//--------add new admin ------------ready------
 include('connection.php');
 if(isset($_POST['submit'])){
   $name=$_POST['name'];
   $email=$_POST['email'];
   $password=$_POST['password'];
   $hash_pass=md5($password);
   $department=$_POST['department'];
   $course=$_POST['course'];
   if($name=='' || $email=='' || $department=='' || $course=='' || $password==''){
     echo "<script>alert('All fields are required.')</script>";
     echo "<script>window.open('admins.php','_self')</script>";
     exit();
   }
   $qry="SELECT * FROM admin WHERE department_id='$department' AND course_id='$course'";
   $run=mysqli_query($con,$qry);
   if(mysqli_num_rows($run)>0){
   echo "<script>alert('Only one admin allow against a course.')</script>";
   echo "<script>window.open('admins.php','_self')</script>";
   exit();
   }
 $qry2="INSERT INTO admin(admin_type,department_id,course_id,admin_name,admin_email,admin_password,admin_status)
        VALUES('controller','$department','$course','$name','$email','$hash_pass',1)";
 $run2=mysqli_query($con,$qry2);
 if($run2){
   echo "<script>alert('New sub admin account created successfully.')</script>";
   echo "<script>window.open('admins.php','_self')</script>";
   exit();
 }
 }
?>
