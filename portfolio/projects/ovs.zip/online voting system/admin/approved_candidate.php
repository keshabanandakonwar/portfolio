<!----ready---------->
<html>
<head>
    <title>Approved Candidate</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <style media="screen">
      #model{
        background: rgba(0, 0, 0, 0.9);
        position: fixed;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        z-index: 100;
        display: none;
      }
      #model-form{
        background: #fff;
        width: 50%;
        position: relative;
        top: 4%;
        left: calc(50%-25%);
        margin-left: 25%;
        padding: 15px;
        border-radius: 5px;
      }
      #close-btn{
        background-color: red;
        color: white;
        width: 30px;
        height: 30px;
        text-align: center;
        border-radius: 50%;
        position: absolute;
        top: 5%;
        margin-left: 75%;
        cursor: pointer;
        box-shadow: 0px 0px 8px 5px white;
      }
      #close-btn:hover{
        box-shadow: 0px 0px 8px 9px green;
      }
    </style>
</head>
  <body>
    <?php include('header.php'); ?>
    <div class="container">
      <div class="row">
        <div class="col-md-10" style="margin-left:20%">
          <table id="search-election" class="table table-border">
            <tr class="text-center bg-danger text-white">
              <th>Search Election</th>
            </tr>
            <tr>
              <td>
                 <select class="form-control" id="election_id">
                    <option disabled selected class="text-center p-2">Select Election</option>
                    <?php
                       include('connection.php');
                       $qry2="SELECT * FROM election WHERE election_status='1'";
                       $run2=mysqli_query($con,$qry2);
                       while($data2=mysqli_fetch_array($run2)){
                    ?>
                    <option value="<?php echo $data2['election_id']?>" class="text-center text-uppercase"><?php echo $data2['election_name'];?></option>
                  <?php } ?>
                 </select>
             </td>
            </tr>
          </table>
          <table id="candidates" class="table table-bordered table-striped"></table>
        </div>
      </div>
      <div class="row">
        <div class="col-12"  id="model">
          <button id="close-btn">X</button>
          <table class="table-striped" id="model-form">

          </table>
        </div>
      </div>
    </div>
<script type="text/javascript" src="../css/jquery-3.2.1.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
//---------- load election data -------------ready-
$('#election_id').on("change",function(){
    var election_id = $('#election_id').val();
    $.ajax({
               url : "load_approved_candidate.php",
               type : "post",
               data : {election_id : election_id},
               success : function(data){
                 $('#candidates').html(data);
               }
    });
});
//--------- delete candidate request-----------ready
$(document).on("click","#delete-candidate",function(){
      var vid=$(this).data("vid");
      var eid=$(this).data("eid");
      if(confirm('Are you sure to reject this candidate ? ')){
      $.ajax({
        url : "delete_record.php",
        type : "post",
        data : {delete_candidate_id:vid,delete_election_id:eid},
        success : function(data){
          $('#candidates').html('Record deleted successfully.Refresh the page and search again.');
        }
      });
     }
});
//--------- view candidate details----------ready
$(document).on("click","#candidate-details",function(){
    var vid=$(this).data("vid");
    var eid=$(this).data("eid");
    $('#model').show();
    $.ajax({
      url : "view_details.php",
      type : "get",
      data : {candidate_id : vid,election_id:eid},
      success : function(data){
          $('#model-form').html(data);
      }
    });
});
//-------- hide model box
$('#close-btn').on("click",function(){
     $('#model').hide();
});
});
</script>
  </body>
</html>
