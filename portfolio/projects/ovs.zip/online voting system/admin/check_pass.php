<?php
//-----------ready
include('connection.php');
 $old_password=$_POST['old_password'];
 $hash_pass=md5($old_password);
 $admin_email=$_POST['admin_email'];
 $qry="SELECT * FROM admin WHERE admin_password='$hash_pass' AND admin_email='$admin_email'";
 $run=mysqli_query($con,$qry);
 $check=mysqli_num_rows($run);
 if($check<1){
   echo "0";
 }else{
   echo "1";
 }
?>
