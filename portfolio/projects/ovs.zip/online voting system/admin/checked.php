manage sub admin----------done
department/school----------done
add course----------------done
add semester---------------done
add election--------------done
un-approve candidate-------done
approved candidate---------done
result--------------------done<may be>
voter's query-------------done
admin's profile------------done
admin login------------done
manage voters-----------------
positions-----------------
