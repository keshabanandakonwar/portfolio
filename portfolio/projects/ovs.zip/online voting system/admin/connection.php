<?php
 $con=mysqli_connect("localhost","root","","votingSystem") OR die('connection fail');
?>
