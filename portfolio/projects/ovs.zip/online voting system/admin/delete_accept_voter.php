<?php
include('connection.php');
if(isset($_POST['delete_vid'])){
  $qry="DELETE FROM vote WHERE voter_id='{$_POST['delete_vid']}' AND election_id='{$_POST['delete_eid']}'";
  $run=mysqli_query($con,$qry);
}
?>
