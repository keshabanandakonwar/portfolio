<?php
 include('connection.php');

//delete approved candidate-------ready
    if(isset($_POST['delete_candidate_id'])){
    $qry1="DELETE FROM candidate WHERE voter_id='{$_POST['delete_candidate_id']}' AND election_id='{$_POST['delete_election_id']}'";
    $run1=mysqli_query($con,$qry1);
    $row=mysqli_fetch_array($run1);
    echo "ok";
   }
//-------delete candiate request--------ready
if(isset($_POST['delete_unAppCandidate_id'])){
  $qry1="DELETE FROM candidate WHERE voter_id='{$_POST['delete_unAppCandidate_id']}' AND election_id='{$_POST['delete_unAppElection_id']}'";
  $run1=mysqli_query($con,$qry1);
}
//--------delete sub admin record-----ready-----
if(isset($_POST['subadmin_id'])){
  $qry="DELETE  FROM admin WHERE sl_no='{$_POST["subadmin_id"]}'";
  $run=mysqli_query($con,$qry);
}
?>
