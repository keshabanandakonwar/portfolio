<?php
//---------ready-----------
 include('connection.php');
 $course_id=mysqli_real_escape_string($con,$_POST['course_id']);
 $course_name=mysqli_real_escape_string($con,$_POST['course_name']);
 $qry="UPDATE courses SET course_name='$course_name' WHERE course_id='$course_id'";
 $run=mysqli_query($con,$qry);
 if($run){
   echo "Record updated successfully.";
   exit();
 }
?>
