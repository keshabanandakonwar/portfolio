<?php
include('connection.php');
//--------edit sub admin details form--------ready--------
if(isset($_POST['subadmin_id'])){
  $qry1="SELECT * FROM admin WHERE sl_no='{$_POST['subadmin_id']}'";
  $run1=mysqli_query($con,$qry1);
  $result=mysqli_fetch_array($run1);
  if($result){
    $output="  <tr>
                  <th colspan='2' class='bg-primary text-white p-2 text-center'>Edit Sub Admin Details</th>
               </tr>";
               $qry2="SELECT * FROM department WHERE department_id='{$result["department_id"]}'";
               $run2=mysqli_query($con,$qry2);
               $data=mysqli_fetch_array($run2);
    $output.=" <tr>
                  <th> School / Department : </th>
                  <td>
                    <input type='text' readonly class='form-control text-uppercase' value='{$data['department_name']}'>
                  </td>
               </tr>
               <tr>
                  <th> Admin Type : </th>
                  <td>
                    <input type='text' readonly class='form-control text-uppercase' value='{$result['admin_type']}'>
                  </td>
               </tr>
               <tr>
                  <th> Name : </th>
                  <td>
                    <input type='text' id='name' class='form-control' value='{$result['admin_name']}'>
                  </td>
               </tr>
               <tr>
                  <th> E-mail Id : </th>
                  <td>
                    <input type='email' id='email' class='form-control' value='{$result['admin_email']}'>
                  </td>
               </tr>
               <tr>
                  <th> Account Status : </th>
                  <td>";
                         if($result['admin_status']=='0'){
                           $output.="<b class='text-danger p-1'>De-Active</b>";
                         }else{
                           $output.="<b class='text-success p-1'>Active</b>";
                         }
              $output.="</p>
                  </td>
               </tr>
               ";
    $output.="<tr>
                  <th colspan='2' class='text-center'>
                    <button class='btn btn-primary input-sm' id='edit-admin-btn' data-id='{$result['sl_no']}'>EDIT</button>
                   </th>
               </tr>
            ";
  }
  echo $output;
}
//------------ edit department details form-----ready
if(isset($_POST['edit_department'])){
$qry1="SELECT * FROM department WHERE department_id='{$_POST['edit_department']}'";
$run1=mysqli_query($con,$qry1);
$result=mysqli_fetch_array($run1);
$output="  <tr>
              <th colspan='2' class='bg-primary text-white p-2 text-center'>Edit Department Details</th>
           </tr>
           <tr>
              <th>Department Name : </th>
              <td>
                <input type='hidden' id='department-id' value='{$result['department_id']}'>
                <input type='text' class='form-control' id='edit-department-value' value='{$result['department_name']}'>
              </td>
           </tr>
           <tr>
              <th colspan='2' class=' text-center'>
                <button class='btn btn-primary input-sm' id='edit-department-btn' data-departmentid='{$result['department_id']}'>EDIT</button>
               </th>
           </tr>
        ";
        echo $output;
}
//-------edit course details form-------ready
if(isset($_POST['edit_course_id'])){
$qry1="SELECT * FROM courses WHERE course_id='{$_POST['edit_course_id']}'";
$run1=mysqli_query($con,$qry1);
$result=mysqli_fetch_array($run1);
$output="  <tr>
              <th colspan='2' class='bg-primary text-white p-2 text-center'>Edit Course Details</th>
           </tr>
           <tr>
              <th>Course Name : </th>
              <td>
                <input type='hidden' id='course-id' value='{$result['course_id']}'>
                <input type='text' class='form-control' id='edit-course-value' value='{$result['course_name']}' required>
              </td>
           </tr>
           <tr>
              <th colspan='2' class=' text-center'>
                <button class='btn btn-primary input-sm' id='edit-course-btn' data-courseid='{$result['course_id']}'>EDIT</button>
               </th>
           </tr>
        ";
        echo $output;
}
//-----edit semester Details--------ready
if(isset($_POST['edit_semester_id'])){
  $qry1="SELECT * FROM semester WHERE semester_id='{$_POST['edit_semester_id']}'";
  $run1=mysqli_query($con,$qry1);
  $result=mysqli_fetch_array($run1);
  if($result){
    $output="  <tr>
                  <th colspan='2' class='bg-primary text-white p-2 text-center'>Edit Semester Details</th>
               </tr>
               <tr>
                  <th>Semester/Class Name : </th>
                  <td>
                    <input type='text' id='semester-semester-value' class='form-control' value='{$result['semester_name']}'>
                  </td>
               </tr>
               <tr>
                  <th>Semester/Class Status : </th>
                  <td>
                    <p class=' text-center'>Current Status : ";
                         if($result['semester_status']=='0'){
                           $output.="<b class='text-danger'>De-Active</b>";
                         }else{
                           $output.="<b class='text-success'>Active</b>";
                         }
              $output.="</p>
                  </td>
               </tr>
               ";
    $output.="<tr>
                  <th colspan='2' class='text-center'>
                    <button class='btn btn-primary input-sm' id='edit-semester-btn' data-id='{$result['semester_id']}'>EDIT</button>
                   </th>
               </tr>
            ";
  }
  echo $output;
}
//---------edit election data form---------ready
if(isset($_POST['edit_election_id'])){
  $election_id=$_POST['edit_election_id'];
  $qry1="SELECT * FROM election WHERE election_id='$election_id'";
  $run1=mysqli_query($con,$qry1);
  $result=mysqli_fetch_array($run1);
  $output="  <tr>
                <th colspan='2' class='bg-primary text-white p-2 text-center'>Edit Election Details</th>
             </tr>
             <tr>
                <th>Election Id : </th><td><input type='text' readonly class='form-control' id='electionid' value='{$result['election_id']}'></td>
             </tr>
             <tr>
                <th>Election Name : </th><td><input type='text' class='form-control' id='editElectionName' value='{$result['election_name']}'></td>
             </tr>
             <tr>
                <th>Election Date : </th><td><input type='date' class='form-control' id='editElectionDate' value='{$result['election_date']}'></td>
             </tr>
             <tr>
                <th>Election Time(Upto) : </th><td><input type='time' class='form-control' id='editElectionTime' value='{$result['time_upto']}'></td>
             </tr>
             <tr>
                <th colspan='2' class=' text-center'><button class='btn btn-primary input-sm' id='edit-btn' data-electionid='{$result['election_id']}'>EDIT</button></th>
             </tr>
          ";
          echo $output;
}
//----------edit position details---ready
if(isset($_POST['edit_position_id'])){
  $position_id=$_POST['edit_position_id'];
  $qry1="SELECT * FROM positions WHERE position_id='$position_id'";
  $run1=mysqli_query($con,$qry1);
  $result=mysqli_fetch_array($run1);
  $output="  <tr>
                <th colspan='2' class='bg-primary text-white p-2 text-center'>Edit Position Details</th>
             </tr>
             <tr>
                <th>Election Id : </th>
                       <td>
                         <input type='text' readonly class='form-control' value='{$result['election_id']}'>
                         <input type='hidden' id='positionid' class='form-control' value='{$result['position_id']}'>
                       </td>
             </tr>
             <tr>
                <th>Position Name : </th><td><input type='text' class='form-control' id='editPositionName' value='{$result['position_name']}'></td>
             </tr>
             <tr>
                <th colspan='2' class=' text-center'><button class='btn btn-primary input-sm' id='edit-btn' >SAVE</button></th>
             </tr>
          ";
          echo $output;
}
//------------query reply form---------ready
if(isset($_POST['query_reply_id'])){
  $qry1="SELECT * FROM query WHERE sl_no='{$_POST["query_reply_id"]}'";
  $run1=mysqli_query($con,$qry1);
  $data=mysqli_fetch_array($run1);
  $output="  <tr>
                <th colspan='2' class='bg-primary text-white p-2 text-center'>Reply Query</th>
             </tr>
             <tr>
                <th>Name :</th>
                <td>
                  <input type='hidden' value='{$data['sl_no']}' id='query-id'>
                  <input type='text' readonly class='form-control' value='{$data['name']}'>
                </td>
             </tr>
             <tr>
                <th>Email :</th><td><input type='text' class='form-control' readonly value='{$data['email']}'></td>
             </tr>
             <tr>
                <th>Message</th><td><textarea class='form-control' readonly>{$data['message']}</textarea></td>
             </tr>
             <tr>
                <th>Reply</th><td><textarea class='form-control' id='reply'></textarea></td>
             </tr>
             <tr>
                <th colspan='2' class=' text-center'><button class='btn btn-primary input-sm' id='send-reply-btn' >SEND</button></th>
             </tr>
          ";
          echo $output;
}
?>
