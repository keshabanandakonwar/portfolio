<?php
//-----------checked--------ready--
 include('connection.php');
 $department_id=mysqli_real_escape_string($con,$_POST['department_id']);
 $department_name=mysqli_real_escape_string($con,$_POST['department_name']);
 $qry="UPDATE department SET department_name='$department_name' WHERE department_id='$department_id'";
 $run=mysqli_query($con,$qry);
 if($run){
   echo "Record updated successfully.";
   exit();
 }
?>
