<?php
//----------ready
 include('connection.php');
 $election_id=$_POST['electionid'];
 $election_name=$_POST['editElectionName'];
 $election_date=$_POST['editElectionDate'];
 $election_time=$_POST['editElectionTime'];
 $qry="UPDATE election SET election_name='$election_name',election_date='$election_date',time_upto='$election_time' WHERE election_id='$election_id'";
 $run=mysqli_query($con,$qry);
 if($run){
   echo "Record updated successfully.";
   exit();
 }
?>
