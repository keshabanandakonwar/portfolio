<?php
//----ready
 include('connection.php');
 $position_id=$_POST['positionid'];
 $position_name=$_POST['editPositionName'];
 if ($position_name=='') {
   echo "Please enter valid position name.";
   exit();
 }
 $qry="UPDATE positions SET position_name='$position_name' WHERE position_id='$position_id'";
 $run=mysqli_query($con,$qry);
 if($run){
   echo "Record updated successfully.";
   exit();
 }
?>
