<?php
//---------ready-----------
 include('connection.php');
 $semester_id=mysqli_real_escape_string($con,$_POST['semester_id']);
 $semester_name=mysqli_real_escape_string($con,$_POST['semester_name']);
 $qry="UPDATE semester SET semester_name='$semester_name' WHERE semester_id='$semester_id'";
 $run=mysqli_query($con,$qry);
 if($run){
   echo "Record updated successfully.";
   exit();
 }
?>
