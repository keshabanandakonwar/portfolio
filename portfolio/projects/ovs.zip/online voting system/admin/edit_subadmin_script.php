<?php
//-----------checked----
include('connection.php');
$qry="UPDATE admin SET admin_name='{$_POST["name"]}', admin_email='{$_POST["email"]}' WHERE sl_no='{$_POST["admin_id"]}'";
$run=mysqli_query($con,$qry);
if($run){
  echo "Record updated successfully.";
  exit();
}
?>
