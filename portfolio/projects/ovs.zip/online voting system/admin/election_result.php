<!DOCTYPE html>
<html>
  <head>
    <title>election result</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <meta name="viewport" content="width=device-width,initial-scale=1">
  </head>
  <body>
 <?php include('header.php'); ?>
    <div class="container">
      <div class="row">
        <div class="col-md-11" style="margin-left:14%;">
          <form class="bg-light" id="table">
            <table class="text-center table-bordered" style="width:100%">
              <thead>
                <tr class="bg-dark ">
                  <th colspan="2"><h2 class="text-white text-center">Search Election</h2>
                  </th>
                </tr>
              </thead>
              <tbody class="ml-3 bg-light">
                <tr>
                  <th><h3>Select Election : </h3></th>
                  <td class="pb-4">
                     <select class="form-control" id="election">
                       <option disabled selected>Select Election </option>
                       <?php
                          include('connection.php');
                          $qry="SELECT * FROM election WHERE election_status='1'";
                          $run=mysqli_query($con,$qry);
                          while($data=mysqli_fetch_array($run)){
                            echo "<option value='{$data['election_id']}' class='text-uppercase'>{$data['election_name']}</option>";
                          }
                       ?>
                     </select>
                  </td>
                </tr>
              </tbody>
            </table>
          </form>
        </div>
        <div class="col-md-11 text-center" style="margin-left:12%;" id="result">

        </div>
      </div>
  </div>
  <div class="container" id="logo-style">
    <div class="row">
      <div class="col-10 mt-2" style="margin-left:30%">
        <img src="system_images/vote.jpg" width="80%" height="auto" style="opacity:0.4" alt="">
      </div>
    </div>
  </div>
<script type="text/javascript" src="../css/jquery-3.2.1.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
  //----------fetch election result using election id-----------
    $('#election').on('change',function(){
      $('#logo-style').hide();
      var election_id = $('#election').val();
      $.ajax({
         url : "fetch_election_result.php",
         type : "post",
         data : {election_id : election_id},
         success : function(data){
           $('#result').html(data);
         }
      });
    });
  });
</script>
  </body>
</html>
