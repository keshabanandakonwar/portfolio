<?php
session_start();
include('connection.php');
$qry="SELECT * FROM admin WHERE admin_email='{$_SESSION['email']}' AND admin_password='{$_SESSION['password']}'";
$run=mysqli_query($con,$qry);
$data=mysqli_fetch_array($run);

//--------fetch login admin type----------
if($data['admin_type']=='hod'){
  $query="SELECT admin.sl_no,admin.admin_type,admin.depertment,depertment.depertment_name,depertment.depertment_id FROM admin INNER JOIN depertment ON  admin.depertment=depertment.depertment_id WHERE admin.sl_no='{$data['sl_no']}'";
  $run_query=mysqli_query($con,$query);
  $data2=mysqli_fetch_array($run_query);
}
//---------get voter requests-----------
$qry1="SELECT election.election_id,election.election_name,election.election_date,voters.voter_id,voters.voter_name,voters.voter_phone_number,voters.voter_course FROM vote INNER JOIN election ON vote.election_id=election.election_id INNER JOIN voters ON vote.voter_id=voters.voter_id WHERE vote.vote_status='0'";
$run1=mysqli_query($con,$qry1);
$check=mysqli_num_rows($run1);
if($check<1){
  echo "<tr><td colspan='4' style='text-align:center;padding:5px;color:purple;'>No Data Found</td></tr>";
  exit();
}
$slno=1;
while($row=mysqli_fetch_array($run1)){
  $output= "
        <tr>
           <td style='vertical-align:middle;text-align:center'>$slno</td>
           <td style='text-align:left;color:green'>
           <b>Voter Id : </b><i style='color:red'>{$row['voter_id']}</i><br>";
             $voter_id=$row['voter_id'];
          $qry2="SELECT voters.voter_id,voters.voter_name,voters.voter_phone_number,depertment.depertment_name,voters.voter_course,courses.course_id,courses.course_name,semester.semester_name FROM voters INNER JOIN depertment ON voters.voter_depertment=depertment.depertment_id INNER JOIN courses ON voters.voter_course=courses.course_id INNER JOIN semester ON voters.voter_semester=semester.semester_id WHERE voters.voter_id='$voter_id'";
             $run2=mysqli_query($con,$qry2);
             $data=mysqli_fetch_array($run2);

  $output.="   <b>Voter Dept/School : </b><i style='color:red'>{$data['depertment_name']}</i><br>
               <b>Voter Name : </b><i style='color:red'>{$data['voter_name']}</i><br>
               <b>Voter Number : </b><i style='color:red'>{$data['voter_phone_number']}</i><br>
               <b>Voter Course : </b><i style='color:red;'>{$data['course_name']}({$data['semester_name']})</i>
           </td>
           <td style='text-align:left;color:green'>
               <b>Election Id : </b><i style='color:red'>{$row['election_id']}</i><br>
               <b>Election Name : </b><i style='color:red'>{$row['election_name']}</i><br>
               <b>Election Date : </b><i style='color:red'>{$row['election_date']}</i>
           </td>
           <td style='vertical-align:middle'>
               <button id='cancel-btn' class='btn btn-sm btn-block btn-danger' data-id='{$data['voter_id']}' data-eid='{$row['election_id']}'>CANCEL</button>
           </td>
        </tr>
       ";
       $slno+=1;
echo $output ;
}
?>
