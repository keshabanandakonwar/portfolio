<?php
include('connection.php');
$qry="SELECT * FROM semester WHERE course_id='{$_POST['course_id']}'";
$run=mysqli_query($con,$qry);
if(mysqli_num_rows($run)<1){
  echo "<option>No semester available.</option>";
  exit();
}
echo "<option selected disabled>Select voter's semester</option>";
while ($data=mysqli_fetch_array($run)) {
?>
 <option value="<?php echo $data['semester_id']?>"><?php echo $data['semester_name']?></option>
<?php } ?>
