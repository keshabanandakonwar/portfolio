<?php
//no need
 include('connection.php');
 $depertment_id=$_POST['depertment_id'];
 $qry="SELECT * FROM courses WHERE depertment_id='{$depertment_id}'";
 $run=mysqli_query($con,$qry);
 if(mysqli_num_rows($run)<1){
   echo "<option>No data found.</option>";
   exit();
 }
 echo "<option>Select voter's course</option>";
 while($data=mysqli_fetch_array($run)){
   echo "<option value='{$data["course_id"]}'>{$data['course_name']}</option>";
 }
?>
