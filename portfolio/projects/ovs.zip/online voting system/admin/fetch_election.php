<?php
//--ready----------
  include('connection.php');

  $qry2="SELECT * FROM election ORDER BY sl_no DESC";
  $run2=mysqli_query($con,$qry2);
  $sl_no=1;
  while($data=mysqli_fetch_assoc($run2)){
    $output= "
                <tr class='text-center'>
                  <td><h3>$sl_no</h3></td>
                  <td><h4 class='text-uppercase'>{$data['election_id']}</h4></td>
                  <td><h4 class='text-uppercase'>{$data['election_name']}</h4></td>
                  <td><h4 class='text-uppercase'>{$data['election_date']}</h4></td>
                  <td><h4 class='text-uppercase'>{$data['time_upto']}</h4></td>
                  <td class='text-center'>
                     <button class='btn btn-warning input-sm' id='edit-election' data-electionid='{$data['election_id']}'>EDIT</button>
            ";
                    if($data['election_status']==1){
              $output.="<button class='btn btn-success input-sm' id='status' data-id='{$data['election_id']}'>VISIBLE</button>";
            }
            if($data['election_status']==0){
              $output.="<button class='btn btn-danger input-sm' id='status' data-id='{$data['election_id']}'>DISABLE</button>";
            }
   $output.= "
                  </td>
                </tr>
             ";
         $sl_no+=1;
 echo $output ;
}
?>
