<?php
 include('connection.php');
 $qry="SELECT * FROM election WHERE election_id='{$_POST["election_id"]}'";
 $run=mysqli_query($con,$qry);
 $data=mysqli_fetch_array($run);
?>

  <h1 class="text-center text-danger text-uppercase mt-5"><?php echo $data['election_name']?></h1>
  <h2 class="text-primary">(<?php echo $data['election_date']?>)</h2>
  <hr class="bg-danger">
<!------------fetch total no of positions-------------->
<?php
 $qry1="SELECT * FROM positions WHERE election_id='{$data["election_id"]}'";
 $run1=mysqli_query($con,$qry1);
 $row1=mysqli_num_rows($run1);
?>
<div class="row text-center">
  <div class="col-md-3 bg-success p-3 m-2 text-center">
    <h2 class="mt-3"><i class="text-danger bg-white p-3" style="border-radius:50%"><?php echo $row1?></i></h2>
      <h3 class="mt-3"><i class="text-white">Total no of Positions</i></h3>
  </div>
<!------------fetch total no of candidates---------->
<?php
$qry2="SELECT * FROM candidate WHERE election_id='{$data["election_id"]}' AND candidate_status='1'";
$run2=mysqli_query($con,$qry2);
$row2=mysqli_num_rows($run2);
?>
  <div class="col-md-3 bg-success p-3 m-2 text-center">
    <h2 class="mt-3"><i class="text-danger bg-white p-3" style="border-radius:50%"><?php echo $row2?></i> </h2>
      <h3 class="mt-3"><i class="text-white">Total no of Candidates</i></h3>
  </div>
<!------------total no of voters------------>
<?php
$qry3="SELECT * FROM voters WHERE voter_status=1";
$run3=mysqli_query($con,$qry3);
$row3=mysqli_num_rows($run3);
?>
  <div class="col-md-3 bg-success p-3 m-2 text-center">
    <h2 class="mt-3"><i class="text-danger bg-white p-3" style="border-radius:50%"><?php echo $row3?></i> </h2>
      <h3 class="mt-3"><i class="text-white">Total no of Voters</i></h3>
  </div>
<!--------------print result------->  
  <div class="col-md-2 bg-danger mt-2 mb-2 text-center">
      <a href="print_result.php?eid=<?php echo $data['election_id']?>" class="btn bg-dark mt-4" id="print">
        <h1><i class="fa fa-print text-success"></i><h1>
        <h5 class="text-white">Print Result</h5>
     </a>
  </div>  
</div>
<hr class="bg-danger">


<div class="row mt-4">
  <div class="col-md-9" style="border-right:2px solid purple">
   <?php
   while($data1=mysqli_fetch_array($run1)){
   ?>
    <h3 class="text-center bg-success text-white text-uppercase"><?php echo $data1['position_name']?></h3><hr class="bg-primary mt-0 mb-0">
    <div class="row">
     <?php
     $qry4="SELECT voters.voter_fname,voters.voter_lname,voters.voter_rollno,courses.course_name,semester.semester_name,candidate.photo,candidate.election_id,candidate.position_id,candidate.vote,department.department_name FROM candidate INNER JOIN voters ON candidate.voter_id=voters.voter_id INNER JOIN department ON voters.voter_department=department.department_id INNER JOIN courses ON voters.voter_course=courses.course_id INNER JOIN semester ON voters.voter_semester=semester.semester_id WHERE candidate.election_id='{$data["election_id"]}' AND candidate.position_id='{$data1["position_id"]}'";
     $run4=mysqli_query($con,$qry4);
     while($data4=mysqli_fetch_array($run4)){
     ?>
        <div class="col-md-12">
          <table class="table table-bordered table-striped" style="box-shadow:0px 0px 5px 2px red">
            <tr>
              <th rowspan="6" style="vertical-align: middle;width:25%;height:20%;border-right:3px solid red"><p style="width:100%;height:100%"><img class="text-center" src="../<?php echo $data4['photo']?>" alt="image" width="100%"></p></th>
            </tr>
            <tr>
              <th style="vertical-align:middle"><h4>Name</h4></th>
              <td style="vertical-align:middle"><h4 class="text-center text-primary text-uppercase"><b><?php echo $data4['voter_fname'].' '. $data4['voter_lname'] ?></b></h4></td>
            </tr>
            <tr>
              <th class="p-0 m-0" style="vertical-align:middle"><h4>Department</h4></th>
              <td class="p-0 m-0" style="vertical-align:middle"><h4 class="text-center text-primary text-uppercase"><?php echo $data4['department_name']?></h4></td>
            </tr>
            <tr>
              <th class="p-0 m-0" style="vertical-align:middle"><h4>Course</h4></th>
              <td class="p-0 m-0" style="vertical-align:middle"><h4 class="text-center text-primary text-uppercase"><?php echo $data4['course_name']?>(<i class="text-lowercase"><?php echo $data4['semester_name']?></i>)</h4></td>
            </tr>
            <tr>
              <th class="p-0 m-0" style="vertical-align:middle"><h4>Roll No</h4></th>
              <td class="p-0 m-0" style="vertical-align:middle"><h4 class="text-center text-primary"><?php echo $data4['voter_rollno']?></h4></td>
            </tr>
            <tr>
              <th style="vertical-align:middle"><h4>Total Votes</h4></th>
              <td style="vertical-align:middle">
                <h4 class="text-center text-white">
                  <?php
                   $qry5="SELECT MAX(vote) FROM candidate WHERE election_id='{$data4["election_id"]}' AND position_id='{$data4["position_id"]}'";
                   $run5=mysqli_query($con,$qry5);
                   $data5=mysqli_fetch_array($run5);
                  if ($data5['MAX(vote)']==$data4['vote']) {
                ?>
                    <div style="background-image:url('../images/photo/victory.gif')">
                <?php
                    echo "<i class='fa fa-trophy float-left fa-lg pt-3 pl-3 text-primary'></i>";
                    echo "{$data5['MAX(vote)']}";
                    echo "<i class='fa fa-trophy float-right fa-lg pt-3 pr-3 text-danger'></i><br>";
                    echo "<b'>WINNER</b>";
                ?>
                   </div>
                <?php
                  }else {
                    echo "<b class='text-dark'>{$data4['vote']}</b>";
                  }
                  ?>
                </h4>
              </td>
            </tr>
          </table>
        </div>
     <?php } ?>
   </div><hr>
   <?php } ?>
  </div>



<div class="col-md-3">
  <table class="table text-center table-bordered table-striped">
      <tr class="bg-dark text-white" style="background-image:url('../images/photo/background.gif')">
        <th colspan="2" class="text-white">WINNERS</th>
      </tr>
      <?php
      $qry6="SELECT * FROM positions WHERE election_id='{$data["election_id"]}'";
      $run6=mysqli_query($con,$qry6);
      while($data6=mysqli_fetch_array($run6)){
      ?>
      <tr>
        <th colspan="2" class="text-uppercase text-danger bg-dark"><?php echo $data6['position_name']?></th>
      </tr>
      <tr>
        <?php
         $qry7="SELECT * FROM candidate WHERE vote=(SELECT MAX(vote) FROM candidate WHERE election_id='{$data["election_id"]}' AND position_id='{$data6["position_id"]}')";
         $run7=mysqli_query($con,$qry7);
         while ($data7=mysqli_fetch_array($run7)) {
        ?>
        <th class="p-1 m-0"><img src="../<?php echo $data7['photo']?>" width="100%"> </th>
        <?php
          $qry8="SELECT * FROM voters WHERE voter_id='{$data7["voter_id"]}'";
          $run8=mysqli_query($con,$qry8);
          $data8=mysqli_fetch_array($run8);
        ?>
          <td class="text-center"><b class="text-uppercase text-success"><?php echo $data8['voter_fname'].' '.$data8['voter_lname']?><hr class="p-0 m-0"><?php echo $data7['vote']?></b> </td>
      <?php }?>
      </tr>
      <?php } ?>
  </table>
</div>
</div>
