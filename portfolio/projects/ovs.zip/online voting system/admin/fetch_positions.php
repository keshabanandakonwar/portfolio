<?php
//----------ready---------
  include('connection.php');
  $qry1="SELECT * FROM election  WHERE election_status='1'";
  $run1=mysqli_query($con,$qry1);
  $sl_no=1;
  while($data=mysqli_fetch_assoc($run1)){
    $output= "
                <tr class='text-center'>
                  <td style='vertical-align:middle'><h5>$sl_no</h5></td>
                  <td class='text-left' style='vertical-align:middle'>
                      <h6 class='text-uppercase'> Election Id : <i class='text-primary'>{$data['election_id']}</i></h6><hr class='bg-warning'>
                      <h6 class='text-uppercase'>Election Name : <i class='text-primary'>{$data['election_name']}</i></h6><hr class='bg-warning'>
                      <h6 class='text-uppercase'>Election Date : <i class='text-primary'>{$data['election_date']}</i></h6>
                  </td>
                  <td class='text-center'>
            ";
        $qry2="SELECT * FROM positions WHERE election_id='{$data['election_id']}' ORDER BY position_id DESC";
        $run2=mysqli_query($con,$qry2);
        while($row=mysqli_fetch_array($run2)){
   $output.="
                  <h6 class='text-uppercase text-danger'>{$row['position_name']}</h6>
                  <button class='btn btn-info input-sm' id='eligibility' data-id='{$row['position_id']}'>Eligibility</button>
                  <button class='btn btn-primary input-sm' id='edit-position-btn' data-id='{$row['position_id']}'>EDIT</button>
            ";
                  if($row['position_status']=='1'){
              $output.="<button class='btn btn-success input-sm' id='status' data-id='{$row['position_id']}'>VISIBLE</button><hr class='bg-dark'>";
            }else{
              $output.="<button class='btn btn-danger input-sm' id='status' data-id='{$row['position_id']}'>DISABLE</button><hr class='bg-dark'>";
            }
          }
   $output.= "
                  </td>
                </tr>
             ";
         $sl_no+=1;
 echo $output ;
}
?>
