<tr>
  <th colspan="6" class="bg-dark text-white text-center">Voter's Details</th>
</tr>
  <tr class="bg-dark text-center">
    <th class="text-white">Select </th>
    <th class="text-white">Sl No</th>
    <th class="text-white">Educational Details</th>
    <th class="text-white">Personal Details</th>
    <th class="text-white">Address</th>
    <th class="text-white">Action</th>
  </tr>
  <tr style="display:none;">
    <th><input type="text" id="course-id" value="<?php echo $_POST['course_id'] ?>"></th>
  </tr>
<?php
include('connection.php');
$course_id=$_POST['course_id'];
$qry1="SELECT voters.voter_id,voters.voter_fname,voters.voter_lname,voters.voter_email,voters.voter_rollno,voters.voter_status,voters.voter_phone_number,department.department_name,courses.course_id,courses.course_name,semester.semester_name,voters.voter_state,voters.voter_district,voters.voter_postoffice,voters.voter_pinno,voters.voter_village FROM voters INNER JOIN department ON voters.voter_department=department.department_id INNER JOIN courses ON voters.voter_course=courses.course_id INNER JOIN semester ON voters.voter_semester=semester.semester_id WHERE courses.course_id='{$course_id}'";
$run1=mysqli_query($con,$qry1);
$check=mysqli_num_rows($run1);
if($check<1){
  echo "<tr><td colspan='6' style='text-align:center;padding:5px;color:purple;'>No Data Found</td></tr>";
  exit();
}
$slno=1;
while($row=mysqli_fetch_array($run1)){
  $output= "
        <tr>
           <td style='vertical-align:middle'><input type='checkbox' class='form-control' data-id='{$row["voter_id"]}' id='checkbox-data'></td>
           <td style='vertical-align:middle'>$slno</td>
           <td>
                 <h6 class='p-0 text-uppercase text-left'>Department : <strong class='text-primary'>{$row["department_name"]}</strong><br>
                 Course : <strong class='text-primary'>{$row["course_name"]}</strong><br>
                 Semester : <strong class='text-primary'>{$row["semester_name"]}</strong><br>
                 Roll No : <strong class='text-primary'>{$row["voter_rollno"]}</strong></h6>
          </td>
           <td>
               <h6 class='p-0 text-uppercase text-left'>Voter Id : <strong class='text-primary'>{$row["voter_id"]}</strong><br>
               Name : <strong class='text-primary'>{$row["voter_fname"]} {$row["voter_lname"]}</strong><br>
               Phone : <strong class='text-primary'>{$row["voter_phone_number"]}</strong><br>
               Email : <strong class='text-primary'>{$row["voter_email"]}</strong></h6>
            </td>
            <td>
                <h6 class='p-0 text-uppercase text-left'>State : <strong class='text-primary'>{$row["voter_state"]}</strong><br>
                  District : <strong class='text-primary'>{$row["voter_district"]}</strong><br>
                  Post Office : <strong class='text-primary'>{$row["voter_postoffice"]}</strong><br>
                  Pin No : <strong class='text-primary'>{$row["voter_pinno"]}</strong><br>
                  Village/Town : <strong class='text-primary'>{$row["voter_village"]}</strong></h6>
           </td>
          <td class='text-center' style='vertical-align:middle'>
            ";
               if($row['voter_status']=='1'){
    $output.="<small class='text-danger'>Click the following button to de-active voter account</small><br><i class='fa fa-arrow-down text-success'></i>
              <button id='voter_status' class='btn btn-sm btn-block btn-success' data-id='{$row['voter_id']}'>DE-ACTIVE</button>";
               }else{
    $output.="<small class='text-danger'>Click the following button to active voter account</small><br><i class='fa fa-arrow-down text-success'></i>
              <button id='voter_status' class='btn btn-sm btn-block btn-warning' data-id='{$row['voter_id']}'>ACTIVE</button>";
               }
    $output.="
              Current Status is <hr class='m-0'>
              ";
              if($row['voter_status']=='0'){
        $output.="<b>DE-ACTIVE</b>";
              }else{
        $output.="<b class='text-success'>ACTIVE</b>";
              }
    $output.="</td>
      </tr>
       ";
       $slno+=1;
echo $output ;
}
?>
