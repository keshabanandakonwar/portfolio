<?php
//--------ready
include('connection.php');
$qry1="SELECT * FROM  department ORDER BY department_id DESC";
$run1=mysqli_query($con,$qry1);
while($data1=mysqli_fetch_array($run1)){
?>
 <table  class="table table-bordered mt-5 mb-4 table-striped table-hover" style="box-shadow:0px 0px 9px 2px purple">
   <tr class='bg-dark text-center text-uppercase'>
     <th colspan="3" class="text-white">School / Department : <?php echo $data1['department_name']?></th>
   </tr>
   <tr class='bg-dark text-center'>
      <th class="text-white">Sl No</th>
      <th class="text-white">Course</th>
      <th class="text-white">Semester</th>
   </tr>
   <?php
    $qry2="SELECT * FROM courses WHERE department_id='{$data1["department_id"]}'";
    $run2=mysqli_query($con,$qry2);
    $slno=1;
    while($data2=mysqli_fetch_array($run2)){
   ?>
       <tr>
         <th class='text-center' style='vertical-align:middle'><h6><?php echo $slno ?></h6></th>
         <th class='text-center text-uppercase' style='vertical-align:middle'>
             <h3 class="pl-5 pr-5"><?php echo $data2['course_name'] ?></h3>
          </th>
         <td class="pl-5 pr-5 text-center">
            <?php
              $qry3="SELECT * FROM semester WHERE course_id='{$data2["course_id"]}'";
              $run3=mysqli_query($con,$qry3);
              if(mysqli_num_rows($run3)<1){
            ?>
                <h6 class='text-center text-danger'>No data found.<br> <p>Click the following button to add new Semester/Class</p><a href='add_semester.php' class='btn btn-sm btn-warning text-dark'> ADD SEMESTER</a></h6>
            <?php }
              while($data3=mysqli_fetch_array($run3)){
            ?>
               <h5 class='text-center text-success text-uppercase w-auto'><?php echo $data3['semester_name'] ?></h5>

               <button class='btn btn-primary btn-sm btn-block' data-id='<?php echo $data3['semester_id'] ?>' id='edit-semester'>Edit</button>
               <?php if($data3['semester_status']=='1'){ ?>
                  <span class='fa fa-arrow-down'></span>&nbsp;&nbsp<small class='text-danger'>Click the following button to de-active this semester</small>&nbsp;&nbsp<span class='fa fa-arrow-down'></span><button class='btn btn-success btn-sm btn-block' data-id='<?php echo $data3['semester_id'] ?>' id='status'>Visible</button><hr>
               <?php }else{ ?>
                  <span class='fa fa-arrow-down'></span>&nbsp;&nbsp<small class='text-danger'>Click the following button to active this semester</small>&nbsp;&nbsp<span class='fa fa-arrow-down'></span><button class='btn btn-block btn-danger btn-sm' data-id='<?php echo $data3['semester_id']?>' id='status'>Disable</button><hr>
              <?php } ?>
            <?php } ?>
         </td>
       </tr>
   <?php $slno++;} ?>
 </table>
<?php  } ?>
