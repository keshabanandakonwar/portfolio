<?php
include('connection.php');
 session_start();
 if(!isset($_SESSION['email'])){
   header("location:index.php");
   exit();
 }
 $query="SELECT * FROM admin WHERE admin_email='{$_SESSION['email']}' AND admin_password='{$_SESSION['password']}'";
 $run_qry=mysqli_query($con,$query);
 $data=mysqli_fetch_array($run_qry);
?>
<html>
  <head>
    <link href="assets/css/lib/calendar2/pignose.calendar.min.css" rel="stylesheet">
    <link href="assets/css/lib/chartist/chartist.min.css" rel="stylesheet">
    <link href="assets/css/lib/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/lib/themify-icons.css" rel="stylesheet">
    <link href="assets/css/lib/owl.carousel.min.css" rel="stylesheet" />
    <link href="assets/css/lib/owl.theme.default.min.css" rel="stylesheet" />
    <link href="assets/css/lib/weather-icons.css" rel="stylesheet" />
    <link href="assets/css/lib/menubar/sidebar.css" rel="stylesheet">
    <link href="assets/css/lib/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/lib/helper.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
  </head>
  <body>
    <div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">
        <div class="nano">
            <div class="nano-content">
                <ul>
                    <div class="logo text-center"><a href="index.html">
                            <span>Admin Control</span></a><br>
                            <img src="../images/argucom_logo.png" width="30%">
                    </div><hr>

                        <?php
                         if($data['admin_type']=='admin'){
                        ?>
                        <li><a class="sidebar-sub-toggle"><i class="fa fa-users"></i>Manage Sub Admin <span
                                        class="sidebar-collapse-icon ti-angle-down"></span></a>
                                <ul>
                                    <li><a href="admins.php">Add/View Sub Admin</a></li>
                              </ul>
                        </li>
                            <li><a class="sidebar-sub-toggle"><i class="fa fa-map"></i> Department / School <span
                                            class="sidebar-collapse-icon ti-angle-down"></span></a>
                                    <ul>
                                        <li><a href="department.php">Add/View New Department</a></li>
                                  </ul>
                            </li>
                            <li><a class="sidebar-sub-toggle"><i class="fa fa-book"></i> Course<span
                                            class="sidebar-collapse-icon ti-angle-down"></span></a>
                                    <ul>
                                        <li><a href="add_course.php">Add Course</a></li>
                                        <li><a href="add_semester.php">Add Semester</a></li>
                                  </ul>
                            </li>
                            <li><a class="sidebar-sub-toggle"><i class="fa fa-map"></i> Election <span
                                            class="sidebar-collapse-icon ti-angle-down"></span></a>
                                    <ul>
                                        <li><a href="add_election.php">Add New Election</a></li>
                                  </ul>
                            </li>

                            <li><a class="sidebar-sub-toggle"><i class="fa fa-users"></i> Position <span
                                            class="sidebar-collapse-icon ti-angle-down"></span></a>
                                    <ul>
                                        <li><a href="add_position.php">Add New Position</a></li>
                                  </ul>
                            </li>
                            <li><a class="sidebar-sub-toggle"><i class="fa fa-election"></i> Result<span
                                            class="sidebar-collapse-icon ti-angle-down"></span></a>
                                    <ul>
                                        <li><a href="election_result.php">Election Result</a></li>
                                    </ul>
                            </li>
                            <li><a class="sidebar-sub-toggle"><i class="fa fa-users"></i> Candidate <span
                                            class="sidebar-collapse-icon ti-angle-down"></span></a>
                                    <ul>
                                        <li><a href="un_approved_candidate.php">Un-Approve Candidates</a></li>
                                        <li><a href="approved_candidate.php">Approved Candidates</a></li>
                                  </ul>
                            </li>
                            <li><a href="query.php"><i class="fa fa-user"></i>Voter's Query</a></li>
                            <li><a class="sidebar-sub-toggle"><i class="fa fa-users"></i> Voters <span
                                            class="sidebar-collapse-icon ti-angle-down"></span></a>
                                    <ul>
                                        <li><a href="voters.php">View Voter</a></li>
                                  </ul>
                            </li>
                      <?php }?>
                       <?php
                       //---------start test-------
                          if($data['admin_type']=='controller'){
                            $query="SELECT department.department_name,courses.course_name,courses.course_id FROM admin INNER JOIN department ON admin.department_id=department.department_id INNER JOIN courses ON admin.course_id=courses.course_id WHERE admin.sl_no='{$data["sl_no"]}'";
                            $run_query=mysqli_query($con,$query);
                            while($data2=mysqli_fetch_array($run_query)){
                       ?>
                           <li><a class="sidebar-sub-toggle text-uppercase"><i class="fa fa-book"></i><?php echo $data2['department_name']?><span class="sidebar-collapse-icon ti-angle-down"></span></a>
                             <ul>
                                 <li><a class="sidebar-sub-toggle text-uppercase"><i class="fa fa-bance"></i><?php echo $data2['course_name']?><span
                                                 class="sidebar-collapse-icon ti-angle-down"></span></a>
                                    <ul>
                                      <?php
                                        $qry3="SELECT * FROM semester WHERE course_id='{$data2["course_id"]}'";
                                        $run3=mysqli_query($con,$qry3);
                                        while ($data3=mysqli_fetch_array($run3)){
                                      ?>
                                      <li><a class="text-uppercase" href="voter_list_for_controller.php?cid=<?php echo $data3['course_id']?>"><?php echo $data3['semester_name']?></a></li>
                                    <?php } ?>
                                    </ul>
                                 </li>
                             </ul>
                           </li>
                          <?php } }?>
                        <!-----end test------>
                    <li><a href="profile.php"><i class="fa fa-user"></i>Your Profile</a></li>
                    <li><a href="logout.php"><i class="ti-close"></i> Logout</a></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- /# sidebar -->

    <div class="header mb-5">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="float-left">
                        <div class="hamburger sidebar-toggle">
                            <span class="line"></span>
                            <span class="line"></span>
                            <span class="line"></span>
                        </div>
                    </div>
                        <div class="dropdown dib float-right">
                            <div class="header-icon text-center" data-toggle="dropdown">
                                <span class="user-avatar text-uppercase">
                                  <i class="fa fa-user"></i><br>
                                  <?php echo $data['admin_name']?>
                                    <i class="ti-angle-down f-s-10"></i>
                                </span>
                                <div class="drop-down dropdown-profile dropdown-menu dropdown-menu-right">
                                    <div class="dropdown-content-body">
                                        <ul>
                                            <li>
                                                    <i class="ti-user"></i>
                                                    <a href="profile.php">Profile</a>
                                            </li>

                                            <li>
                                                <a href="logout.php">
                                                    <i class="ti-power-off"></i>
                                                    <span>Logout</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- jquery vendor -->
    <script src="assets/js/lib/jquery.min.js"></script>
    <script src="assets/js/lib/jquery.nanoscroller.min.js"></script>
    <!-- nano scroller -->
    <script src="assets/js/lib/menubar/sidebar.js"></script>
    <script src="assets/js/lib/preloader/pace.min.js"></script>
    <!-- sidebar -->

    <script src="assets/js/lib/bootstrap.min.js"></script>
    <script src="assets/js/scripts.js"></script>
    <!-- bootstrap -->

    <script src="assets/js/lib/calendar-2/moment.latest.min.js"></script>
    <script src="assets/js/lib/calendar-2/pignose.calendar.min.js"></script>
    <script src="assets/js/lib/calendar-2/pignose.init.js"></script>


    <script src="assets/js/lib/weather/jquery.simpleWeather.min.js"></script>
    <script src="assets/js/lib/weather/weather-init.js"></script>
    <script src="assets/js/lib/circle-progress/circle-progress.min.js"></script>
    <script src="assets/js/lib/circle-progress/circle-progress-init.js"></script>
    <script src="assets/js/lib/chartist/chartist.min.js"></script>
    <script src="assets/js/lib/sparklinechart/jquery.sparkline.min.js"></script>
    <script src="assets/js/lib/sparklinechart/sparkline.init.js"></script>
    <script src="assets/js/lib/owl-carousel/owl.carousel.min.js"></script>
    <script src="assets/js/lib/owl-carousel/owl.carousel-init.js"></script>
    <!-- scripit init-->
    <script src="assets/js/dashboard2.js"></script>
  </body>
</html>
