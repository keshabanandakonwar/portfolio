<!-------ready-------->
<html>
  <head>
    <title>Admin login Page</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <style media="screen">
      .department{
        display: none;
      }
      .course{
        display: none;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <img src="system_images/logo.png" width="80%" height="auto" alt="">
        </div>
        <div class="col-lg-6 mt-5">
          <form class="border p-3 bg-light" action="" method="post">
            <div class="form-group">
              <h1 class="p-3 bg-success text-white text-center">Admin Login</h1>
            </div>
            <div class="form-group">
              <label for="">Select Admin Type :</label>
              <select class="form-control" id="admin-type" name="a_type" required>
                 <option disabled selected>Select admin type</option>
                 <option value="admin">ADMIN</option>
                 <option value="controller">Course Controller</option>
              </select>
            </div>
            <div class="form-group department">
              <label for="">Select Your Department / School :</label>
              <select class="form-control" name="department" id="department">
                 <option disabled selected>Select Department / School</option>
                 <?php
                    include('connection.php');
                    $qry1="SELECT * FROM department";
                    $run1=mysqli_query($con,$qry1);
                    while($data1=mysqli_fetch_array($run1)){
                 ?>
                 <option value="<?php echo $data1['department_id'] ?>"><?php echo $data1['department_name'] ?></option>
               <?php } ?>
              </select>
            </div>
            <div class="form-group course">
              <label for="">Select Course :</label>
              <select class="form-control" name="course" id="course">
              </select>
            </div>
            <div class="form-group">
              <label for="email">Admin Email Id</label>
              <input type="email" placeholder="Enter your email id" class="form-control" name="email" required id="email">
            </div>
            <div class="form-group">
              <label for="password">Admin Password</label>
              <input type="password" placeholder="Enter your password" class="form-control" name="password" required id="password">
            </div>
            <div class="form-group">
              <input type="submit" name="submit" value="SUBMIT" class="btn btn-success btn-block">
            </div>
          </form>
        </div>
      </div>
    </div>
<script type="text/javascript" src="../css/jquery-3.2.1.min.js"></script>
<script>
  $(document).ready(function(){
     $('#admin-type').on('change',function(){
       a_type = $('#admin-type').val();
       if(a_type=='controller'){
         $('.department').show();
         $('.course').show();
       }
     });
//--------fetch dependent course--------
$('#department').on('change',function(){
  var department_id=$(this).val();
  $.ajax({
    url : "../fetch_dependent_course.php",
    type : "post",
    data : {dept_id : department_id},
    success : function(data){
      $('#course').html(data);
    }
  });
});
  });
</script>
  </body>
</html>
<?php
include('connection.php');
if(isset($_POST['submit'])){
  $a_type=mysqli_real_escape_string($con,$_POST['a_type']);
  if($a_type=='admin'){
    $department=0;
    $course=0;
  }else{
    $department=mysqli_real_escape_string($con,$_POST['department']);
    $course=mysqli_real_escape_string($con,$_POST['course']);
  }
  $email=mysqli_real_escape_string($con,$_POST['email']);
  $password=mysqli_real_escape_string($con,$_POST['password']);
  $hash_pass=md5($password);
  $qry1="SELECT * FROM admin WHERE admin_email='$email' AND admin_password='$hash_pass' AND department_id='$department' AND course_id='$course'";
  $run1=mysqli_query($con,$qry1);
  if(mysqli_num_rows($run1)>0){
    while($result=mysqli_fetch_array($run1)){
      if ($result['admin_status']==0){
        echo "<script>alert('You account is de-activate.')</script>";
        echo "<script>window.open('index.php','_self')</script>";
        exit();
      }
    }
    session_start();
    $_SESSION['email']=$email;
    $_SESSION['password']=$hash_pass;
    $_SESSION['department']=$department;
    $_SESSION['course']=$course;
    echo "<script>alert('You are login Successfully.')</script>";
    echo "<script>window.open('header.php','_self')</script>";
    exit();
  }else{
    echo "<script>alert('Wrong details.Please enter valid details.')</script>";
    echo "<script>window.open('index.php','_self')</script>";
    exit();
  }
}
?>
