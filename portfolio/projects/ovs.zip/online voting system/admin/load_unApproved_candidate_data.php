<?php
//------------ready
include('connection.php');
 $election_id=$_POST['election_id'];
 $qry="SELECT * FROM election WHERE election_id='$election_id'";
 $run=mysqli_query($con,$qry);
 $data=mysqli_fetch_array($run);
  $output="
            <tbody>
               <tr class='bg-success text-center'>
                  <th colspan='4' class='text-white'>
                    <i>Election Id :</i><b>{$data['election_id']}</b><br>
                    <i>Election Name :</i><b class='text-uppercase'>{$data['election_name']}</b><br>
                    <i>Election Date :</i><b>{$data['election_date']}
                  </th>
               </tr>
               <tr class='text-center'>
                  <th>Sl No</th>
                  <th>Position Name</th>
                  <th>Candidates</th>
                  <th>Action</th>
                </tr>
               ";
             $qry2="SELECT candidate.candidate_status,positions.position_name,voters.voter_id,voters.voter_fname,voters.voter_lname FROM candidate INNER JOIN positions ON positions.position_id=candidate.position_id INNER JOIN voters ON voters.voter_id=candidate.voter_id WHERE candidate.election_id='{$data['election_id']}' AND candidate.candidate_status='0'";
             $run2=mysqli_query($con,$qry2);
             $check=mysqli_num_rows($run2);
             if($check<1){
               echo "<tr><td><h5 class='text-white text-center p-2 bg-primary'>No candidate found.</h5></td></tr>";
               exit();
             }
             $slno=1;
             while($data2=mysqli_fetch_array($run2)){
          $output.="
                      <tr class='text-center'>
                          <td>{$slno}</td>
                          <td>{$data2['position_name']}</td>
                          <td>{$data2['voter_fname']} {$data2['voter_lname']}</td>
                          <td class='text-left'>
                          <button id='candidate-details' class='btn btn-sm btn-secondary' data-vid='{$data2['voter_id']}' data-eid='{$data['election_id']}'>DETAILS</button>
                          <button id='approve-candidate' class='btn btn-sm btn-primary' data-vid='{$data2['voter_id']}' data-eid='{$data['election_id']}'>APPROVE</button>
                          <button id='delete-candidate' class='btn btn-sm btn-danger' data-vid='{$data2['voter_id']}' data-eid='{$data['election_id']}'>DELETE</button>;</td>
                       </tr>";
             $slno+=1;}
  $output.="</tbody>
          ";
  echo $output;
?>
