<?php
//--------checked
 include('connection.php');
 // get position id from fetch_positions.php page
 $position_id=$_GET['position_id'];
 $qry="SELECT * FROM positions WHERE position_id='$position_id'";
 $run=mysqli_query($con,$qry);
 $check=mysqli_num_rows($run);
 if($check<1){
   echo "<h3 class='text-center text-danger p-3'>No data found.</h3>";
 }
    while($result=mysqli_fetch_array($run)){
           $output="<form style='width:40%;height:5%;overflow-y:scroll'>
                      <h6 class='text-danger pl-2 pt-1'><u>Conditions </u> -----</h6>
                      <strong class='pl-3 pr-3'> {$result['eligibility']}</strong>
                    </form>
                  ";
    echo $output;
    }
?>
