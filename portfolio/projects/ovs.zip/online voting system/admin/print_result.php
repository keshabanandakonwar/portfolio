<?php
include('connection.php');
$qry1="SELECT * FROM election WHERE election_id='{$_GET["eid"]}'";
$run1=mysqli_query($con,$qry1);
$data1=mysqli_fetch_array($run1);
?>
<html>
  <head>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <title></title>
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col-12 mt-4">
          <h1 class="text-center">ELECTION RESULT</h1>
          <hr>
          <table class="table table-bordered text-center">
            <tr>
              <th colspan="3">
                <h1 class="text-uppercase"><?php echo $data1['election_name'] ?></h1>
                <h4>Date : <?php echo $data1['election_date'] ?></h4>
              </th>
            </tr>
            <tr>
              <th><h3>Sl No</h3> </th>
              <th><h3>Position Name</h3> </th>
              <th><h3>Winner</h3> </th>
            </tr>
<?php
$qry2="SELECT * FROM positions WHERE election_id='{$_GET["eid"]}'";
$run2=mysqli_query($con,$qry2);
$slno=1;
while($data2=mysqli_fetch_array($run2)){
?>
            <tr>
              <td style="vertical-align:middle"><h3><?php echo $slno ?></h3> </td>
              <td style="vertical-align:middle"><h3 class="text-uppercase"><?php echo $data2['position_name']?></h3> </td>
              <td>
                <h3 class="text-uppercase">
                <?php
                   $qry3="SELECT * FROM candidate WHERE vote=(SELECT MAX(vote) FROM candidate WHERE election_id='{$_GET["eid"]}' AND position_id='{$data2["position_id"]}')";
                   $run3=mysqli_query($con,$qry3);
                   if(mysqli_num_rows($run3)<1){
                     echo "Empty";
                   }
                   $data3=mysqli_fetch_array($run3);
                   $qry4="SELECT voters.voter_fname,voters.voter_lname,department.department_name,courses.course_name,semester.semester_name FROM voters INNER JOIN department ON voters.voter_department=department.department_id INNER JOIN courses ON voters.voter_course=courses.course_id INNER JOIN semester ON voters.voter_semester=semester.semester_id WHERE voters.voter_id='{$data3["voter_id"]}'";
                   $run4=mysqli_query($con,$qry4);
                   while($data4=mysqli_fetch_array($run4)){
                ?>
                   <i class="fa fa-trophy"></i>

                   <table class="table text-center">
                     <tr>
                       <th rowspan="4" style="width:30%"><img src="../<?php echo $data3['photo']?>" width="100%" alt=""> </th>
                     </tr>
                     <tr>
                       <th colspan="2" style="vertical-align:middle"><h3><?php echo $data4['voter_fname'].' '.$data4['voter_lname']?></h3></th>
                     </tr>
                     <tr>
                       <th>Department</th>
                       <td><?php echo $data4['department_name']?></td>
                     </tr>
                     <tr>
                       <th>Course</th>
                       <td><?php echo $data4['course_name']?>(<?php echo $data4['semester_name']?>)</td>
                     </tr>
                   </table>
                <?php } ?>
              </h3>
            </td>
            </tr>
<?php $slno++;} ?>
          </table>
        </div>
      </div>
    </div>
<script type="text/javascript" src="../css/jquery-3.2.1.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
  function loadData(){
    //window.open('print_result.php','_target');
    window.print();
  }
  loadData();
});
</script>
  </body>
</html>
