<!----ready---------->
<html>
  <head>
    <title>Update Profile</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
  </head>
  <body>
 <?php include('header.php'); ?>
    <div class="container">
      <div class="row">
        <div class="col-md-10" style="margin-left:20%;">
          <form class="form" method="post">
            <table class="table table-striped table-bordered">
              <tr class="bg-dark ">
                <th colspan="3" class="text-center text-uppercase"><h2 class="text-white">Update Profile</h2> </th>
              </tr>
              <tr>
                <th class="text-center"><h4><label for="admin_type">ADMIN TYPE</label></h4></th>
                <th>:</th>
                <td><input type="text" value="<?php echo $data['admin_type']?>" id="admin_type" class="form-control text-uppercase text-danger" readonly> </td>
              </tr>
              <?php
                if($data['admin_type']=='controller'){
                  $query="SELECT department.department_name,courses.course_name FROM admin INNER JOIN department ON admin.department_id=department.department_id INNER JOIN courses ON admin.course_id=courses.course_id WHERE admin.sl_no='{$data["sl_no"]}'";
                  $run_query=mysqli_query($con,$query);
                  $data2=mysqli_fetch_array($run_query);
              ?>
              <tr>
                <th class="text-center"><h4><label for="department">DEPARTMENT</label></h4></th>
                <th>:</th>
                <td><input type="text" value="<?php echo $data2['department_name']?>" readonly class="form-control"> </td>
              </tr>
              <tr>
                <th class="text-center"><h4><label for="course">COURSE</label></h4></th>
                <th>:</th>
                <td><input type="text" value="<?php echo $data2['course_name']?>" readonly class="form-control"> </td>
              </tr>
            <?php } ?>
              <tr>
                <th class="text-center"><h4><label for="email">EMAIL ID</label></h4></th>
                <th>:</th>
                <td><input type="email" name="email" value="<?php echo $data['admin_email']?>" readonly class="form-control text-danger"> </td>
              </tr>
              <tr>
                <th class="text-center"><h4><label for="old-pass">ENTER OLD PASSWORD</label></h4></th>
                <th>:</th>
                <td><input type="hidden" value="<?php echo $data['admin_email']?>" id="admin-email"> <input type="password" name="old_password" value="" class="form-control text-danger" id="old-pass"><strong id="pass-message"></strong></td>
              </tr>
              <tr style="display:none" class="pass-field">
                <th class="text-center"><h4><label for="name">ADMIN NAME</label></h4></th>
                <th>:</th>
                <td><input type="text" name="name" value="<?php echo $data['admin_name']?>" id="name" class=" text-uppercase form-control text-danger"> </td>
              </tr>
              <tr style="display:none" class="pass-field">
                <th class="text-center"><h4><label for="new-pass">ENTER NEW PASSWORD</label></h4></th>
                <th>:</th>
                <td> <input type="password" name="password" value="" class="form-control text-danger" id="new-pass" required></td>
              </tr>
              <tr>
                <th colspan="3"><input type="submit" name="submit" value="SUBMIT" class="btn btn-success text-white btn-block"> </th>
              </tr>
            </table>
          </form>
        </div>
      </div>
  </div>
<script type="text/javascript" src="../css/jquery-3.2.1.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
//---------check old password is valid or not--------ready-
$('#old-pass').on('keyup',function(){
     var old_password=$('#old-pass').val();
     var admin_email=$('#admin-email').val();
       $.ajax({
         url : "check_pass.php",
         type : "post",
         data : {old_password : old_password, admin_email:admin_email},
         success : function(data){
           if(data==0){
             $('#pass-message').html('<small class="text-dark">Please enter valid password</small>');
           }else{
             $('#pass-message').html('<small class="text-success">Now you can change your password</small>');
             $('.pass-field').show();
           }
         }
       });
});
 });
</script>
</body>
</html>
<?php
//---------save updated data--------------
 include('connection.php');
 if(isset($_POST['submit'])){
   $email=mysqli_real_escape_string($con,$_POST['email']);
   $old_password=mysqli_real_escape_string($con,$_POST['old_password']);
   $name=mysqli_real_escape_string($con,$_POST['name']);
   if ($name=='') {
     echo "<script>alert('Please enter valid data.')</script>";
     echo "<script>window.open('profile.php','_self')</script>";
     exit();
   }
   $password=mysqli_real_escape_string($con,$_POST['password']);
   if($password==''){
     echo "<script>alert('Please enter valid data.')</script>";
     echo "<script>window.open('profile.php','_self')</script>";
     exit();
   }
   echo
   $hash_pass=md5($password);
   $qry2="UPDATE `admin` SET `admin_name`='$name',`admin_email`='$email',`admin_password`='$hash_pass' WHERE admin_email='$email'";
   $run2=mysqli_query($con,$qry2);
   if($run2){
     echo "<script>alert('Record updated successfully.')</script>";
     echo "<script>window.open('index.php','_self')</script>";
     exit();
   }else{
     echo "<script>alert('Record is not updated successfully.')</script>";
     echo "<script>window.open('profile.php','_self')</script>";
     exit();
   }
 }
?>
