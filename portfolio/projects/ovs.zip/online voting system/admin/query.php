<!-------ready------->
<html>
<head>
  <title>user's query </title>
  <link rel="stylesheet" href="../css/bootstrap.css">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    #model{
      background: rgba(0, 0, 0, 0.9);
      position: fixed;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      z-index: 100;
      display: none;
    }
    #model-form{
      background: #fff;
      width: 40%;
      height: 5%;
      overflow-y: scroll;
      position: relative;
      top: 20%;
      margin-left: 35%;
      padding: 15px;
      border-radius: 5px;
    }
    #close-btn{
      background-color: red;
      color: white;
      width: 30px;
      height: 30px;
      text-align: center;
      border-radius: 50%;
      position: absolute;
      top: 17%;
      margin-left: 74%;
      cursor: pointer;
      box-shadow: 0px 0px 8px 5px white;
    }
    #close-btn:hover{
      box-shadow: 0px 0px 8px 9px green;
    }
  </style>
</head>
<body>
<?php include('header.php');?>
<div class="container">
  <div class="row">
    <div class="col-md-10" style="margin-left:20%">
      <table class="table table-bordered table-striped text-center">
        <tr class="bg-dark">
          <th class="text-white">Sl</th>
          <th class="text-white">User Details</th>
          <th class="text-white">Query</th>
          <th class="text-white">Reply</th>
        </tr>
        <?php
          include('connection.php');
          $qry="SELECT * FROM query ORDER BY sl_no DESC";
          $run=mysqli_query($con,$qry);
          if(mysqli_num_rows($run)<1){
            echo "<tr><th colspan='4'><h4 class='text-danger'>No query found.</h4></th></tr>";
          }
          $sl_no=1;
          while($data=mysqli_fetch_array($run)){
            echo "<tr>
                    <td style='vertical-align:middle'>$sl_no</td>
                    <td style='vertical-align:middle;text-align:left;'>
                      Name <i class='text-dark text-uppercase'>{$data['name']}</i><hr class='bg-primary'>
                      Email <i class='text-dark'>{$data['email']}</i><br>
                    </td>
                    <td style='vertical-align:middle'>{$data['message']}</td>
                    <td style='vertical-align:middle;text-align:center'>
                  ";
                    if ($data['reply']=='') {
                       echo "<button class='btn btn-success btn-block' id='reply-btn' data-id='{$data["sl_no"]}'>Reply</button>";
                    }else{
                      echo "{$data['reply']}";
                    }
              echo "</td></tr>";
          $sl_no++;}
        ?>
      </table>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-12"  id="model">
    <button id="close-btn">X</button>
    <table class="table-bordered table-striped" id="model-form" style='border:1px double red;box-shadow:0px 0px 9px 7px lightblue;'>

    </table>
  </div>
</div>
</body>
<script type="text/javascript" src="../css/jquery-3.2.1.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
//--------reply query form-------ready
  $('#reply-btn').on('click',function(){
    var query_id=$(this).data('id');
    $('#model').show();
    $.ajax({
      url : "edit_data.php",
      type : "post",
      data : {query_reply_id:query_id},
      success : function(data){
        $('#model-form').html(data);
      }
    });
  });
//---------hide model box
$('#close-btn').on("click",function(){
  $('#model').hide();
});
//--------send reply-------ready
$(document).on('click','#send-reply-btn',function(){
  var reply=$('#reply').val();
  var id=$('#query-id').val();
  if (reply[0]==' ' || reply.length=='') {
    alert('Please enter valid reply.');
    exit();
  }
  $.ajax({
    url : "reply_query.php",
    type : "post",
    data : {id:id, reply:reply},
    success : function(){
      alert('Message send successfully.');
      window.open('query.php','_self');
      exit();
    }
  });
});
});
</script>
</body>
</html>
