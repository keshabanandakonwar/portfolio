<?php
//----ready
 include('connection.php');
 $query_id=$_POST['id'];
 $reply=$_POST['reply'];
 $qry="UPDATE query SET reply='$reply',status='1' WHERE sl_no='$query_id'";
 $run=mysqli_query($con,$qry);
 if($run){
   echo "Reply send successfully.";
   exit();
 }
?>
 