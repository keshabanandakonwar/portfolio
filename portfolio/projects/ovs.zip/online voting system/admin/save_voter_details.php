<?php//no need
include('connection.php');
  $qry1="SELECT * FROM courses WHERE course_id='{$_POST['course']}'";
  $run1=mysqli_query($con,$qry1);
  $data1=mysqli_fetch_array($run1);
  $course_name=$data1['course_name'];
 $voter_id="voter/".$course_name."/".$_POST['semester']."/".$_POST['rollno']."/".date('d-m-Y')."/".rand(1,100);
 echo $voter_id;
 $qry2="INSERT INTO voters(voter_id,voter_name,voter_course,voter_semester,voter_district,voter_phone_number,voter_email,voter_status)VALUES('$voter_id','{$_POST['voter_name']}','{$_POST['course']}','{$_POST['semester']}','{$_POST['district']}','{$_POST['voter_phone_number']}','{$_POST['voter_email']}','1')";
 $run2=mysqli_query($con,$qry2);
 if($run2){
   echo "New voter inserted successfully.";
   exit();
 }
?>
