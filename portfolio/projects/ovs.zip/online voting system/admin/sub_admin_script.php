<?php
include('connection.php');
//--------fetch sub admins------ready----
$qry="SELECT admin.sl_no,admin.admin_type,admin.admin_name,admin.admin_email,admin.admin_status,department.department_name,courses.course_name FROM admin INNER JOIN department ON admin.department_id=department.department_id INNER JOIN courses ON admin.course_id=courses.course_id WHERE admin.department_id NOT IN(0) ORDER BY admin.sl_no DESC";
$run=mysqli_query($con,$qry);
if(mysqli_num_rows($run)<1){
  echo "
         <tr>
            <th class='text-center' colspan='4'><h4 class='text-danger'>No Sub Admin Found</h4></th>
         </tr>
       ";
}else{
  $slno=1;
  while($data=mysqli_fetch_array($run)){
 $output= "
      <tr class='text-center text-uppercase'>
          <td style='vertical-align:middle'>$slno</td>
          <td style='vertical-align:middle'><h5>{$data['department_name']}</h5></td>
          <td style='vertical-align:middle'><h5>{$data['course_name']}</h5></td>
          <td class='text-dark text-left'>
                  Admin Type : <b class='text-primary'>{$data['admin_type']}</b> <br>
                  Name : <b class='text-primary'>{$data['admin_name']}</b> <br>
                  Email : <b class='text-primary'>{$data['admin_email']}</b> <br>
                  Account Status :
          ";
          if($data['admin_status']==0){
                 $output.= "<b class='text-primary'>De-Active</b>";
          }else{
                 $output.= "<b class='text-primary'>Active</b>";
          }
$output.= "</td>;
          <td>
          <input type='button' data-id={$data['sl_no']} class='btn btn-secondary btn-block btn-sm' value='Edit' id='edit-subadmin'>
          ";
          if($data['admin_status']==0){
$output.= "<input type='button' data-id={$data['sl_no']} class='btn btn-success btn-block btn-sm' value='Active' id='status'>";
          }else{
$output.= "<input type='button' data-id={$data['sl_no']} class='btn btn-warning btn-block btn-sm' value='De-Active' id='status'>";
          }
$output.= "
          <input type='button' data-id={$data['sl_no']} class='btn btn-danger btn-block btn-sm' value='Delete' id='delete-admin'>
          </td>
      </tr>
         ";
  echo $output;
  $slno++;}
}
?>
