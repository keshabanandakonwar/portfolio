<?php
 include('connection.php');
 //--------update sub admin account status-------ready------
if(isset($_POST['subadmin_id'])){
   $qry1="SELECT * FROM admin WHERE sl_no='{$_POST['subadmin_id']}'" or die('no');
   $run1=mysqli_query($con,$qry1)or die('noo');
   $row=mysqli_fetch_array($run1)or die('noooooo');
   if($row['admin_status']=='0'){
     $qry2="UPDATE admin SET admin_status='1' WHERE sl_no='{$_POST['subadmin_id']}'";
     $run2=mysqli_query($con,$qry2);
   }
   if($row['admin_status']=='1'){
     $qry3="UPDATE admin SET admin_status='0' WHERE sl_no='{$_POST['subadmin_id']}'";
     $run3=mysqli_query($con,$qry3);
   }
  }
//  update election status---------ready
if(isset($_POST['election_id'])){
  $qry1="SELECT * FROM election WHERE election_id='{$_POST['election_id']}'" or die('no');
  $run1=mysqli_query($con,$qry1)or die('noo');
  $row=mysqli_fetch_array($run1)or die('noooooo');
  if($row['election_status']=='0'){
    $qry2="UPDATE election SET election_status='1' WHERE election_id='{$_POST['election_id']}'";
    $run2=mysqli_query($con,$qry2);
  }
  if($row['election_status']=='1'){
    $qry3="UPDATE election SET election_status='0' WHERE election_id='{$_POST['election_id']}'";
    $run3=mysqli_query($con,$qry3);
  }
 }

//update position status-----------ready
if(isset($_POST['position_id'])){
   $qry="SELECT * FROM positions WHERE position_id='{$_POST['position_id']}'";
   $run=mysqli_query($con,$qry);
   $row=mysqli_fetch_array($run);
   if($row['position_status']=='1'){
     $qry1="UPDATE positions SET position_status='0' WHERE position_id='{$_POST['position_id']}'";
     $run1=mysqli_query($con,$qry1);
   }
   if($row['position_status']=='0'){
     $qry2="UPDATE positions SET position_status='1' WHERE position_id='{$_POST['position_id']}'";
     $run2=mysqli_query($con,$qry2);
   }
  }
// approve candidate------ready
if (isset($_POST['approve_candidate_id'])){
   $qry="UPDATE candidate SET candidate_status='1' WHERE voter_id='{$_POST['approve_candidate_id']}' AND election_id='{$_POST['electionId']}'";
   $run=mysqli_query($con,$qry);
   if ($run){
     echo 1;
   }
 }
// un approve candidate status
 if(isset($_POST['toUnApprove_candidate'])){
   $qry="UPDATE candidate SET candidate_status='0' WHERE candidate_id='{$_POST['toUnApprove_candidate']}'";
   $run=mysqli_query($con,$qry);
   if ($run){
     echo "ok";
   }
 }
// update course status-----ready
 if(isset($_POST['course_id'])){
   $qry="SELECT * FROM courses WHERE course_id='{$_POST['course_id']}'";
   $run=mysqli_query($con,$qry);
   $row=mysqli_fetch_array($run);
   if($row['course_status']=='1'){
     $qry1="UPDATE courses SET course_status='0' WHERE course_id='{$_POST['course_id']}'";
     $run1=mysqli_query($con,$qry1);
   }
   if($row['course_status']=='0'){
     $qry2="UPDATE courses SET course_status='1' WHERE course_id='{$_POST['course_id']}'";
     $run2=mysqli_query($con,$qry2);
   }
  }
// update semester status-----ready
  if(isset($_POST['semester_id'])){
    $qry="SELECT * FROM semester WHERE semester_id='{$_POST['semester_id']}'";
    $run=mysqli_query($con,$qry);
    $row=mysqli_fetch_array($run);
    if($row['semester_status']=='1'){
      $qry1="UPDATE semester SET semester_status='0' WHERE semester_id='{$_POST['semester_id']}'";
      $run1=mysqli_query($con,$qry1);
    }
    if($row['semester_status']=='0'){
      $qry2="UPDATE semester SET semester_status='1' WHERE semester_id='{$_POST['semester_id']}'";
      $run2=mysqli_query($con,$qry2);
    }
   }
// update department status------ready
if(isset($_POST['department_id'])){
  $qry="SELECT * FROM department WHERE department_id='{$_POST['department_id']}'";
  $run=mysqli_query($con,$qry);
  $row=mysqli_fetch_array($run);
  if($row['department_status']=='1'){
    $qry1="UPDATE department SET department_status='0' WHERE department_id='{$_POST['department_id']}'";
    $run1=mysqli_query($con,$qry1);
  }
  if($row['department_status']=='0'){
    $qry2="UPDATE department SET department_status='1' WHERE department_id='{$_POST['department_id']}'";
    $run2=mysqli_query($con,$qry2);
  }
 }
//update voter status
 if(isset($_POST['voter_status'])){
   $qry="SELECT * FROM voters WHERE voter_id='{$_POST['voter_status']}'";
   $run=mysqli_query($con,$qry);
   $data=mysqli_fetch_array($run);
   if($data['voter_status']=='0'){
     $qry2="UPDATE voters SET voter_status='1' WHERE voter_id='{$_POST['voter_status']}'";
     $run2=mysqli_query($con,$qry2);
   }
   if($data['voter_status']=='1'){
     $qry2="UPDATE voters SET voter_status='0' WHERE voter_id='{$_POST['voter_status']}'";
     $run2=mysqli_query($con,$qry2);
   }
 }
 //update multiple voter status---------
 if(isset($_POST['multiple_voter_update'])){
   $qry="SELECT * FROM voters WHERE voter_id='{$_POST['multiple_voter_update']}'";
   $run=mysqli_query($con,$qry);
   $data=mysqli_fetch_array($run);
   if($data['voter_status']=='0'){
     $qry2="UPDATE voters SET voter_status='1' WHERE voter_id='{$_POST['multiple_voter_update']}'";
     $run2=mysqli_query($con,$qry2);
   }
   if($data['voter_status']=='1'){
     $qry2="UPDATE voters SET voter_status='0' WHERE voter_id='{$_POST['multiple_voter_update']}'";
     $run2=mysqli_query($con,$qry2);
   }
 }
?>
