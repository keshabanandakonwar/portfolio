<?php//no need-----------
include('connection.php');
//code to accept voter request
if(isset($_POST['accept_election_id'])){
  $voter_id=$_POST['accept_voter_id'];
  $election_id=$_POST['accept_election_id'];
  $qry1="UPDATE vote SET vote_status='0' WHERE voter_id='$voter_id' AND election_id='$election_id'";
  $run1=mysqli_query($con,$qry1);
}
//code to cancel voter request
if(isset($_POST['cancel_voter_id'])){
  $voter_id=$_POST['cancel_voter_id'];
  $election_id=$_POST['cancel_election_id'];
  $qry1="DELETE FROM vote WHERE voter_id='$voter_id' AND election_id='$election_id'";
  $run2=mysqli_query($con,$qry1);
}

?>
