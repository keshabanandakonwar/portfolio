<?php
 include('connection.php');
 //------view candidate details---------ready
 if (isset($_GET['candidate_id'])){
   $qry="SELECT candidate.election_id,election.election_name,candidate.photo,department.department_name,courses.course_name,semester.semester_name,voters.voter_rollno,election.election_date,voters.voter_id,voters.voter_state,voters.voter_district,voters.voter_postoffice,voters.voter_pinno,voters.voter_village,voters.voter_email,voters.voter_phone_number,candidate.candidate_status,positions.position_name,voters.voter_fname,voters.voter_lname FROM candidate INNER JOIN positions ON positions.position_id=candidate.position_id INNER JOIN election ON candidate.election_id=election.election_id INNER JOIN voters ON voters.voter_id=candidate.voter_id INNER JOIN department ON voters.voter_department=department.department_id INNER JOIN courses ON voters.voter_course=courses.course_id INNER JOIN semester ON voters.voter_semester=semester.semester_id WHERE candidate.voter_id='{$_GET['candidate_id']}' AND candidate.election_id='{$_GET['election_id']}'";
   $run=mysqli_query($con,$qry);
   $data=mysqli_fetch_array($run);
   if($run){
     echo "<tbody><tr><th colspan='2'><h4 class='text-center bg-success p-4'>Candidate Details</h4></th></tr>
          <tr><td>
            <div class='form-group pl-3 m-0'>
              <label class='text-danger'>Candidate Details----</label><hr class='p-0 m-0 bg-warning'>
              <i>Vote Id : </i><strong class='text-primary'>{$data['voter_id']}</strong><br>
               <i>Candidate Name : </i><strong class='text-primary text-uppercase'>{$data['voter_fname']} {$data['voter_lname']}</strong><br>
               <i>Candidate Department : </i><strong class='text-primary text-uppercase'>{$data['department_name']}</strong><br>
               <i>Candidate Course : </i><strong class='text-primary text-uppercase'>{$data['course_name']} ({$data['semester_name']})</strong><br>
               <i>Candidate Roll No : </i><strong class='text-primary'>{$data['voter_rollno']}</strong><br>
               <i>Candidate Email : </i><strong class='text-primary'>{$data['voter_email']}</strong><br>
               <i>Candidate phone : </i><strong class='text-primary'>{$data['voter_phone_number']}</strong><br>
               <i>Candidate Address : </i>
                             <textarea class='form-control' rows='3' cols='40'>
  STATE : {$data['voter_state']}
  DISTRICT : {$data['voter_district']}
  POST OFFICE : {$data['voter_postoffice']}
  PIN NO : {$data['voter_pinno']}
  VILLAGE / TOWN : {$data['voter_village']}
                             </textarea>
           </div>
           <div class='form-group pl-3'>
             <label class='text-danger mb-0'>Apply to----</label><hr class='p-0 m-0 bg-warning'>
             <i>Election Id : </i><strong class='text-primary'>{$data['election_id']}</strong><br>
              <i>Election Name : </i><strong class='text-primary text-uppercase'>{$data['election_name']}</strong><br>
              <i>Election Date : </i><strong class='text-primary'>{$data['election_date']}</strong><br>
              <i>Position Name : </i><strong class='text-primary text-uppercase'>{$data['position_name']}</strong>
          </div>
            </td>
            <td style='border-left:2px solid purple;width:40%'><img src='../{$data['photo']}' alt='candidate image' style='width:100%'></td></tr></tbody>
          ";
   }
 }
?>
