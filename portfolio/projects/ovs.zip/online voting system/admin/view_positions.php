<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>elections</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <meta name="viewport" content="width=device-width,initial-scale=1">
  </head>
  <body>
    <?php include('header.php'); ?>
    <div class="container">
      <div class="row">
        <div class="col-md-10" style="margin-left:20%">
          <table class="table text-center table-bordered table-striped table-hover">
            <thead class="bg-success">
              <tr class="bg-primary text-warning">
                <th colspan="5" class="text-center text-white">POSITION NAMES</th>
              </tr>
              <tr>
                <th>Sl No</th>
                <th>Election Name</th>
                <th>POSITION NAME</th>
                <th>ELIGIBILITY</th>
                <th>ACTION</th>
              </tr>
            </thead>
            <tbody>
              <?php
              include('connection.php');
              //  $qry1="SELECT election.election_id,election.election_name,positions.position_name,positions.sl_no FROM positions INNER JOIN election ON election.election_id=positions.election_id ORDER BY positions.sl_no DESC";
                $qry1="SELECT * FROM election WHERE status='1'";
                $run1=mysqli_query($con,$qry1);
                $check=mysqli_num_rows($run1);
                if($check<0){
                  echo "<tr><th colspan='5'>No data found</th></tr>";
                }
                $slno=1;
                while($data1=mysqli_fetch_array($run1)){
              ?>
              <tr>
                <td><?php echo $slno ?></td>
                <td><?php echo $data1['election_name']?></td>
                <td>
                  <?php
                   $election_id=$data1['election_id'];
                   $qry2="SELECT DISTINCT position_name FROM positions WHERE election_id='$election_id'";
                   $run2=mysqli_query($con,$qry2);
                   while($data2=mysqli_fetch_array($run2)){
                  ?>
                   <h5><?php echo $data2['position_name']?></h5><hr>
                  <?php }?>
                </td>
                <td>
                  <?php
                    $position_name=$data2['position_name'];
                    $qry3="SELECT eligibility FROM positions WHERE position_name='$position_name'";
                    $run3=mysqli_query($con,$qry3);
                    while($data3=mysqli_fetch_array($run3)){
                  ?>
                  <select class="form-control" name="">
                    <option disabled selected>SEE ELIGIBILITY</option>
                    <option value=""><?php echo $data3['eligibility']?></option>
                  </select>
                <?php } ?>
                </td>
                <td>
                <!--  <a href="edit_position.php?id=<?php echo $position_id ?>" class="btn btn-success">EDIT</a>
                  <a href="delete_position.php?id=<?php echo $position_id ?>" class="btn btn-danger">DELETE</a>
                   <?php
                      if($data2['status']=='0'){
                   ?>
                  <!-- <a href="update_status.php?id=<?php echo $row['sl_no']?>" class="btn btn-secondary">DE-ACTIVE </a>-->
                  <a href="update_status.php?id=<?php echo $position_id?>" ><input type="button" class="btn btn-warning" name="position_status" value="DE-ACTIVE"></a>
                 <?php }else{?>
                  <!-- <a href="update_status.php?id=<?php echo $row['sl_no']?>" class="btn btn-primary">ACTIVE </a>-->
                  <a href="update_status.php?id=<?php echo $position_id?>" ><input type="submit" class="btn btn-success" name="position_status" value="ACTIVE"></a>
                <?php } ?>-->
                </td>
              </tr>
            <?php $slno+=1; } ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </body>
</html>
