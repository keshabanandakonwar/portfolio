<!--------no need---->
<html lang="en" dir="ltr">
  <head>
    <title>voter request </title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <meta name="viewport" content="width=device-width,initial-scale=1">

  </head>
  <body>
    <?php include('header.php'); ?>
    <div class="container">
      <div class="row">
        <div class="col-md-10" style="margin-left:20%">
            <!--------form to allow voters to vote in a election ----------->


     <!------------code to show positions details--------------------->
          <table class="table table-bordered mb-4 table-striped table-hover">
            <tr class='bg-dark text-center'>
               <th class="text-white">Sl No</th>
               <th class="text-white">Voter Details </th>
               <th class="text-white">Election</th>
               <th class="text-white">Request</th>
            </tr>
            <tbody id="voters">


            </tbody>
          </table>

        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-12"  id="model">
        <button id="close-btn">X</button>
        <table class="table-bordered table-striped" id="model-form" style='border:1px double red;box-shadow:0px 0px 9px 7px lightblue;'>

        </table>

      </div>
    </div>
<script type="text/javascript" src="../css/jquery-3.2.1.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
   function  loadData(){
     $.ajax({
       url : "fetch_applied_voters.php",
       type : "GET",
       success : function(data){
         $('#voters').html(data);
       }
     });
   }
  loadData();
//code to cancel voter request
$(document).on("click",'#cancel-btn',function(){
    var vid=$(this).data("vid");
    var eid=$(this).data("eid");
    if(confirm('Are you sure to remove this record ? ')){
    $.ajax({
      url : "update_voter_request.php",
      type : "POST",
      data : {cancel_voter_id:vid,cancel_election_id:eid},
      success : function(data){
        loadData();
      }
    });
   }
 });
 //code to accept voter request
 $(document).on("click",'#accept-btn',function(){
     var vid=$(this).data("vid");
     var eid=$(this).data("eid");
     if(confirm('Are you sure to accept voter request ? ')){
     $.ajax({
       url : "update_voter_request.php",
       type : "POST",
       data : {accept_election_id:eid,accept_voter_id:vid},
       success : function(data){
         loadData();
       }
     });
   }
  });
});
</script>
  </body>
</html>
