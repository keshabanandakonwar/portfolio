<html>
   <head>
     <title>voters</title>
     <link rel="stylesheet" href="../css/bootstrap.css">
     <meta name="viewport" content="width=device-width,initial-scale=1">
     <style media="screen">
       #option{
         display: none;
         position: fixed;
         top: 20%;
         right: 5%;
       }
     </style>
   </head>
   <body>
     <?php include('header.php'); ?>
        <div class="container">
          <div class="row">

            <div class="col-12" style="margin-left:10%;padding-top:0px;">
              <!---------search data --------->
              <table class="table table-bordered bg-white">
                <tr class="text-center">
                  <th><b> Search : </b></th>
                  <td>
                    <input type="text" id="search_data" placeholder="search Voter id / Department name" class="form-control" name="" value="">
                  </td>
                  <td>
                     <button type="Search" id="search_btn" class="btn btn-success btn-block" name="button">Search</button>
                  </td>
                </tr>
              </table>
            </div><br>

            <div class="col-12"  style="margin-left:12%;padding-top:0px;">
                
               <table class="table table-bordered table-striped" id="voters-table">
               </table>
            </div>
          </div>
        </div>
        <script type="text/javascript" src="../css/jquery-3.2.1.min.js"></script>
        <script type="text/javascript">
$(document).ready(function(){
//----------show voters data --------------ready
function loadData(){
    $.ajax({
          url : "fetch_all_voters.php",
          type : "get",
          success : function(data){
          $('#voters-table').html(data);
    }
    });
}
loadData();
//-------change voter status--------
$(document).on("click","#voter_status",function(){
  var id=$(this).data("id");
  $.ajax({
    url : "update_status.php",
    type : "post",
    data : {voter_status : id},
    success : function(){
      loadData();
    }
  });
});
//------search -----------
$('#search_btn').on('click',function(){
  var search_data=$('#search_data').val();
  $.ajax({
    url : "search_voter.php",
    type : "post",
    data : {search_data :search_data},
    success : function(data){
      $('#voters-table').html(data);
    }
  });
});
//-----------checkbox-----------
$(document).on("click","#checkbox-data",function(){
  $("#option").show();
    var id=[];
    id.toString(id);
    $(":checkbox:checked").each(function(key){
      id.push($(this).data('id'));
      alert(id);
      $.ajax({
        url : "update_status.php",
        type : "post",
        data : {multiple_voter_update:id},
        success : function(data){
          alert(data);
        }
      });
    });
});
});
</script>
   </body>
 </html>
