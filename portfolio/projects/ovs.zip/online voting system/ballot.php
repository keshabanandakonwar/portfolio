<?php
 session_start();
 if(!isset($_SESSION['voter_id'])){
   header("location:login.php");
   exit();
 }
?> 
<html>
  <head>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <style>
    #model{
      background: rgba(0, 0, 0, 0.9);
      position: fixed;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      z-index: 100;
      display: none;
    }
    #model-form{
      background: #fff;
      width: 50%;
      position: relative;
      top: 4%;
      left: calc(50%-25%);
      margin-left: 25%;
      padding: 15px;
      border-radius: 5px;
    }
    #close-btn{
      background-color: red;
      color: white;
      width: 30px;
      height: 30px;
      text-align: center;
      border-radius: 50%;
      position: absolute;
      top: 5%;
      margin-left: 75%;
      cursor: pointer;
      box-shadow: 0px 0px 8px 5px white;
    }
    #close-btn:hover{
      box-shadow: 0px 0px 8px 9px green;
    }
    .alert{
      position:fixed;
      top:20px;
      right:50px;
      background-color:skyblue;
      display:none;
    }
    .success{
      position:fixed;
      top:20px;
      right:50px;
      background-color:skyblue;
      display:none;
    }
    </style>
  </head>
<body>
<?php include('header.php')?>
 <div class="container">
   <div class="row"><hr>
     <div class="col-md-5 p-5">
       <img src="admin/system_images/logo.png" alt="logo" width="100%">
     </div>
     <div class="col-md-7 mt-5">
       <form>
         <div class="alert text-danger text-center m-5 p-2">Already voted.</div><div class="success text-success text-center m-5 p-2">Successfully voted.</div>
         <table class="table bg-light table-striped table-hover table-bordered m-5">
           <tr>
             <th class="text-center" style="background-color:purple;color:white"><h3>BALLOT PAPPER</h3></th>
           </tr>
           <tr>
             <td>
               <select class="form-control" id="election-id">
                 <option disabled selected>Select Election</option>
                 <?php
                  include('admin/connection.php');
                   $qry1="SELECT * FROM election WHERE election_status='1'";
                   $run1=mysqli_query($con,$qry1);
                   while($data1=mysqli_fetch_array($run1)){
                 ?>
                 <option value="<?php echo $data1['election_id']?>"><?php echo $data1['election_name']?></option>
               <?php } ?>
             </select>
             </td>
           </tr>
           <tr>
             <td id="positions" class="p-0 table table-responsive"></td>
           </tr>
           <div id="temp">

           </div>
           <div id="temp-data">
             
           </div>
        <!---   <tr>
             <th colspan="3" class="text-center"><input type="submit" id="candidate-request-form" value="Vote" class="btn btn-success form-control"> </th>
           </tr>--->
         </table>
       </form>
     </div>
   </div>
 </div>
 <div class="row">
   <div class="col-12"  id="model">
     <button id="close-btn">X</button>
     <table class="table-striped" id="model-form">

     </table>
   </div>
 </div>
 <?php include('footer.php') ?>
<script type="text/javascript" src="css/jquery-3.2.1.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
//--------show candidates--------ready---
$('#election-id').on("change",function(){
  var election_id=$('#election-id').val();
  $.ajax({
    url : "fetch_position.php",
    type : "post",
    data : {election_id : election_id},
    success : function(data){
      $('#positions').html(data);
    }
  });
});
//--------- view candidate details----------ready
$(document).on("click","#candidate-details",function(){
  var vid=$(this).data("vid");
  var eid=$(this).data("eid");
  $.ajax({
    url : "fetch_candidate_data.php",
    type : "post",
    data : {voter_id : vid,election_id:eid},
    success : function(data){
        var heading='Candidate Details\n';
        alert(heading+data);
        window.open('ballot.php','_self');
    }
  });
 });
 
//------------vote------
$(document).on('click','#vote',function(){
  if(confirm("Are you sure ?")){
     var electionId=$(this).data("electionid");
     var positionId=$(this).data("positionid");
     var candidateId=$(this).data("candidateid");
     $.ajax({
        url : "save_vote.php",
        type : "post",
        data : {electionId:electionId, positionId:positionId, candidateId:candidateId},
        success : function(data){
          if(data=='0'){            
            $('.alert').show();
          setTimeout(function(){
            $('.alert').hide();
          },3000);
          }else{
            $('.success').show();
            setTimeout(function(){
            $('.success').hide();
          },3000);
          }
        }
     });
  }else{
    alert("un checked");
  }
});

});
</script>
</body>
</html>
