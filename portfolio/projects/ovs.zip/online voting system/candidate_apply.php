<?php
 session_start();
 if(!isset($_SESSION['voter_id'])){
   header("location:login.php");
   exit();
 }
 include('admin/connection.php');
 $qry1="SELECT voters.voter_fname,voters.voter_lname,voters.voter_email,voters.voter_id,voters.voter_state,voters.voter_district,voters.voter_postoffice,voters.voter_pinno,voters.voter_village,voters.voter_phone_number,department.department_name,courses.course_name,semester.semester_name FROM voters INNER JOIN department ON voters.voter_department=department.department_id INNER JOIN courses ON voters.voter_course=courses.course_id INNER JOIN semester ON courses.course_id=semester.course_id WHERE voters.voter_id='{$_SESSION['voter_id']}'";
 $run1=mysqli_query($con,$qry1);
 $data1=mysqli_fetch_array($run1);
?>
<html>
  <head>
    <title>candidate apply page</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link href="admin/assets/css/lib/font-awesome.min.css" rel="stylesheet">
    <style media="screen">
      @media (min-width:1024px) {
       #candidate-apply{
         padding-left:130px;
       }
      }
    </style>
  </head>
  <body style="background-color:#c3c9ed">
<?php include('header.php');?>
<!----banner---->
<section style="background-image:url('images/download.jpg')">
  <div class="container">
    <div class="row">
      <div class="col-12 text-center text-white p-5 mt-5 mb-5">
        <h2>CANDIDATE APPLICATION FORM</h2>
        <h4 class="mt-5"><a href="index.php"> HOME </a>/<i class="text-danger"> Candidate application form </i></h4>
      </div>
    </div>
  </div>
</section>
    <div class="container">
      <div class="row">
        <!------profile------>
        <div class="col-lg-4 mt-2 border p-0 pt-4">
          <div class=" text-center bg-light">
            <h4 class="text-uppercase p-3 mt-0" style="border-bottom:2px red solid;background-color:#dfc2c2;font-family:cursive">PROFILE</h4>
            <img src="images/photo/2.png">
          </div>
          <div class="form-group">
            <h5 id="personal-details-btn" style="border-bottom:1px solid purple;background-color:lightblue" class="text-primary p-3">PERSONAL DETAILS <span class="fa fa-angle-down fa-lg float-right mr-3 text-danger"></span> </h5>
          </div>
            <div class="form-group pl-3 pdetails bg-light" id="personal-details">
            <label >Name : </label>
            <i class="text-uppercase"><?php echo $data1['voter_fname']." ".$data1['voter_lname']?></i><br>
            <label >Voter Id: </label>
            <i><?php echo $data1['voter_id']?></i><br>
            <label >Mobile Number : </label>
            <i class="text-uppercase"><?php echo $data1['voter_phone_number']?></i><br>
            <label >Email Id : </label>
            <i><?php echo $data1['voter_email']?></i><br>
            <label >Mobile Number : </label>
            <i><?php echo $data1['voter_phone_number']?></i><br>
            <label >Address : </label>
            <i>
               <p class="ml-3">
                   <strong>STATE : </strong><i><?php echo $data1['voter_state']?></i><br>
                   <strong>DISTRICT : </strong><i><?php echo $data1['voter_district']?></i><br>
                   <strong>POST OFFICE : </strong><i><?php echo $data1['voter_postoffice']?></i><br>
                   <strong>PIN NO : </strong><i><?php echo $data1['voter_pinno']?></i><br>
                   <strong>VILLAGE/TOWN : </strong><i><?php echo $data1['voter_village']?></i>
               </p>
            </i>
          </div>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <div class="form-group">
            <h5 id="edu-details-btn" style="border-bottom:1px solid purple;background-color:lightblue" class="text-primary p-3">EDUCATIONAL DETAILS <span class="fa fa-angle-down fa-lg float-right mr-3 text-danger"></span> </h5>
          </div>
          <div class="form-group bg-light pl-3 edudetails" id="edu-details">
            <label>Dept./School : </label><hr class="p-0 m-0">
            <i class="text-uppercase"><?php echo $data1['department_name']?></i><br>
            <label>Course : </label>
            <i class="text-uppercase"><?php echo $data1['course_name']?></i><br>
            <label>Semester : </label>
            <i class="text-uppercase"><?php echo $data1['semester_name']?></i>
          </div>
        </div>

     <!-----------candidate application form---------->
        <div class="col-lg-8 mt-2 p-4" id="candidate-apply">
            <form class="form" action="candidate_apply_script.php" method="post" enctype="multipart/form-data">
              <table class="table bg-light table-striped table-hover table-bordered">
                <tr>
                  <th colspan="3" class="text-center text-white" style="background-color:purple"><h3>CANDIDATE APPLY</h3><hr class="m-0 bg-info"><span id="message" class="text-warning"></span> </th>
                </tr>
                <tr class="d-none">
                  <th>Voter Id</th>
                  <th><input type="text" name="voter_id" value="<?php echo $_SESSION['voter_id']?>"> </th>
                </tr>
                <tr>
                  <th>Select Election</th>
                  <td>
                    <select class="form-control" id="election-id" name="election_id">
                      <option disabled selected>Select Election</option>
                      <?php
                          $qry2="SELECT * FROM election WHERE election_status='1'";
                          $run2=mysqli_query($con,$qry2);
                          while($data2=mysqli_fetch_array($run2)){
                      ?>
                      <option value="<?php echo $data2['election_id']?>"><?php echo $data2['election_name'] ?></option>
                    <?php } ?>
                    </select>
                  </td>
                </tr>
                <tr>
                  <th>Select Position</th>
                  <td>
                      <select class="form-control" id="position-id" name="position_id"></select>
                  </td>
                </tr>
                <tr>
                  <th>Post Elligibility</th>
                  <td><textarea rows="4" cols="40" class="form-control text-primary" id="eligibility" readonly></textarea> </td>
                </tr>
                <tr>
                  <th>Candidate Photo</th>
                  <td><input type="file" class="form-control" name="photo" required> </td>
                </tr>
                <tr>
                  <th colspan="3" class="text-center"><input type="submit" id="candidate-request-form" value="Send Request" class="btn btn-success form-control"> </th>
                </tr>
              </table>
            </form>
            </div>
        </div>
    </div>
<?php include('footer.php'); ?>
<script type="text/javascript" src="css/jquery-3.2.1.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    // load position names when user select election/change election
      $('#election-id').on("change",function(){
        var election_id=$('#election-id').val();
        $.ajax({
          url : "fetch_dependent_position.php",
          type : "post",
          data : {election_id : election_id},
          success : function(data){
            $('#position-id').html(data);
          }
        });
      });
    // load position Elligibility when user select position/change position
    $('#position-id').on("change",function(){
      var position_id=$(this).val();
      $.ajax({
        url : "fetch_dependent_eligibility.php",
        type : "post",
        data : {position_id:position_id},
        success : function(data){
          $('#eligibility').html(data);
        }
      });
    });
   //---------profile toggle---------
   $('#personal-details-btn').on('click',function(){
     $('#personal-details').toggle(1000);
   });
   $('#edu-details-btn').on('click',function(){
     $('#edu-details').toggle(1000);
   });


  });
</script>
  </body>
</html>
