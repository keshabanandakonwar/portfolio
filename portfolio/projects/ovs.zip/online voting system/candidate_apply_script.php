<?php
//---------------ready--------------
include("admin/connection.php");
$voter_id=mysqli_real_escape_string($con,$_POST['voter_id']);
$election_id=mysqli_real_escape_string($con,$_POST['election_id']);
$position_id=mysqli_real_escape_string($con,$_POST['position_id']);
$qry1="SELECT * FROM candidate WHERE voter_id='$voter_id' AND election_id='$election_id'";
$run1=mysqli_query($con,$qry1);
if(mysqli_num_rows($run1)>0){
  echo "<script>alert('You have already applied.')</script>";
  echo "<script>window.open('candidate_apply.php','_self')</script>";
  exit();;
}
   $file_name= $_FILES['photo']['name'];
   $temp_name=$_FILES['photo']['tmp_name'];
   $file_store="upload/".$file_name;
   $image1=move_uploaded_file($temp_name,$file_store);

$qry2="INSERT INTO candidate(voter_id,election_id,position_id,photo)VALUES('$voter_id','$election_id','$position_id','$file_store')";
$run2=mysqli_query($con,$qry2);
if($run2){
  echo "<script>alert('Congratulation,Your application submitted successfully.')</script>";
  echo "<script>window.open('home.php','_self')</script>";
  exit();
}





?>
