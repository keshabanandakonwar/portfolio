
<!--ready-->
<html>
<head>
  <title>contact us</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="css/font-awesome.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link href="css/style.css" rel="stylesheet">
  <script type="text/javascript" src="css/jquery-3.2.1.min.js">

  </script>
</head>
<body>
<div class="page-wrapper">
<?php include('social_media_link.php')?>
<?php include('navbar.php')?>
<!--banner-->
<section class="page-title text-center" style="background-image:url(images/images.jpg)">
    <div class="container">
        <div class="title-text">
            <h1>Contact Us</h1>
            <ul class="title-menu clearfix">
                <li>
                    <a href="index.php">home &nbsp;/</a>
                </li>
                <li>Contact</li>
            </ul>
            <ul class="P-0">
              <li><h3 class="text-white">Assam Rajiv Gandhi University of Cooperative Management</h3></li>
            </ul>
        </div>
    </div>
</section>
<section class="section contact">
  <div class="container">
    <div class="row">
      <div class="col-lg-4">
        <div class="row text-center">
          <div class="col-lg-4">
            <h2><i class="fa fa-home text-secondary"></i></h2>
          </div>
          <div class="col-lg-8">
            <h3 class="text-primary">Location</h3>
            <p class="text-danger">
              State : Assam <br>
              District : Sivasagar <br>
              Post Office : Nitai Pukhuri <br>
              Land Mark : Bank Of Nitai Pukhuri
            </p>
          </div>
          <div class="col-lg-4">
            <h2><i class="fa fa-phone text-success"></i></h2>
          </div>
          <div class="col-lg-8">
            <h3 class="text-primary">Phone</h3>
            <p class="text-danger">
                9854481365
              <br> 8720927454
            </p>
          </div>
          <div class="col-lg-4">
            <h2><i class="fa fa-envelope text-danger"></i></h2>
          </div>
          <div class="col-lg-8">
            <h3 class="text-primary">Email</h3>
            <p class="text-danger">
              devabrotkonwar69@gmail.com
              <br>keshab2000@gmail.com
            </p>
          </div>
        </div>
      </div>
      <div class="col-lg-8">
        <div class="contact-form">
          <form class="row mt-5">
            <div class="col-md-6">
              <input type="text" id="name" class="form-control" placeholder="Name" required>
            </div>
            <div class="col-md-6">
              <input type="email" id="email" class="form-control main" placeholder="Email" required>
            </div>
            <div class="col-lg-12">
              <textarea id="message" rows="10" class="form-control main" placeholder="Your message"></textarea>
            </div>
            <div class="col-md-12 text-right">
              <input type="submit" id="submit-btn" value="SEND MESSAGE" class="btn btn-custom btn-lg text-success border" style="box-shadow:0px 0px 9px 1px green;">
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
</div>
<?php include("footer.php")?>
<script src="plugins/jquery.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $('#submit-btn').on('click',function(){
      var name = $('#name').val();
      var email = $('#email').val();
      var message = $('#message').val();
      $.ajax({
        url : "query_script.php",
        type : "post",
        data : {name : name, email : email, message : message},
        success : function(data){
          alert(data);
        }
      });
    });
  });
</script>
</body>
</html>
