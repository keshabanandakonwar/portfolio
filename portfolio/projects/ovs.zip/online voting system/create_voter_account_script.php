<?php
include("admin/connection.php");
$fname=mysqli_real_escape_string($con,$_POST['fname']);
$lname=mysqli_real_escape_string($con,$_POST['lname']);
$email=mysqli_real_escape_string($con,$_POST['email']);
$number=mysqli_real_escape_string($con,$_POST['number']);
$dept=mysqli_real_escape_string($con,$_POST['dept']);
$course=mysqli_real_escape_string($con,$_POST['course']);
$semester=mysqli_real_escape_string($con,$_POST['semester']);
$rollno=mysqli_real_escape_string($con,$_POST['rollno']);
$state=mysqli_real_escape_string($con,$_POST['state']);
$district=mysqli_real_escape_string($con,$_POST['district']);
$postoffice=mysqli_real_escape_string($con,$_POST['postoffice']);
$pinno=mysqli_real_escape_string($con,$_POST['pinno']);
$village=mysqli_real_escape_string($con,$_POST['village']);
$password=mysqli_real_escape_string($con,$_POST['password']);
$hash_pass=md5($password);

$qry2="SELECT * FROM courses WHERE course_id='$course'";
$qry2=mysqli_query($con,$qry2);
$data2=mysqli_fetch_array($qry2);
$course_name=$data2['course_name'];
$date=date('Y');
$voter_id="Voter/".$date."/".$course_name."/".$semester."/".$rollno;

$qry1="SELECT * FROM voters WHERE voter_email='$email' OR voter_id='$voter_id'";
$run1=mysqli_query($con,$qry1);
if(mysqli_num_rows($run1)>0){
  echo 'error';
  exit();
}

$qry3="INSERT INTO voters(voter_id,voter_fname,voter_lname,voter_email,voter_phone_number,voter_department,voter_course,voter_semester,voter_rollno,voter_state,voter_district,voter_postoffice,voter_pinno,voter_village,voter_password,voter_status)
VALUES('$voter_id','$fname','$lname','$email','$number','$dept','$course','$semester',$rollno,'$state','$district','$postoffice','$pinno','$village','$hash_pass','0')";
$run3=mysqli_query($con,$qry3);
if($run3){
  echo $voter_id;
  session_start();
  $_SESSION['voter_id']=$voter_id;
  $_SESSION['voter_email']=$email;
  exit();
}
?>
