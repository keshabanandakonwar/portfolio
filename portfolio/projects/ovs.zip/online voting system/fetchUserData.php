<!---------- fetch and display user data when login-------------->
<!---------------------ready------------------->
<?php
 include('admin/connection.php');
 $id=$_POST['voter_id'];
 if(isset($_POST['voter_id'])){
   $qry="SELECT voters.voter_id,voters.voter_fname,voters.voter_lname,voters.voter_email,voters.voter_phone_number,department.department_name,courses.course_id,courses.course_name,semester.semester_name,voters.voter_state,voters.voter_district,voters.voter_postoffice,voters.voter_pinno,voters.voter_village FROM voters INNER JOIN department ON voters.voter_department=department.department_id INNER JOIN courses ON voters.voter_course=courses.course_id INNER JOIN semester ON voters.voter_semester=semester.semester_id WHERE voters.voter_id='$id'";
   $run=mysqli_query($con,$qry);
   if($check=mysqli_num_rows($run)<1){
     echo "<h5 class='text-danger'>Please enter valid voter id.</h5>";
   }else {
     $row=mysqli_fetch_array($run);
     if($row){
     echo $output="
     <div class='col-12 form-group bg-dark'>
       <h4 class='text-center p-3 text-white'>YOUR DETAILS</h4>
     </div>
       <div class='col-md-6 form-group'>
         <label><b>Voter Id</b></label>
         <input type='text' class='form-control' id='voter-id' value='{$_POST["voter_id"]}' readonly>
       </div>
       <div class='col-md-6 form-group'>
         <label><b>Voter Phone Number</b></label>
         <input type='text' class='form-control' value='{$row['voter_phone_number']}' readonly>
       </div>
       <div class='col-md-6 form-group'>
         <label><b>Name</b></label>
         <input type='text' class='form-control text-uppercase' value='{$row['voter_fname']} {$row['voter_lname']}' readonly>
       </div>
       <div class='col-md-6 form-group'>
         <label><b>School / Department</b></label>
         <input type='text' class='form-control text-uppercase text-italic' value='{$row['department_name']}' readonly>
       </div>
       <div class='col-md-6 form-group'>
         <label><b>Course</b></label>
         <input type='text' class='form-control text-uppercase' value='{$row['course_name']}({$row['semester_name']})' readonly>
       </div>

       <div class='col-lg-6 form-group'>
         <label><b>Email id</b></label>
         <input type='email' class='form-control' value='{$row['voter_email']}' readonly>
       </div>
       <div class='col-12 form-group'>
         <label><b>Address</b></label>
         <textarea class='form-control' rows='5' readonly>
            State : {$row['voter_state']}
            District : {$row['voter_district']}
            Post Office : {$row['voter_postoffice']}
            Pin No : {$row['voter_pinno']}
            Town/Village : {$row['voter_village']}
         </textarea>
       </div>

       <div class='col-12 form-group'>
         <label for='voter-password'><b>Voter Password</b></label>
         <input type='password' class='form-control' id='voter-password' placeholder='Enter your password'>
       </div>
       <div class='col-12 form-group'>
         <p class='text-warning text-center'><b>After successfully login,you can update your details.</b></p>
       </div>
       <div class='col-12 form-group text-center'>
         <input type='submit' class='btn btn-primary' value='LOGIN' id='voter-login'>
       </div>

             ";
      }
   }

 }
?>
