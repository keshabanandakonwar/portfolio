<?php
//---------ready------
include('admin/connection.php');
if(isset($_POST['voter_id'])){
        $election_id=$_POST['election_id'];
        $voter_id=$_POST['voter_id'];
        $qry="SELECT voters.voter_id,voters.voter_fname,voters.voter_lname,voters.voter_email,voters.voter_phone_number,department.department_name,courses.course_name,semester.semester_name,candidate.photo FROM candidate INNER JOIN voters ON candidate.voter_id=voters.voter_id INNER JOIN department ON voters.voter_department=department.department_id INNER JOIN courses ON voters.voter_course=courses.course_id INNER JOIN semester ON voters.voter_semester=semester.semester_id WHERE candidate.election_id='$election_id' AND candidate.voter_id='$voter_id'";
        $run=mysqli_query($con,$qry);
        $result=mysqli_fetch_array($run);
        $output="
         Name : {$result['voter_fname']} {$result['voter_lname']} 
         Email : {$result['voter_email']}
         Mobile No : {$result['voter_phone_number']}
         Department : {$result['department_name']}
         Course : {$result['course_name']}({$result['semester_name']})
         ";
        echo $output;
}
?>