<?php
//----------ready-------------
 include('admin/connection.php');
 $dept_id=$_POST['dept_id'];
 $qry="SELECT * FROM courses WHERE department_id='{$dept_id}'";
 $run=mysqli_query($con,$qry);
 if(mysqli_num_rows($run)<1){
   echo "<option>No courses found.</option>";
 }else{
   echo "<option selected disabled>Select Course</option>";
   while($data=mysqli_fetch_array($run)){
?>
     <option value="<?php echo $data['course_id']?>" class="text-uppercase"><?php echo $data['course_name']?></option>
<?php } }?>
