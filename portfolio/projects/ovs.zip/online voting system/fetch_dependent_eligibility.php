<?php
//-----------------ready------------
include('admin/connection.php');
$qry1="SELECT * FROM positions WHERE position_id='{$_POST['position_id']}'";
$run1=mysqli_query($con,$qry1);
$check=mysqli_num_rows($run1);
if($check<1){
  echo "<strong>No data found.</strong>";
  exit();
}
while ($eligibility=mysqli_fetch_array($run1)) {
?>
 <?php echo $eligibility['eligibility']?>
<?php } ?>
