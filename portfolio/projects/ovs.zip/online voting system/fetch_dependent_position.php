<?php
//-------------ready------------
include('admin/connection.php');
$qry1="SELECT * FROM positions WHERE election_id='{$_POST['election_id']}' AND position_status='1'";
$run1=mysqli_query($con,$qry1)or die('qry fail');
echo "<option selected disable class='text-info text-center'>Select position</option>";
if(mysqli_num_rows($run1)<1){
  echo "<option>No data found.</option>";
}

while ($positions=mysqli_fetch_array($run1)) {
?>
 <option value="<?php echo $positions['position_id']?>"><?php echo $positions['position_name']?></option>
<?php } ?>
