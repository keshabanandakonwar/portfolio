<?php
//--------------ready-------------------
 include('admin/connection.php');
 $course_id=$_POST['course_id'];
 $qry="SELECT * FROM semester WHERE course_id='$course_id'";
 $run=mysqli_query($con,$qry);
 if(mysqli_num_rows($run)<1){
   echo "<option>No semester Found</option>";
 }else {
   echo "<option selected disabled>Select Semester</option>";
   while($data=mysqli_fetch_array($run)){
?>
    <option value="<?php echo $data['semester_id']?>"><?php echo $data['semester_name']?></option>
<?php } } ?>
