<?php
include('admin/connection.php');
$qry1="SELECT * FROM ELECTION WHERE election_id='{$_GET['election_id']}'";
//$qry1="SELECT election.election_id,election.election_name,election.election_date,positions.position_name,candidate.candidate_photo FROM positions INNER JOIN election ON positions.election_id=election.election_id INNER JOIN candidate ON positions.position_id=candidate.position_id WHERE election.election_id='{$_GET['election_id']}'";
$run1=mysqli_query($con,$qry1);
$data=mysqli_fetch_array($run1);
if($data) {
 $output="<th colspan='2' class='text-center'><input class='form-control text-center text-white bold text-uppercase bg-primary' readonly value='Election details'>
                <i>Election Name : </i><b class='text-danger'>{$data['election_name']}</b><br>
                <i>Election Date : </i><b class='text-danger'>{$data['election_date']}</b><br>";
      $output.="<input class='form-control text-center text-white bold text-uppercase bg-primary' readonly value='Candidates'>";
      $qry3="SELECT * FROM positions WHERE election_id='{$_GET['election_id']}'";
      $run3=mysqli_query($con,$qry3);
      while($data3=mysqli_fetch_array($run3)){
      $output.="<h4 class='text-uppercase text-success text-center'>- - - {$data3['position_name']} - - -</h4>";
      $qry4="SELECT voters.voter_name,courses.course_name,semester.semester_name FROM voters INNER JOIN candidate ON voters.voter_id=candidate.voter_id INNER JOIN courses ON voters.voter_course=courses.course_id INNER JOIN semester ON voters.voter_semester=semester.semester_id WHERE candidate.position_id='{$data3['position_id']}'";
      $run4=mysqli_query($con,$qry4);
      $check4=mysqli_num_rows($run4);
      if($check4<1){
        $output.="<h5 class='text-danger'>No data found.</h5>";
      }
      while($data4=mysqli_fetch_array($run4)){
        $output.="<b class='text-right text-uppercase'>{$data4['voter_name']}</b><br>
                  <i class='text-primary text-uppercase'><small>{$data4['course_name']}({$data4['semester_name']})</small></i><hr class='p-0 m-0'>
                 ";
      }
    }
 $output.= "</th>";
}
echo $output;
?>
