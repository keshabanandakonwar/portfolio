<?php
//----------ready------------ 
 session_start();
 if(!isset($_SESSION['voter_id'])){
   header("location:login.php");
   exit();
 }
include('admin/connection.php');
$qry="SELECT * FROM election WHERE election_id='{$_POST['election_id']}'";
$run=mysqli_query($con,$qry);
$data=mysqli_fetch_array($run);
?>
<h4 style="text-align:center;font-family:fantasy;font-size:20px"><?php echo $data['election_name']?></h4>
<h5 class="text-center text-danger ">(<?php echo $data['election_date']?>)</h5>
<?php
//--------- show position details------------
$qry1="SELECT * FROM positions WHERE election_id='{$_POST['election_id']}'";
$run1=mysqli_query($con,$qry1);
while($data1=mysqli_fetch_array($run1)){
?>
 <h3 class="text-center p-2 bg-dark text-white" style="font-family:cursive;padding:5px;background-color:#6cdb65;color:white;margin:0px;"><?php echo $data1['position_name'] ?><br><p id="message"></p></h3>
 <?php
//---------show candidate----------
  $qry2="SELECT voters.voter_id,voters.voter_fname,voters.voter_lname,candidate.photo,voters.voter_state FROM candidate INNER JOIN voters ON candidate.voter_id=voters.voter_id WHERE candidate.position_id='{$data1["position_id"]}' AND candidate.election_id='{$data["election_id"]}' AND candidate.candidate_status='1'";
  $run2=mysqli_query($con,$qry2);
  if(mysqli_num_rows($run2)<1){
    echo "<h6 class='text-danger text-center'>No candidate Found</h6>";
  }

 ?>
 <table class="candidate_form table table-striped table-bordered table-responsive text-center">
   <tr class="bg-light">
     <th style="text-align:center">Sl</th>
     <th style="text-align:center">photo</th>
     <th style="text-align:center">Name</th>
     <th style="text-align:center">Details</th>
     <th style="text-align:center">Vote</th>
   </tr>
<?php $sl=1;
      while($data2=mysqli_fetch_array($run2)){ ?>
   <tr>
     <td style="vertical-align:middle;text-align:center"><?php echo $sl ?></td>
     <td style="width:10%;vertical-align:middle"><img src="<?php echo $data2['photo']?>"style="width:100%"></td>
     <td style="vertical-align:middle;text-align:center" class="text-uppercase"><?php echo $data2['voter_fname'].' '.$data2['voter_lname']?></td>
     <td style="vertical-align:middle;text-align:center;padding:0px">
      <a href="fetch_candidate_data.php?eid=<?php echo $data1['election_id']?>&vid=<?php echo $data2['voter_id']?>"><button id='candidate-details' class='btn btn-sm btn-secondary' data-vid="<?php echo $data2['voter_id'] ?>" data-eid="<?php echo $data['election_id'] ?>">DETAILS</a></button>
   </td> 
     <td><!--<button type="button" id="vote" class="vote btn btn-sm btn-danger w-auto" data-candidateid="<?php echo $data2['voter_id']?>" data-positionid="<?php echo $data1['position_id'] ?>">Vote</button>--->
       <input type="checkbox" id="vote" class="vote_box form-control w-auto" data-candidateid="<?php echo $data2['voter_id']?>" data-positionid="<?php echo $data1['position_id'] ?>" data-electionid="<?php echo $_POST['election_id'] ?>">
      </td>
   </tr>
   
<?php $sl++; } ?>
 </table>
 <hr class="m-0 p-0">
<?php }?>