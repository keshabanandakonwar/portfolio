<!---------------------ready------------>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
    <style media="screen">
    @media (min-width:1024px) {
       .schoolname{
         display: none;
       }
       .text{
         letter-spacing: 5px;
         font-weight:bold;
         word-spacing: 10px;
       }
    }
    @media (max-width:768px) {
      .sec_image{
        display: none;
      }
    }
    </style>
  </head>
  <body>
  <?php include('social_media_link.php');?>
  <section class=" mb-3" style="background-color:#030b34;">
    <div class="container p-2">
      <div class="row">
        <div class="col-lg-3 text-center">
          <img loading="lazy" class="img-fluid" src="images/argucom_logo.png" alt="logo" width="50%" height="auto">
        </div>
        <div class="col-lg-6 text-center text-primary" style="vertical-align:middle">
          <h3 clas="text-center">
            <b>Assam Rajiv Gandhi University of Cooperative Management</b><br>
            <small>(A Govt. of Assam University)<br>
            Recognized by <strong class="text-success">UGC and member of Association of Indian Universities</strong><br>
            Basic Tinali, Gadadhar Nagar, Joysagar, Sivasagar</small>
          </h3>
        </div>
        <div class="col-lg-3 text-center sec_image">
          <img loading="lazy" class="img-fluid" src="images/argucom_logo.png" alt="logo" width="50%" height="auto">
        </div>
      </div>
    </div>
  </section>
  </body>
</html>
