<?php
//------------ready------------
 session_start();
 include('admin/connection.php');
 $qry1="SELECT voters.voter_fname,voters.voter_lname,voters.voter_email,voters.voter_id,voters.voter_state,voters.voter_district,voters.voter_postoffice,voters.voter_pinno,voters.voter_village,voters.voter_phone_number,department.department_name,courses.course_name,semester.semester_name,voters.voter_rollno FROM voters INNER JOIN department ON voters.voter_department=department.department_id INNER JOIN courses ON voters.voter_course=courses.course_id INNER JOIN semester ON courses.course_id=semester.course_id WHERE voters.voter_id='{$_SESSION['voter_id']}'";
 $run1=mysqli_query($con,$qry1);
 $data1=mysqli_fetch_array($run1);
?>
<html>
  <head>
    <link rel="stylesheet" href="css/bootstrap.css">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link href="admin/assets/css/lib/font-awesome.min.css" rel="stylesheet">
    <title>Voter Dashboard</title>
    <style media="screen">
      .box:hover{
        color:white;
        background-color: lightgreen;
        font-weight: bold;
        cursor: pointer;
      }
      @media (max-width:375px) {
        .box{
          font-size: 18px;
        }
      }
      @media (min-width:1024px) {
        .dashboard{
           writing-mode : vertical-rl;
        }
      }
    </style>
  </head>
  <body>
    <?php   include('header.php');  ?>
  <!--end navbar--->
    <div class="container mt-3">
      <div class="row p-2">
        <!------profile------>
        <div class="col-lg-3 border p-1 bg-light">
          <div class="form-group text-center bg-light">
            <h4 class="text-uppercase p-3 mt-0" style="border-bottom:2px red solid;background-color:#dfc2c2;font-family:cursive">PROFILE</h4>
            <img src="images/photo/2.png">
          </div>
          <div class="form-group">
            <h5 id="personal-details-btn" style="border-bottom:1px solid purple;background-color:lightblue" class="text-primary p-3">PERSONAL DETAILS <span class="fa fa-angle-down fa-lg float-right mr-3 text-danger"></span> </h5>
          </div>
            <div class="form-group pl-3 pdetails bg-light" id="personal-details">
            <label >Name : </label>
            <i class="text-uppercase"><?php echo $data1['voter_fname']." ".$data1['voter_lname']?></i><br>
            <label >Voter Id: </label>
            <i><?php echo $data1['voter_id']?></i><br>
            <label >Mobile Number : </label>
            <i class="text-uppercase"><?php echo $data1['voter_phone_number']?></i><br>
            <label >Email Id : </label>
            <i><?php echo $data1['voter_email']?></i><br>
            <label >Address : </label><hr class="m-0">
            <i>
               <p class="ml-3 bg-white">
                   <strong>STATE : </strong><i><?php echo $data1['voter_state']?></i><br>
                   <strong>DISTRICT : </strong><i><?php echo $data1['voter_district']?></i><br>
                   <strong>POST OFFICE : </strong><i><?php echo $data1['voter_postoffice']?></i><br>
                   <strong>PIN NO : </strong><i><?php echo $data1['voter_pinno']?></i><br>
                   <strong>VILLAGE/TOWN : </strong><i><?php echo $data1['voter_village']?></i>
               </p>
            </i>
          </div>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <div class="form-group">
            <h5 id="edu-details-btn" style="border-bottom:1px solid purple;background-color:lightblue" class="text-primary p-3">EDUCATIONAL DETAILS <span class="fa fa-angle-down fa-lg float-right mr-3 text-danger"></span> </h5>
          </div>
          <div class="form-group bg-light pl-3 edudetails" id="edu-details">
            <label>Dept./School : </label><hr class="p-0 m-0">
            <i class="text-uppercase"><?php echo $data1['department_name']?></i><br>
            <label>Course : </label>
            <i class="text-uppercase"><?php echo $data1['course_name']?></i><br>
            <label>Semester : </label>
            <i class="text-uppercase"><?php echo $data1['semester_name']?></i><br>
            <label>Roll No : </label>
            <i><?php echo $data1['voter_rollno']?></i>
          </div>
        </div>
        <div class="col-lg-1">
          <h1 class=" dashboard" style="text-align:center;font-family:cursive">VOTER DASHBOARD</h1>
        </div>
<!-------voter application status--------->
        <div class="col-lg-8 bg-light">
          <div class="row">
            <div class="col-12" id="candidate-application-btn">
              <h3 class="box p-4 text-center border-primary" style="font-family:cursive;border:1px solid gray;word-wrap:break-word;">
                 <span class="fa fa-arrow-right float-left text-warning ml-0" id="arrow"></span>
                   <i>Candidate Application</i>
                 <span class="fa fa-arrow-left float-left text-warning float-right mr-0"></span>
              </h3>
            </div>
          </div>

<!--------candidate application status-------->
  <div class="form-group pt-5" id="candidate-application" style="display:none">
    <h3 class="text-center mt-4" style="font-family:cursive"><b>CANDIDATE APPLICATION STATUS</b></h3>
  <hr>
    <?php
    $qry3="SELECT voters.voter_fname,voters.voter_lname,candidate.candidate_status,candidate.photo,election.election_id,election.election_name,election.election_date,positions.position_name,positions.eligibility FROM candidate INNER JOIN voters ON voters.voter_id=candidate.voter_id INNER JOIN election ON election.election_id=candidate.election_id INNER JOIN positions ON candidate.position_id=positions.position_id WHERE candidate.voter_id='{$_SESSION['voter_id']}' ORDER BY candidate.id DESC";
      $run3=mysqli_query($con,$qry3);
      $check=mysqli_num_rows($run3);
      if($check<1){
    ?>
    <h4 class="text-danger text-center"> No Application Found</h4>
  <?php }
 while($data3=mysqli_fetch_array($run3)){
   ?>
   <div class="row bg-light">
     <div class="col-lg-4">
       <img src="<?php echo $data3['photo']?>" width="100%" height="auto">
       <h4 class="text-center p-2 bg-primary"><?php echo $data3['voter_fname']." ".$data3['voter_lname']?></h4> </th>
     </div>
     <div class="col-lg-8 p-0">
       <table class="table bg-light table-bordered">
         <tbody>
           <tr>
             <th style="vertical-align:middle;text-align:center;color:purple">Election Details</th>
             <td><strong>Election Id : </strong><i class="text-danger"><?php echo $data3['election_id']?></i><br>
                 <strong>Election Name : </strong><i class="text-danger"><?php echo $data3['election_name']?></i><br>
                 <strong>Election Date : </strong><i class="text-danger"><?php echo $data3['election_date']?></i>
            </td>
           </tr>
           <tr>
             <th style="vertical-align:middle;text-align:center;color:purple">Position Details</th>
             <td><strong>Position Name : </strong><i class="text-danger"><?php echo $data3['position_name']?></i><br>
                 <strong>Position Eligibility : </strong><br><small class="text-danger"><?php echo $data3['eligibility']?></small><br>
             </td>
           </tr>
           <tr>
             <th style="vertical-align:middle;text-align:center;color:purple">Application Status</th>
             <td>
               <?php
                 if($data3['candidate_status']=='0'){
               ?>
               <i class="text-primary"><span class="fa fa-spinner "></span> Your application is in process.We will update your application very soon.</i>
             <?php }else{ ?>
               <i class="text-success"><span class="fa fa-check"></span>Your application verified successfully. </i>
             <?php } ?>
             </td>
           </tr>
         </tbody>
       </table>
     </div>
   </div><hr class="bg-primary text-danger text-bold">
 <?php } ?>
  </div>
        </div>
      </div>
    </div>

    <?php include('footer.php'); ?>
<script type="text/javascript" src="css/jquery-3.2.1.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $('#personal-details-btn').on('click',function(){
      $('#personal-details').toggle(1000);
    });
    $('#edu-details-btn').on('click',function(){
      $('#edu-details').toggle(1000);
    });
    $('#candidate-application-btn').on('click',function(){
      $('#candidate-application').toggle(1000);
    });
});
</script>
</body>
</html>
