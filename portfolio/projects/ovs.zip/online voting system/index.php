
<html>
<head>
  <title>ARGUCOM</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- Slick Carousel -->
  <link rel="stylesheet" href="css/slick.css">
  <link rel="stylesheet" href="css/slick-theme.css">
  <!-- FancyBox -->
  <link rel="stylesheet" href="css/jquery.fancybox.min.css">
  <!-- fontawesome -->
  <link rel="stylesheet" href="css/all.min.css">
  <!-- animate.css -->
  <link rel="stylesheet" href="css/animate.min.css">
  <!-- jquery-ui -->
  <link rel="stylesheet" href="css/jquery-ui.css">
  <!-- timePicker -->
  <link rel="stylesheet" href="css/timePicker.css">
  <!-- Stylesheets -->
  <link href="css/style.css" rel="stylesheet">

  <!--Favicon-->
  <link rel="icon" href="images/favicon.png" type="image/x-icon">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
  <!---mobile view style--->
  <style media="screen">
  @media (min-width:1024px) {
     .schoolname{
       display: none;
     }
  }
  @media (max-width:768px) {
    .text{
      font-size: 5px;
    }
    div .candidate{
      width:50%;
    }
  }
  </style>

</head>
<body>
<div class="page-wrapper">
<?php include('social_media_link.php')?>

<!--Header Upper(mobile)-->
<section class="schoolname">
  <div class="container">
    <div class="row">
      <div class="col-12 text-center">
            <img loading="lazy" class="img-fluid" src="images/argucom_logo.png" alt="logo" width="40%" height="auto">
              <h5 style="font-family: 'Sofia', sans-serif;font-size: 30px;text-shadow: 3px 3px 3px #ababab;">Assam Rajiv Gandhi University of Cooperative Management</h5>
              <small>(A Govt. of Assam University)<br>
                  Recognized by <i class="text-success">UGC and member of Association of Indian Universities</i><br>
                  Basic Tinali, Gadadhar Nagar, Joysagar, Sivasagar
              </small>
      </div>
    </div>
  </div>
</section>
<!--Header Upper(mobile)-->

<!--Main nav bar-->
<?php include('navbar.php')?>

<!--======= Page Slider============-->
<div class="hero-slider">
  <!-- Slider Item -->
  <div class="slider-item slide1" style="background-image:url(images/images.jpg);background-size: cover;">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <!-- Slide Content Start --> 
          <div class="content style text-center">
            <h2 class="text-white text-bold mb-2" data-animation-in="slideInLeft" style="font-family:serif;"><b>Assam Rajiv Gandhi University of Cooperative Management</b></h2>
            <p class="tag-text mb-4" data-animation-in="slideInRight">
              <small>(A Govt. of Assam University)</small>
            </p>
            <a href="login.php" class="btn btn-main btn-white" data-animation-in="slideInLeft" data-duration-in="1.2">LOGIN</a>
          </div>
          <!-- Slide Content End -->
        </div>
      </div>
    </div>
  </div>
  <!-- Slider Item -->
  <div class="slider-item" style="background-image:url(admin/system_images/vote1.jpg);background-size: cover;">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <!-- Slide Content Start -->
          <div class="content text-center style">
            <h2 class="text-white text-bold mb-2" data-animation-in="slideInRight" style="font-family:serif;"><b>Assam Rajiv Gandhi University of Cooperative Management</b></h2>
            <p class="tag-text mb-4" data-animation-in="slideInLeft">New Election is going on</p>
            <a href="candidate_apply.php" class="btn btn-main btn-white" data-animation-in="slideInRight"  data-duration-in="1.2">Apply Now</a>
          </div>
          <!-- Slide Content End -->
        </div>
      </div>
    </div>
  </div>
</div>
<!--====  End of Page Slider  ====-->
<!---=== Start about section ===--->
<div class="container pt-5">
  <div class="row inline">
    <div class="col-lg-8 col-xm-12 inline">
      <img src="admin/system_images/logo.png" width="90%" height="auto">
    </div>
    <div class="col-lg-4 col-xm-12 text-center inline">
    <h3 class="pb-4 text-center text-danger" style="font-family: 'Sofia', sans-serif;font-size: 30px;text-shadow: 3px 3px 3px #ababab;">Assam Rajiv Gandhi University of Cooperative Management</h3>
      <p style="font-size:17px">
        <h3 class="text-left">About</h3><hr class="m-0">
        mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        quis nostrud exercitation ullamco laboris nisi ut aliqusse cillum dolore
         eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
         unt in culpa qui officia deserunt mollit anim id est la
         <h3 class="text-left">Mission</h3><hr class="m-0">
         mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
         eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
         ute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu f
         ugiat nulla pariatur. Excepteur sint occaecat cupidatat.
         <h3 class="text-left">Vision</h3><hr class="m-0">
         mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
         eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
         ute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu f
         ugiat nulla pariatur. Excepteur sint occaecat cupidatat.
         </p>
         <a href="index.php" class="btn btn-sm btn-primary text-white mt-3 float-right">Read more <span class="fa fa-arrow-right"></span> </a>
    </div>
  </div>
</div><hr>
<!---=== End about section ===--->

<!---=== Start achevement section ===--->
<section class="service-section bg-gray mt-4 mb-4">
  <div class="container">
    <div class="row" style="vertical-align:middle">
      <div class="col-12 text-center text-dark">
        <h2 class="p-3">Candidates</h2><hr class="bg-primary m-0">
        <?php 
          $qry1="SELECT * FROM election WHERE election_status='1' ORDER BY sl_no DESC";
          $run1=mysqli_query($con,$qry1);
          $data=mysqli_fetch_array($run1);
        ?>
        <h3 class="text-white bg-success p-3"><strong class="text-uppercase text-white"><?php echo $data['election_name']?></strong></h3>
      </div>
    </div>
    <div class="row">
     <?php 
      // $qry2="SELECT voters.voter_fname,voters.voter_lname FROM candidate INNER JOIN voters ON candidate.voter_id=voters.voter_id WHERE candidate.elecion_id='{$data["election_id"]}'";
      $qry2="SELECT voters.voter_fname,voters.voter_lname,candidate.photo,department.department_name,courses.course_name FROM  candidate INNER JOIN voters ON candidate.voter_id=voters.voter_id INNER JOIN department ON voters.voter_department=department.department_id INNER JOIN courses ON voters.voter_course=courses.course_id WHERE election_id='{$data["election_id"]}'";
      $run2=mysqli_query($con,$qry2);
       while($data2=mysqli_fetch_array($run2)){
     ?>
      <div class="col-lg-3 bg-light candidate">
        <div class="item">
          <div class="inner-box text-center text-dark text-uppercase">
            <div class="img_holder">
              <a href="<?php echo $data2['photo']?>">
                <img src="<?php echo $data2['photo']?>" class="img-fluid">
              </a>
            </div>
              <h5><b><?php echo $data2['voter_fname'].' '.$data2['voter_lname'] ?></b></h5>
              <h6 class="text-primary"><?php echo $data2['department_name']?></h6>
              <h6 class="text-primary">(<?php echo $data2['course_name']?>)</h6>
          </div>
        </div>
      </div>
      <?php } ?>
      
      <div class="col-lg-3 bg-light border">
        <H3 class="text-center text-primary p-2" style="box-shadow:1px 1px 9px 2px red">IMPORTANT LINKS</H3>
        <a href=""><button class="btn btn-block p-0 btn-secondary"><span class="fa fa-link text-danger"></span>  University Website</button></a><br>
        <a href=""><button class="btn btn-block p-0 btn-secondary"><span class="fa fa-link text-danger"></span>  Candidate Application</button></a><br>
        <a href=""><button class="btn btn-block p-0 btn-secondary"><span class="fa fa-link text-danger"></span>  Ballot Paper</button></a>
      </div>
    </div>
  </div>
</section>
<!---=== End achevemen                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  t section ===--->
<!-- scroll-to-top -->
<div id="back-to-top" class="back-to-top">
  <i class="fa fa-angle-up pt-3"></i>
</div>

</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".header-top">
  <span class="icon fa fa-angle-up"></span>
</div>
<?php include('footer.php')?>

<!-- jquery -->
<script src="css/jquery.min.js"></script>
<!-- bootstrap -->
<script src="css/bootstrap.min.js"></script>
<!-- Slick Slider -->
<script src="css/slick.min.js"></script>
<script src="css/slick-animation.min.js"></script>
<!-- script js -->
<script src="css/script.js"></script>
</body>

</html>
