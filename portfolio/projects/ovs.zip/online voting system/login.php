<!----------last update on 12.10.2023----------->
<html>
  <head>
    <title>login page</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <style media="screen">
     #signup-form{
       display: none;
     }
     #form-row{
       width: 100%;
       height: 80%;
       overflow-y: scroll;
     }
      #design{
        background-image: url(admin/system_images/logo.png);
        background-size: cover;
        background-repeat: no-repeat;
      }
    </style>
  </head>
  <body>
   <?php include("header.php")?>
    <div class="container">
      <div class="row mt-5 mb-5">
        <div class="col-lg-6">
          <img src="admin/system_images/vote.jpg" width="100%" height="auto">
        </div>
        <!---login form-->
        <div class="col-lg-6" id="signin-form">
           <div class="row p-2 border mt-4">
             <div class="col-12">
               <h2 class="bg-success text-white text-center p-3">Login</h2>
             </div>
             <div class="col-12">
               <label for="voter-id">Voter Id</label>
               <input type="text" class="form-control" placeholder="Enter your id" id="voter-id" required>
             </div>
             <div class="col-12 text-center">
               <button type="button" id="searchVoter" class="btn btn-danger m-2">Search</button>
             </div>
             <div class="col-12">
               <p>Don't have account <a id="signup-btn-link" class="text-danger">Click here</a> </p>
             </div>
             <div class="col-lg-12">
               <p>Forget Password <a id="forget-password-link" class="text-danger">Click here</a> </p>
             </div>
           </div>
           <div class="row border" id="design" >

            </div>
        </div>
        <!---signup form---->
        <div class="col-lg-6" id="signup-form">
          <div class="row p-2 ml-1 border bg-light mt-4" id="form-row">
            <div class="col-12 p-0">
              <h2 class="bg-success text-white text-center p-3">Signup Form</h2>
            </div>
            <div class="col-md-6">
              <label for="voter-fname"> First Name</label>
              <input type="text" class="form-control text-uppercase" placeholder="Enter your first name" id="voter-fname" required>
            </div>
            <div class="col-md-6">
              <label for="voter-lname"> Last Name</label>
              <input type="text" class="form-control text-uppercase" placeholder="Enter your last name" id="voter-lname" required>
            </div>
            <div class="col-md-6">
              <label for="voter-email"> Email</label>
              <input type="email" class="form-control" placeholder="Enter your email id" id="voter-email" required>
            </div>
            <div class="col-md-6">
              <label for="voter-number"> Mobile Number</label>
              <input type="text" class="form-control" placeholder="Enter your mobile number" maxlength="10" id="voter-number" required>
            </div>
            <div class="col-12">
              <label for="voter-dept">School / Department</label>
              <select class="form-control text-uppercase" id="voter-dept">
                <option disabled selected>School / Department</option>
                <?php
                    include('admin/connection.php');
                    $qry1="SELECT * FROM department WHERE department_status='1'";
                    $run1=mysqli_query($con,$qry1);
                    while($data1=mysqli_fetch_array($run1)){
                ?>
                <option value="<?php echo $data1['department_id']?>"><?php echo $data1['department_name']?></option>
              <?php } ?>
              </select>
            </div>
            <div class="col-md-6" style="display:none" id="course-box">
              <label for="voter-course">Select Course</label>
              <select class="form-control text-uppercase" id="voter-course"></select>
            </div>
            <div class="col-md-6"  style="display:none" id="semester-box">
              <label for="voter-semester">Select Semester/Class</label>
              <select class="form-control text-uppercase" id="voter-semester"></select>
            </div>
            <div class="col-md-6"  style="display:none" id="rollno-box">
              <label for="voter-rollno">Roll Number</label>
              <input type="number" min="1" class="form-control" required id="voter-rollno">
            </div>
            <div class="col-md-6">
              <label for="voter-state"> State</label>
              <input type="text" class="form-control text-uppercase" placeholder="Enter your state name" id="voter-state" required>
            </div>
            <div class="col-md-6">
              <label for="voter-district"> District</label>
              <input type="text" class="form-control text-uppercase" placeholder="Enter your district name" id="voter-district" required>
            </div>
            <div class="col-md-6">
              <label for="voter-postoffice">Post Office</label>
              <input type="text" class="form-control text-uppercase" placeholder="Enter your post office name" id="voter-postoffice" required>
            </div>
            <div class="col-md-6">
              <label for="voter-pinno"> Pin No</label>
              <input type="number" maxlength='6' class="form-control" placeholder="Enter your Pin Number" id="voter-pinno" required>
            </div>
            <div class="col-md-6">
              <label for="voter-village"> Village / Town</label>
              <input type="text" class="form-control text-uppercase" placeholder="Enter your town/village name" id="voter-village" required>
            </div>
            <div class="col-12">
              <label for="voter-number"> Password</label>
              <input type="password" class="form-control" placeholder="Create a password" id="voter-password" required>
            </div>
            <div class="col-12">
              <p>Already have account <a id="signin-btn-link" class="text-danger">Click here</a> </p>
            </div>
            <div class="col-12 text-center">
              <i id="signup-message" class="bg-light text-warning"></i>
              <input type="submit" id="submit-signup-form" class="btn btn-primary btn-block btn-sm" value="SUBMIT">
            </div>
          </div>
        </div>
        <!----forget password form----->
      <div class="col-lg-6 p-5 mt-5">
        <form class="form border p-2 bg-light" id="forget-password-form" style="display:none;box-shadow:0px 0px 9px 1px purple">
          <div class="form-group bg-danger">
               <h2 class="p-2 text-white text-center">FORGET PASSWORD FORM</h2><hr class="m-0 bg-white">
          </div>
          <div class="form-group">
                <label for="user-email">Enter your email id</label>
                <input type="email" class="form-control" placeholder="Email id " id="user-email-input" required>
           </div>
           <div class="form-group">
                <input type="submit" name="forget_password" value="Send Password" onclick="alert('Please check your email message')" class="btn btn-warning btn-block btn-sm">
           </div>
        </form>
      </div>
        <div class="text-center"><strong class=" text-danger" id="forget-message"></strong>  </div>
      </div>
    </div>
    <?php include('footer.php')?>
    <script type="text/javascript" src="css/jquery-3.2.1.min.js"></script>
    <script type="text/javascript">
      $(document).ready(function(){
        //---------fetch voter details-----------ready
        $('#searchVoter').on('click',function(){
          var voter_id = $('#voter-id').val();
          $.ajax({ 
            type : "post",
            url : "fetchUserData.php",
            data : {voter_id : voter_id},
            success : function(data){
              $('#design').html(data);
            }
          });
        });
//-------load courses when user select a department  or change department------ready-
        $('#voter-dept').on("change",function(){
          var dept_id=$('#voter-dept').val();
          $('#course-box').show();
          $.ajax({
            url : "fetch_dependent_course.php",
            type : "post",
            data : {dept_id : dept_id},
            success : function(data){
              $('#voter-course').html(data);
            }
          });
        });
//--------load semester details when user select a course  or change course------ready-
      $('#voter-course').on("change",function(){
        var course_id=$('#voter-course').val();
        $('#semester-box').show();
        $.ajax({
          url : "fetch_dependent_semester.php",
          type : "post",
          data : {course_id : course_id},
          success : function(data){
            $('#voter-semester').html(data);
          }
        });
      });
//show rollno box after select semester--------ready
      $('#voter-semester').on('change',function(){
        $('#rollno-box').show();
      });
      //----- show/hide forms---------
      $('#signup-btn-link').on("click",function(){
        $('#signin-form').hide(1000);
        $('#signup-form').show(2000);
      });
      $('#signin-btn-link').on("click",function(){
        $('#signup-form').hide(1000);
        $('#signin-form').show(2000);
      });
      $('#forget-password-link').on('click',function(){
        $('#signin-form').hide(1000);
        $('#forget-password-form').show(1000);
     });
      //--------- create voter account-------------
      $('#submit-signup-form').on("click",function(){
        var fname=$('#voter-fname').val();
        var lname=$('#voter-lname').val();
        var email=$('#voter-email').val();
        var number=$('#voter-number').val();
        var dept=$('#voter-dept').val();
        var course=$('#voter-course').val();
        var semester=$('#voter-semester').val();
        var rollno=$('#voter-rollno').val();
        var state=$('#voter-state').val();
        var district=$('#voter-district').val();
        var postoffice=$('#voter-postoffice').val();
        var pinno=$('#voter-pinno').val();
        var village=$('#voter-village').val();
        var password=$('#voter-password').val();
        if(fname=='' || lname=='' || email=='' || number=='' || password=='' || state=='' || course=='' || semester=='' || rollno==''){
          $('#signup-message').html('Please enter valid data.');
          exit();
        }
        $.ajax({
          url : "create_voter_account_script.php",
          type : "post",
          data : {fname:fname, lname:lname, email:email, number:number, dept:dept, course:course, semester:semester, rollno:rollno, state:state, district:district, postoffice:postoffice, pinno:pinno, village:village, password:password},
          success : function(data){
            if(data=='error'){
              alert("This email/voter id already exist in our database,please enter another email id.");
            }else {
              alert('Congratulation '+fname+', Your account has been created successfully.');
              alert('Your login details are: Voter id : '+data+' Voter Password : '+password+'     Kindly note it down for feature reference.This will serve as your login id.');
              window.open('index.php','_self');
              exit();
            }
          }
        });
      });
      //--------login voter-------------
      $(document).on("click","#voter-login",function(){
         var voter_id = $('#voter-id').val();
         var voter_password = $('#voter-password').val();
         if(voter_password[0]==' ' || voter_password==''){
           alert('Please enter valid password.');
           exit();
         }
         $.ajax({
           url : "login_script.php",
           type : "post",
           data : {
             voter_id : voter_id,
             voter_password :voter_password
           },
           success : function(data){
             if(data=='1'){
               alert('You are login successfully.');
               window.open('index.php');
               exit();
             }else{
               alert('Please enter valid password.');
               exit();
             }

           }
         });
       });
      });
    </script>
  </body>
</html>
