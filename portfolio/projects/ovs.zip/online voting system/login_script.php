<?php
include('admin/connection.php');
$enc_pass=md5($_POST['voter_password']);
$qry1="SELECT * FROM voters WHERE voter_id='{$_POST['voter_id']}' AND voter_password='{$enc_pass}'";
$run1=mysqli_query($con,$qry1);
$check=mysqli_num_rows($run1);
if($check>0){
  session_start();
  $_SESSION['voter_id']=$_POST['voter_id'];
  $_SESSION['voter_password']=$_POST['voter_password'];
  echo "1";
}else{
  echo "0";
}
?>
