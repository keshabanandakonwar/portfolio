<?php
include('admin/connection.php');
session_start();
 if(isset($_SESSION['voter_id'])){
   $qry="SELECT * FROM voters WHERE voter_id='{$_SESSION['voter_id']}'";
   $run=mysqli_query($con,$qry);
   $data=mysqli_fetch_array($run);
 }
?>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link href="admin/assets/css/lib/font-awesome.min.css" rel="stylesheet">
    <style>
      @media (max-width:1023px) {
         .name{
           display: none;
         }
      }
      @media (min-width:1024px) {
        #navbarLinks{
         /* margin-left:130px;*/
        }
        #navbar a{
          margin-top: 20px;
        }
        #navbar{
           float:right;
           margin-right:50px;
        }  
      }
    </style>
  </head>
  <body>
    <!--Main Header-->
    <nav class="navbar navbar-expand-lg navbar-dark">
      <ul class="name">
        <li class=" text-center" style="font-family:serif;"><h3>Assam Rajiv Gandhi University of Cooperative Management</h3></li>
      </ul>
      <div class="container">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarLinks" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarLinks">

          <ul class="navbar-nav" id="navbar">
            <li class="nav-item @@home">
              <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#!" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Apply</a>

              <ul class="dropdown-menu text-center" aria-labelledby="navbarDropdown">
                <li><a class="dropdown-item @@blogDetails" href="candidate_apply.php">Candidate Apply</a></li>
                <li><a class="dropdown-item @@blogDetails" href="ballot.php">Ballot Papper</a></li>
              </ul>
            </li>
            <li class="nav-item @@contact">
              <a class="nav-link" href="contact.php">Contact</a>
            </li>
            <?php
              if(isset($_SESSION['voter_id'])){
            ?>
            <li class="nav-link @@dashboard">
              <a class="nav-link" href="home.php">DASHBOARD</a>
            </li>
          <?php }?>

            <li class="nav-link text-center @@login">
                 <?php
                       if(!isset($_SESSION['voter_id'])){
                 ?>
                 <a href="login.php" class="btn btn-sm p-1 bg-white text-danger">LOGIN</a>
               <?php }else{?>
                 <a href="home.php" title="Dashboard"><span class="fa fa-solid fa-user-secret fa-lg" style="color:purple"></span><br>
                 <i class="text-danger text-uppercase"><?php echo "{$data['voter_fname']}"?></i><br></a>
                 <a href="logout.php" class="btn btn-sm m-0 p-0" style="color:purple;background-color:white">LOGOUT</a>
               <?php }?>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!--End Main Header -->
    <script src="css/jquery.min.js"></script>
    <!-- bootstrap -->
    <script src="css/bootstrap.min.js"></script>
    <!-- Slick Slider -->
    <script src="css/slick.min.js"></script>
    <script src="css/slick-animation.min.js"></script>
    <!-- script js -->
    <script src="css/script.js"></script>
  </body>
</html>
