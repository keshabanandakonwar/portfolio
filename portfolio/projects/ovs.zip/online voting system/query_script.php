<!---------send voter query----ready-->
<?php
 include('admin/connection.php');
 $name = mysqli_real_escape_string($con,$_POST['name']);
 $email = mysqli_real_escape_string($con,$_POST['email']);
 $message = mysqli_real_escape_string($con,$_POST['message']);
 $qry="INSERT INTO query(name,email,message)VALUES('$name','$email','$message')";
 $run=mysqli_query($con,$qry);
?>
