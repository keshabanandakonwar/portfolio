<?php 
 include('admin/connection.php');
 session_start();
 $voter=$_SESSION['voter_id'];
 $election=$_POST['electionId'];
 $position=$_POST['positionId'];
 $vote=$_POST['candidateId'];
 $qry1="SELECT * FROM vote WHERE voter_id='$voter' AND election_id='{$_POST["electionId"]}' AND position_id='{$_POST["positionId"]}'";
 $run1=mysqli_query($con,$qry1);
 $check=mysqli_num_rows($run1);
 if($check>0){
   echo "0";
   exit();
 }else{
  //$qry2="INSERT INTO vote(voter_id,election_id,position_id,vote)VALUES('$voter','$election','$position','$vote')";
  $qry2="INSERT INTO `vote`(`voter_id`, `election_id`, `position_id`, `vote`) VALUES ('$voter','$election','$position','$vote')";
  $run2=mysqli_query($con,$qry2);
  $qry3="SELECT * FROM candidate WHERE voter_id='$vote' AND election_id='$election'";
  $run3=mysqli_query($con,$qry3);
  $data3=mysqli_fetch_array($run3);
  $count=$data3['vote'];
  $count=$count+1;
  $id=$data3['id'];

  $qry4="UPDATE candidate SET vote='$count' WHERE id='$id'";
  $run4=mysqli_query($con,$qry4);
  $data4=mysqli_fetch_array($run4);
  echo "1";
  exit();
 }
?>