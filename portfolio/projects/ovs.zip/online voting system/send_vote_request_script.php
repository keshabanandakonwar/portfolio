<?php
//---------send voter request
//no need
include('admin/connection.php');
$voter_id=$_POST['voter_id'];
$election_id=$_POST['election_id'];
$query="SELECT * FROM vote WHERE voter_id='$voter_id' AND election_id='$election_id'";
$run_query=mysqli_query($con,$query);
$check=mysqli_num_rows($run_query);
if($check<1) {
  $qry="INSERT INTO vote(voter_id,election_id)VALUES('$voter_id','$election_id') ";
  $run=mysqli_query($con,$qry);
  if($run){
    echo "Your request send successfully.";
  }
}else{
  echo "You have already send request to vote for this election.";
}

?>
