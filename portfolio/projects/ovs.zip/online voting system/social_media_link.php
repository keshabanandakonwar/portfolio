<!----------------ready---------------->
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
      @media (max-width:1023px) {
        .admin{
          display: none;
        }
      }
      .admin:hover{
        font-family: cursive;
        color: purple;
        text-decoration: none;
        text-shadow: 0px 0px 3px 3px red;
        font-size: 15px;
      }
    </style>
  </head>
  <body>
    <!--header top-->
    <div class="header-top bg-light">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-md-7">
            <div class="top-left text-center text-md-left">
              <small>Opening Hours: (Sunday- <b class="text-danger">9.30 AM</b> to <b class="text-danger">3.00 PM)</b> </small>
            </div>
          </div>
          <div class="col-md-4 top-right text-center text-lg-right">
            <a href="https://www.facebook.com/devabrata.konwar"><span class="fa fa-facebook-square text-primary pl-3 pr-3"></span></a>
            <a href="https://www.facebook.com/devabrata.konwar"><span class="fa fa-instagram text-danger pl-3 pr-3"></span></a>
            <a href="https://keshabthedeveloper.000webhostapp.com"><i class="fa fa-twitter text-primary pl-3 pr-3"></i></a>
            <a href="https://www.youtube.com"><i class="fa fa-youtube text-danger pl-3 pr-3"></i></a>
          </div>
          <div class="col-md-1 bg-success text-center" style="border-left:4px double purple;border-right:4px double purple">
            <small><a href="admin/index.php" class="admin text-white">ADMIN</a></small>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
