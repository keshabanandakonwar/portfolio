<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <img src="../images/photo/2.png" width="20%" height=auto>
  </body>
</html>
