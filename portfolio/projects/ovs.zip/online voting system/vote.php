<table class="table table-striped table-hover">
  <tr>
    <th colspan="2">Your Vote Goes To</th>
  </tr>
<?php
  include('admin/connection.php');
  $qry="SELECT * FROM positions WHERE position_id='{$_POST["position_id"]}'";
  $run=mysqli_query($con,$qry);
  while($data=mysqli_fetch_array($run)){
?>
  <tr>
    <th><?php echo $data['position_name']?></th>
    <?php
      $qry2="SELECT * FROM voters WHERE voter_id='{$_POST["candidate_id"]}'";
      $run2=mysqli_query($con,$qry2);
      while($data2=mysqli_fetch_array($run2)){
    ?>
    <td><?php echo $data2['voter_fname'] ?></td>
  <?php } ?>
  </tr>
<?php } ?>
</table>
