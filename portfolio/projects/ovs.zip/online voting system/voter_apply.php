<?php
include("admin/connection.php");
session_start();
 if(!isset($_SESSION['voter_id'])){
   header("location:login.php");
   exit();
 }
?>
<html lang="en" dir="ltr">
  <head>
    <title>voter apply page</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <meta name="viewport" content="width=device-width,initial-scale=1">
   <style media="screen">
     @media (min-width:1024px) {
      #voter-apply{
        padding-left:25px;
      }
     }
   </style>
  </head>
  <body style="background-color:#c3c9ed">
<?php include('header.php');?>
<!----banner---->
<section style="background-image:url('images/download.jpg')">
  <div class="container">
    <div class="row">
      <div class="col-12 text-center text-white p-5 mt-5 mb-5">
        <h2>VOTER APPLICATION FORM</h2>
        <h4 class="mt-5"><a href="index.php"> HOME </a>/<i class="text-danger"> Voter application form </i></h4>
      </div>
    </div>
  </div>
</section>
  <div class="container ">
    <div class="row">
      <div class="col-lg-4">
        <?php include('voter_data.php');?>
      </div>

      <div class="col-lg-7 mt-2" id="voter-apply">
        <table class="table bg-light" style="overflow-x:scroll">
          <tr style="background-color:purple">
            <th colspan="3" class="text-center text-white"><h3>VOTER APPLY</h3><hr class="m-0 bg-info"><span id="message" class="text-warning"></span> </th>
          </tr>
          <tr>
            <th>Select Election</th>
            <td>
              <select class="form-control" id="election-id">
                <option disabled selected>Select Election where you want to vote</option>
                <?php
                    $qry2="SELECT * FROM election WHERE election_status='1'";
                    $run2=mysqli_query($con,$qry2);
                    while($data2=mysqli_fetch_array($run2)){
                ?>
                <option value="<?php echo $data2['election_id']?>"><?php echo $data2['election_name'] ?></option>
              <?php } ?>
              </select>
            </td>
          </tr>
          <tr id="election-details"></tr>
          <tr>
            <th colspan="3" class="text-center"><input type="submit" id="voter-request-form" value="Send Request" class="btn btn-success form-control"> </th>
          </tr>
        </table>
      </div>
    </div>
  </div>
  <?php include('footer.php') ?>
  <script type="text/javascript" src="css/jquery-3.2.1.min.js"></script>
  <script type="text/javascript">
  $(document).ready(function(){
    //code to display election details
    $('#election-id').on('change',function(){
      var election_id=$('#election-id').val();
      $.ajax({
        url : "fetch_election_details.php",
        type : "get",
        data : {election_id : election_id},
        success : function(data){
          $('#election-details').html(data);
        }
      });
    });
      //script to send voter request
      $('#voter-request-form').on('click',function(){
        var voter_id = $('#voter-id').val();
        var election_id = $('#election-id').val();
        if (election_id==null) {
          $('#message').html('Please select election.');
          exit();
        }
        if (confirm('Are you sure to send voter request ? ')) {
          $.ajax({
            url : "send_vote_request_script.php",
            type : "post",
            data : {voter_id : voter_id, election_id : election_id},
            success : function(data){
              alert(data);
              window.open('voter_apply.php','_self');
            }
          });
        }
      });
});
  </script>
  </body>
</html>
