<!----------NO NEED --------.>
<?php
include('admin/connection.php');
//session_start();
if(isset($_SESSION['voter_id'])){
  $qry1="SELECT voters.voter_id,voters.voter_fname,voters.voter_lname,voters.voter_address,depertment.depertment_name,courses.course_name,semester.semester_name,voters.voter_email,voters.voter_phone_number FROM voters INNER JOIN depertment ON voters.voter_depertment=depertment.depertment_id INNER JOIN courses ON voters.voter_course=courses.course_id INNER JOIN semester ON voters.voter_semester=semester.semester_id WHERE voters.voter_id='{$_SESSION['voter_id']}'";
  $run1=mysqli_query($con,$qry1);
  $data=mysqli_fetch_array($run1);
}
?>
<html>
  <head>
    <link rel="stylesheet" href="css/bootstrap.css">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <style media="screen">
      @media (max-width:768px) {
        .user_details{
          display: none;
        }
      }
    </style>
  </head>
  <body style="background-color:#ab88eb">
  <div class="container ">
    <div class="row">
      <div class="col-12 mt-2 user_details" >
        <table class="table table-striped table-hover table-responsive ">
          <thead class="bg-success">
            <tr>
              <th colspan="3" class="text-center"><img src="images/photo/4.png" alt=""><br>
              <h5 class="text-uppercase"><b><?php echo $data['voter_fname']." ".$data['voter_lname']?></b></h5></th>
            </tr>
          </thead>
          <tbody style="background-color:skyblue">
            <tr>
              <th>Voter Id</th>
              <th>:</th>
              <td><input type="text" id="voter-id" class="form-control" value="<?php echo $data['voter_id']?>" readonly> </td>
            </tr>
            <tr>
              <th>Voter Department</th>
              <th>:</th>
              <td><!--<input type="text" class="form-control" value="<?php echo $data['depertment_name']?>" readonly >--->
                 <marquee><h4><?php echo $data['depertment_name']?></h4></marquee>
               </td>
            </tr>
            <tr>
              <th>Voter Course</th>
              <th>:</th>
              <td><input type="text" class="form-control" value="<?php echo $data['course_name']?>" readonly> </td>
            </tr>
            <tr>
              <th>Voter Semester</th>
              <th>:</th>
              <td><input type="text" class="form-control" value="<?php echo $data['semester_name']?>" readonly> </td>
            </tr>
            <tr>
              <th>Voter Phone</th>
              <th>:</th>
              <td><input type="text" class="form-control" value="<?php echo $data['voter_phone_number']?>" readonly> </td>
            </tr>
            <tr>
              <th>Voter Email</th>
              <th>:</th>
              <td><input type="text" class="form-control" value="<?php echo $data['voter_email']?>" readonly> </td>
            </tr>
            <tr>
              <th>Voter Address</th>
              <th>:</th>
              <td><input type="text" class="form-control" value="<?php echo $data['voter_address']?>" readonly> </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  </body>
</html>
