-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 17, 2013 at 08:32 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `votingsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `sl_no` int(11) NOT NULL,
  `admin_type` varchar(255) NOT NULL,
  `department_id` int(255) DEFAULT 0,
  `course_id` int(11) DEFAULT 0,
  `admin_name` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_password` varchar(255) NOT NULL,
  `admin_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`sl_no`, `admin_type`, `department_id`, `course_id`, `admin_name`, `admin_email`, `admin_password`, `admin_status`) VALUES
(1, 'admin', 0, 0, 'admin', 'keshab@gmail.com', 'a3d27d175b3789dc104100b0985b6a2b', 1),
(6, 'controller', 2, 16, 'diganta gogoi', 'gogoi@gmail.com', '0c85a6bc5f5b01dbeee00de465fa6b0a', 1),
(12, 'controller', 3, 18, 'saswat gogoi', 'saswat@gmail.com', '6c40e8e14d24f4cb219efb1e2b239404', 1);

-- --------------------------------------------------------

--
-- Table structure for table `candidate`
--

CREATE TABLE `candidate` (
  `id` int(11) NOT NULL,
  `voter_id` varchar(255) NOT NULL,
  `election_id` varchar(255) NOT NULL,
  `position_id` int(11) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `vote` int(11) DEFAULT 0,
  `candidate_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `candidate`
--

INSERT INTO `candidate` (`id`, `voter_id`, `election_id`, `position_id`, `photo`, `vote`, `candidate_status`) VALUES
(11, 'Voter/2023/1/38148', 'election/2023/07/26/2', 13, 'upload/whatsapp.png', 54, 1),
(13, 'Voter/2023/PGDCA/3', 'election/2023/07/26/2', 15, 'upload/facebook.jpg', 34, 1),
(14, 'Voter/2023/PGDCA/4', 'election/2023/08/13/1', 14, 'upload/whatsapp.png', 45, 1),
(15, 'Voter/2023/PGDCA/4', 'election/2023/07/26/2', 15, 'upload/facebook.jpg', 61, 1),
(16, 'Voter/2023/PGDCA/4', 'election/2013/07/17/6', 16, 'upload/Penguins.jpg', 1, 1),
(17, 'Voter/2013/mca/38/4', 'election/2023/07/26/2', 15, 'upload/Tulips.jpg', 11, 1),
(18, 'Voter/2013/mca/38/4', 'election/2023/08/13/1', 14, 'upload/Koala.jpg', 1, 0),
(19, 'Voter/2013/PGDCA/34/1', 'election/2023/07/26/2', 13, 'upload/Penguins.jpg', 0, 1),
(20, 'Voter/2013/mca/1', 'election/2023/07/26/2', 13, 'upload/Lighthouse.jpg', 1, 1),
(21, 'Voter/2013/mca/1', 'election/2013/07/17/6', 16, 'upload/Tulips.jpg', 0, 0),
(22, 'Voter/2013/PGDCA/34/1', 'election/2023/08/13/1', 14, 'upload/Penguins.jpg', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_id` int(11) NOT NULL,
  `department_id` int(255) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `course_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `department_id`, `course_name`, `course_status`) VALUES
(14, 1, 'BCA', 1),
(15, 1, 'mca', 1),
(16, 2, 'B.A.(Assamese)', 1),
(17, 1, 'PGDCA', 1),
(18, 3, 'mba', 1),
(19, 2, 'MA  (Assamese)', 1),
(20, 3, 'M.Com', 1),
(21, 1, 'B.Sc IT', 1),
(22, 1, 'B.Sc. CS', 1);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `department_id` int(11) NOT NULL,
  `department_name` varchar(255) NOT NULL,
  `department_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`department_id`, `department_name`, `department_status`) VALUES
(1, 'school 0f innovation & technology', 1),
(2, 'Assamese Department', 1),
(3, 'school of management', 1),
(4, 'education department', 1);

-- --------------------------------------------------------

--
-- Table structure for table `election`
--

CREATE TABLE `election` (
  `sl_no` int(11) NOT NULL,
  `election_id` varchar(255) NOT NULL,
  `election_name` varchar(255) NOT NULL,
  `election_date` date NOT NULL,
  `time_upto` time NOT NULL,
  `election_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `election`
--

INSERT INTO `election` (`sl_no`, `election_id`, `election_name`, `election_date`, `time_upto`, `election_status`) VALUES
(4, 'election/2023/07/26/2', 'argucom 2023-24', '2023-06-21', '15:04:00', 1),
(5, 'election/2023/08/12/10', 'argucom 2022-23', '2023-09-03', '04:04:00', 1),
(6, 'election/2023/08/13/1', 'ARGUCOM ELECTION 2024-25', '2023-08-10', '05:36:00', 1),
(7, 'election/2013/07/17/6', ' Student Election 2023-24', '2013-07-19', '16:47:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `positions`
--

CREATE TABLE `positions` (
  `position_id` int(11) NOT NULL,
  `election_id` varchar(255) NOT NULL,
  `position_name` varchar(255) NOT NULL,
  `eligibility` varchar(255) NOT NULL,
  `position_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `positions`
--

INSERT INTO `positions` (`position_id`, `election_id`, `position_name`, `eligibility`, `position_status`) VALUES
(13, 'election/2023/07/26/2', 'Sports Secratary', '1/student should have atleast 75% attendence in previous semester.\r\n2/!st  year students are not allow.\r\n3/No backlog in previous semester.', 1),
(14, 'election/2023/08/13/1', 'general secratary', '1/student should have atleast 75% attendence in previous semester.\r\n\r\n2/!st  year students are not allow.\r\n\r\n3/No backlog in previous semester.', 1),
(15, 'election/2023/07/26/2', 'general secratary', '1/student should have atleast 75% attendence in previous semester.\r\n\r\n2/!st  year students are not allow.\r\n\r\n3/No backlog in previous semester.', 1),
(16, 'election/2013/07/17/6', 'social sec.', '1/Student must have 75% attendence in previous semester.\n2/2nd year student are allow.\n3/.xkfmng.asd klnfks \n4/skdj h.slkdj hkjs dhksjd h;sldk h;slkd h', 1),
(17, 'election/2013/07/17/6', 'General secratary', '1/student should have atleast 75% attendence in previous semester.\n 2/!st year students are not allow.\n 3/No backlog in previous semester.', 1),
(18, 'election/2013/07/17/6', 'SPORTS SECRATARY', '1/student should have atleast 75% attendence in previous semester.\n 2/!st year students are not allow.\n 3/No backlog in previous semester.', 1);

-- --------------------------------------------------------

--
-- Table structure for table `query`
--

CREATE TABLE `query` (
  `sl_no` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `reply` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `query`
--

INSERT INTO `query` (`sl_no`, `name`, `email`, `message`, `reply`, `status`) VALUES
(3, 'arshad', 'arshad@gmail.com', 'hii', '', 0),
(4, 'arshad rahman', 'arshad@gmail.com', 'argucom e w', 'kajsdnkajs dkajs kasj', 0),
(5, 'keshab', 'kk@gmail.com', '', '', 0),
(6, 'keshab', 'kk@gmail.com', '', '', 0),
(7, 'keshab', 'kesh@gmail.com', '', '', 0),
(8, 'konwar', 'aslkdn@gmail.com', 'asd as dasd as asd asd asd as dasd ', 'asd', 1),
(9, 'keshab', 'aslkdn@gmail.com', 'sd fsd sdf srtae5ye', 'cfgd g dg df ghsd gh', 1),
(10, 'konwar', 'aslkdn@gmail.com', 'g yj gfs hfg    dfggggggggggggggggg', 'mkm km m kmkm km km km ', 1),
(11, 'keshab', 'kesh@gmail.com', 'abcdefghijlmnopqrstuvwxyz', ',mj g,.mj .j h.jh .j h.kj h', 0),
(12, 'saswat ', 'saswat@gmail.com', 'asklhdaskn ans akns asnd aksdlaksnd aslkda;l ', 'kuygkhgljb  iu liu i', 0),
(14, 'keshabananda konowar', 'keshab@gmail.com', 'hello', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `semester_id` int(11) NOT NULL,
  `course_id` varchar(255) NOT NULL,
  `semester_name` varchar(255) NOT NULL,
  `semester_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`semester_id`, `course_id`, `semester_name`, `semester_status`) VALUES
(29, '14', 'bca 1st sem', 1),
(30, '14', 'bca 2nd sem', 1),
(31, '14', 'bca 3rd sem', 1),
(34, '17', 'pgdca 1st sem', 1),
(35, '17', 'pgdca 2nd sem', 1),
(36, '14', '4th semester', 1),
(37, '15', 'MCA 1st sem', 1),
(38, '15', 'MCA 2nd Sem', 1),
(39, '18', 'MBA 1st Sem', 1),
(40, '15', 'MCA 3RD SEM', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vote`
--

CREATE TABLE `vote` (
  `vote_no` int(11) NOT NULL,
  `voter_id` varchar(255) NOT NULL,
  `election_id` varchar(255) NOT NULL,
  `position_id` int(255) NOT NULL,
  `vote` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vote`
--

INSERT INTO `vote` (`vote_no`, `voter_id`, `election_id`, `position_id`, `vote`) VALUES
(26, 'Voter/2013/PGDCA/34/1', 'election/2023/07/26/2', 13, 'Voter/2023/1/38148'),
(27, 'Voter/2013/PGDCA/34/1', 'election/2023/07/26/2', 15, 'Voter/2023/PGDCA/3'),
(28, 'Voter/2013/PGDCA/35/5', 'election/2023/07/26/2', 13, 'Voter/2013/mca/1'),
(29, 'Voter/2013/PGDCA/35/5', 'election/2023/07/26/2', 15, 'Voter/2023/PGDCA/3'),
(30, 'Voter/2013/mca/1', 'election/2023/07/26/2', 15, 'Voter/2013/mca/38/4'),
(31, 'Voter/2013/mca/1', 'election/2023/07/26/2', 13, 'Voter/2023/1/38148'),
(32, 'Voter/2013/mca/1', 'election/2013/07/17/6', 16, 'Voter/2023/PGDCA/4');

-- --------------------------------------------------------

--
-- Table structure for table `voters`
--

CREATE TABLE `voters` (
  `sl_no` int(11) NOT NULL,
  `voter_id` varchar(255) NOT NULL,
  `voter_fname` varchar(255) NOT NULL,
  `voter_lname` varchar(255) NOT NULL,
  `voter_department` int(255) NOT NULL,
  `voter_course` text NOT NULL,
  `voter_semester` text NOT NULL,
  `voter_rollno` int(255) NOT NULL,
  `voter_state` varchar(255) NOT NULL,
  `voter_district` varchar(255) NOT NULL,
  `voter_postoffice` varchar(255) NOT NULL,
  `voter_pinno` int(255) NOT NULL,
  `voter_village` varchar(255) NOT NULL,
  `voter_phone_number` bigint(10) NOT NULL,
  `voter_email` varchar(255) NOT NULL,
  `voter_password` varchar(255) NOT NULL,
  `voter_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `voters`
--

INSERT INTO `voters` (`sl_no`, `voter_id`, `voter_fname`, `voter_lname`, `voter_department`, `voter_course`, `voter_semester`, `voter_rollno`, `voter_state`, `voter_district`, `voter_postoffice`, `voter_pinno`, `voter_village`, `voter_phone_number`, `voter_email`, `voter_password`, `voter_status`) VALUES
(11, 'Voter/2023/1/38148', 'keshabananda', 'konwar', 1, '14', '31', 2, 'assam', 'sivasagar', 'nitai', 7856732, 'baputigarh', 8728274545, 'kesgab@gmail.com', 'keshab', 1),
(13, 'Voter/2023/PGDCA/3', 'papu', 'konwar', 1, '17', '35', 3, 'assam', 'sivasagar', 'nitai pukhuri', 656756, 'konwar suk', 6746756756, 'papu@gmail.com', 'papu', 1),
(14, 'Voter/2023/PGDCA/4', 'DEVABROT', 'KONWAR', 1, '17', '35', 4, 'assam', 'sivasagar', 'nitai pukhuri', 785672, 'konwar suk', 8738745345, 'devabrot@gmail.com', 'devabrot', 1),
(15, 'Voter/2013/PGDCA/4', 'dfs', 'sdfsdfs', 1, '17', '35', 4, 'sdfsdfsf', 'werwerwer', 'ftgdrtyerty', 4567567, 'ertertert', 4564564564, 'sdf@gmail.com', 'ghjgj', 1),
(16, 'Voter/2013/PGDCA/11', 'fghdfgh', 'fghfgh', 1, '17', '35', 11, 'adfgadg', 'sedasfasf', 'dfgdsfgd', 4564564, 'sdgsfgfg', 3456456456, 'fghertefd@gmail.com', 'tytyu', 1),
(17, 'Voter/2013/mca/1', 'saswat', 'gogoi', 1, '15', '37', 1, 'assam', 'sivasagar', 'sivasagar', 4564564, 'abc', 7546456456, 'saswat@gmail.com', '6c40e8e14d24f4cb219efb1e2b239404', 1),
(18, 'Voter/2013/mca/38/3', 'arif', 'zahan', 1, '15', '38', 3, 'assakm', 'jorhat', 'torajan', 678456, 'bvcbcb', 8827342342, 'arif@gmail.com', 'c782174277eeb692b361f7e2b8eca99b', 0),
(19, 'Voter/2013/mca/38/4', 'tanjil', 'zahan', 1, '15', '38', 4, 'asd', 'dfsf', 'wserwer', 3453453, 'dfgdg', 9456456456, 'tanjil@gmail.com', 'ad7d2e8e4ed3bafdfa7337709feaf58f', 0),
(20, 'Voter/2013/PGDCA/34/1', 'arshad', 'rahman', 1, '17', '34', 1, 'asda', 'asda', 'asda', 3453455, 'zxccv', 7345345345, 'arshad@gmail.com', '779d79dc24928f4653d5ad84cffc559f', 0),
(21, 'Voter/2013/PGDCA/35/5', 'asd', 'asd', 1, '17', '35', 5, 'sdfs', 'sdfsf', 'sdfsdf', 4564564, 'fdgdxfgcx', 5464564564, 'asda@gmail.com', 'adbf5a778175ee757c34d0eba4e932bc', 0),
(22, 'Voter/2013/mca/40/4', 'sagar', 'pradhan', 1, '15', '40', 4, 'assam', 'sivasagar', 'sivasagar', 348536, 'abc', 8283742734, 'sagar@gmail.com', '41ed44e3038dbeee7d2ffaa7f51d8a4b', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`sl_no`);

--
-- Indexes for table `candidate`
--
ALTER TABLE `candidate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `election`
--
ALTER TABLE `election`
  ADD PRIMARY KEY (`sl_no`);

--
-- Indexes for table `positions`
--
ALTER TABLE `positions`
  ADD PRIMARY KEY (`position_id`);

--
-- Indexes for table `query`
--
ALTER TABLE `query`
  ADD PRIMARY KEY (`sl_no`);

--
-- Indexes for table `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`semester_id`);

--
-- Indexes for table `vote`
--
ALTER TABLE `vote`
  ADD PRIMARY KEY (`vote_no`);

--
-- Indexes for table `voters`
--
ALTER TABLE `voters`
  ADD PRIMARY KEY (`sl_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `sl_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `candidate`
--
ALTER TABLE `candidate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `department_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `election`
--
ALTER TABLE `election`
  MODIFY `sl_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `positions`
--
ALTER TABLE `positions`
  MODIFY `position_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `query`
--
ALTER TABLE `query`
  MODIFY `sl_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `semester`
--
ALTER TABLE `semester`
  MODIFY `semester_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `vote`
--
ALTER TABLE `vote`
  MODIFY `vote_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `voters`
--
ALTER TABLE `voters`
  MODIFY `sl_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
